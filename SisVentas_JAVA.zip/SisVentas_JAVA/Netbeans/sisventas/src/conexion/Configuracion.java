
package conexion;

public interface Configuracion {
    
    String DRIVER = "com.mysql.jdbc.Driver";
    String DATA_BASE = "sisventas";
    String CONNECTION_URL = "jdbc:mysql://127.0.0.1/"+DATA_BASE;    
    String USERNAME = "root";
    String PASSWORD = "";
    

}

