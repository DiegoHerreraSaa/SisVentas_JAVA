
package modelo;

public class Modelo_detalleVenta {
    
    private Integer IdDetalleVenta;
    private String CodigoArticulo1;
    private Integer cantidad;
    private String subTotal;
    
    private String nomArticulo;
    private Double precioFinal1;
    private String porIva;
    private String porDscto;

    public Modelo_detalleVenta() {
    }

    public Modelo_detalleVenta(Integer IdDetalleVenta, String CodigoArticulo1, Integer cantidad, String subTotal, String nomArticulo, Double precioFinal1, String porIva, String porDscto) {
        this.IdDetalleVenta = IdDetalleVenta;
        this.CodigoArticulo1 = CodigoArticulo1;
        this.cantidad = cantidad;
        this.subTotal = subTotal;
        this.nomArticulo = nomArticulo;
        this.precioFinal1 = precioFinal1;
        this.porIva = porIva;
        this.porDscto = porDscto;
    }

    public Integer getIdDetalleVenta() {
        return IdDetalleVenta;
    }

    public void setIdDetalleVenta(Integer IdDetalleVenta) {
        this.IdDetalleVenta = IdDetalleVenta;
    }

    public String getCodigoArticulo1() {
        return CodigoArticulo1;
    }

    public void setCodigoArticulo1(String CodigoArticulo1) {
        this.CodigoArticulo1 = CodigoArticulo1;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public String getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(String subTotal) {
        this.subTotal = subTotal;
    }

    public String getNomArticulo() {
        return nomArticulo;
    }

    public void setNomArticulo(String nomArticulo) {
        this.nomArticulo = nomArticulo;
    }

    public Double getPrecioFinal1() {
        return precioFinal1;
    }

    public void setPrecioFinal1(Double precioFinal1) {
        this.precioFinal1 = precioFinal1;
    }

    public String getPorIva() {
        return porIva;
    }

    public void setPorIva(String porIva) {
        this.porIva = porIva;
    }

    public String getPorDscto() {
        return porDscto;
    }

    public void setPorDscto(String porDscto) {
        this.porDscto = porDscto;
    }

    
}
