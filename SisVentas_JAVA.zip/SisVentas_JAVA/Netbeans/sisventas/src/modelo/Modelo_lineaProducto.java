
package modelo;

public class Modelo_lineaProducto {
    
    private Integer IdLineas;
    private String LineaDescripcion;
    private String estado;

    public Modelo_lineaProducto() {
    }

    public Modelo_lineaProducto(Integer IdLineas, String LineaDescripcion, String estado) {
        this.IdLineas = IdLineas;
        this.LineaDescripcion = LineaDescripcion;
        this.estado = estado;
    }

    public Integer getIdLineas() {
        return IdLineas;
    }

    public void setIdLineas(Integer IdLineas) {
        this.IdLineas = IdLineas;
    }

    public String getLineaDescripcion() {
        return LineaDescripcion;
    }

    public void setLineaDescripcion(String LineaDescripcion) {
        this.LineaDescripcion = LineaDescripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

}
