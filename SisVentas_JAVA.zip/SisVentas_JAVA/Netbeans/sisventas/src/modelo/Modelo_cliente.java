package modelo;

import java.sql.*;

public class Modelo_cliente {
    
    private Integer CodigoCliente;

    private String IdTipoIdentidad1;

    private String NumeroDocumento;
    private String Nombre; // nombre cliente
    private String Apellido;
    private String Genero;
    private Date FechaNacimiento;
    private String Direccion;
    private String Telefono;
    private String Email;
    private String IdBarrio1;
    private String CodigoCiudad1;

    private String nombre_tipo; // nombre del tipo de Identidad
    private String barrioCliente;
    private String ciudadCliente;
    private String estado;

    public Modelo_cliente() {
    }

    public Modelo_cliente(Integer CodigoCliente, String IdTipoIdentidad1, String NumeroDocumento, String Nombre, String Apellido, String Genero, Date FechaNacimiento, String Direccion, String Telefono, String Email, String IdBarrio1, String CodigoCiudad1, String nombre_tipo, String barrioCliente, String ciudadCliente, String estado) {
        this.CodigoCliente = CodigoCliente;
        this.IdTipoIdentidad1 = IdTipoIdentidad1;
        this.NumeroDocumento = NumeroDocumento;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Genero = Genero;
        this.FechaNacimiento = FechaNacimiento;
        this.Direccion = Direccion;
        this.Telefono = Telefono;
        this.Email = Email;
        this.IdBarrio1 = IdBarrio1;
        this.CodigoCiudad1 = CodigoCiudad1;
        this.nombre_tipo = nombre_tipo;
        this.barrioCliente = barrioCliente;
        this.ciudadCliente = ciudadCliente;
        this.estado = estado;
    }

    public Integer getCodigoCliente() {
        return CodigoCliente;
    }

    public void setCodigoCliente(Integer CodigoCliente) {
        this.CodigoCliente = CodigoCliente;
    }

    public String getIdTipoIdentidad1() {
        return IdTipoIdentidad1;
    }

    public void setIdTipoIdentidad1(String IdTipoIdentidad1) {
        this.IdTipoIdentidad1 = IdTipoIdentidad1;
    }

    public String getNumeroDocumento() {
        return NumeroDocumento;
    }

    public void setNumeroDocumento(String NumeroDocumento) {
        this.NumeroDocumento = NumeroDocumento;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

    public Date getFechaNacimiento() {
        return FechaNacimiento;
    }

    public void setFechaNacimiento(Date FechaNacimiento) {
        this.FechaNacimiento = FechaNacimiento;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getIdBarrio1() {
        return IdBarrio1;
    }

    public void setIdBarrio1(String IdBarrio1) {
        this.IdBarrio1 = IdBarrio1;
    }

    public String getCodigoCiudad1() {
        return CodigoCiudad1;
    }

    public void setCodigoCiudad1(String CodigoCiudad1) {
        this.CodigoCiudad1 = CodigoCiudad1;
    }

    public String getNombre_tipo() {
        return nombre_tipo;
    }

    public void setNombre_tipo(String nombre_tipo) {
        this.nombre_tipo = nombre_tipo;
    }

    public String getBarrioCliente() {
        return barrioCliente;
    }

    public void setBarrioCliente(String barrioCliente) {
        this.barrioCliente = barrioCliente;
    }

    public String getCiudadCliente() {
        return ciudadCliente;
    }

    public void setCiudadCliente(String ciudadCliente) {
        this.ciudadCliente = ciudadCliente;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    
}
