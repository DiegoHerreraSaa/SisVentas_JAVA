
package modelo;

public class Modelo_tipoCaja {
    
    private int IdTipoCaja;
    private String Nombre;
    private String estado;

    public Modelo_tipoCaja() {
    }

    public Modelo_tipoCaja(int IdTipoCaja, String Nombre, String estado) {
        this.IdTipoCaja = IdTipoCaja;
        this.Nombre = Nombre;
        this.estado = estado;
    }

    public int getIdTipoCaja() {
        return IdTipoCaja;
    }

    public void setIdTipoCaja(int IdTipoCaja) {
        this.IdTipoCaja = IdTipoCaja;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    
}
