
package modelo;

import java.sql.Date;

public class Modelo_empleado {
    
    private String IdEmpleados;
    private String PrimerNombre;
    private String SegundoNombre;
    private String PrimerApellido;
    private String SegundoApellido;
    private String IdRol1;
    private String Sexo;
    private String IdTipoIdentidad2;
    private String NumeroIdentidad;
    private Date FechaNac;
    private String IdCargo1;
    private String Direccion;
    private String Telefono;
    private String horaEntrada;
    private String horaSalida;
    
    
    private String nomRol;
    private String nomTipoId;
    private String nomCargo;
    private String estado;

    public Modelo_empleado() {
    }

    public Modelo_empleado(String IdEmpleados, String PrimerNombre, String SegundoNombre, String PrimerApellido, String SegundoApellido, String IdRol1, String Sexo, String IdTipoIdentidad2, String NumeroIdentidad, Date FechaNac, String IdCargo1, String Direccion, String Telefono, String horaEntrada, String horaSalida, String nomRol, String nomTipoId, String nomCargo, String estado) {
        this.IdEmpleados = IdEmpleados;
        this.PrimerNombre = PrimerNombre;
        this.SegundoNombre = SegundoNombre;
        this.PrimerApellido = PrimerApellido;
        this.SegundoApellido = SegundoApellido;
        this.IdRol1 = IdRol1;
        this.Sexo = Sexo;
        this.IdTipoIdentidad2 = IdTipoIdentidad2;
        this.NumeroIdentidad = NumeroIdentidad;
        this.FechaNac = FechaNac;
        this.IdCargo1 = IdCargo1;
        this.Direccion = Direccion;
        this.Telefono = Telefono;
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
        this.nomRol = nomRol;
        this.nomTipoId = nomTipoId;
        this.nomCargo = nomCargo;
        this.estado = estado;
    }

    public String getIdEmpleados() {
        return IdEmpleados;
    }

    public void setIdEmpleados(String IdEmpleados) {
        this.IdEmpleados = IdEmpleados;
    }

    public String getPrimerNombre() {
        return PrimerNombre;
    }

    public void setPrimerNombre(String PrimerNombre) {
        this.PrimerNombre = PrimerNombre;
    }

    public String getSegundoNombre() {
        return SegundoNombre;
    }

    public void setSegundoNombre(String SegundoNombre) {
        this.SegundoNombre = SegundoNombre;
    }

    public String getPrimerApellido() {
        return PrimerApellido;
    }

    public void setPrimerApellido(String PrimerApellido) {
        this.PrimerApellido = PrimerApellido;
    }

    public String getSegundoApellido() {
        return SegundoApellido;
    }

    public void setSegundoApellido(String SegundoApellido) {
        this.SegundoApellido = SegundoApellido;
    }

    public String getIdRol1() {
        return IdRol1;
    }

    public void setIdRol1(String IdRol1) {
        this.IdRol1 = IdRol1;
    }

    public String getSexo() {
        return Sexo;
    }

    public void setSexo(String Sexo) {
        this.Sexo = Sexo;
    }

    public String getIdTipoIdentidad2() {
        return IdTipoIdentidad2;
    }

    public void setIdTipoIdentidad2(String IdTipoIdentidad2) {
        this.IdTipoIdentidad2 = IdTipoIdentidad2;
    }

    public String getNumeroIdentidad() {
        return NumeroIdentidad;
    }

    public void setNumeroIdentidad(String NumeroIdentidad) {
        this.NumeroIdentidad = NumeroIdentidad;
    }

    public Date getFechaNac() {
        return FechaNac;
    }

    public void setFechaNac(Date FechaNac) {
        this.FechaNac = FechaNac;
    }

    public String getIdCargo1() {
        return IdCargo1;
    }

    public void setIdCargo1(String IdCargo1) {
        this.IdCargo1 = IdCargo1;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public String getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(String horaEntrada) {
        this.horaEntrada = horaEntrada;
    }

    public String getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(String horaSalida) {
        this.horaSalida = horaSalida;
    }

    public String getNomRol() {
        return nomRol;
    }

    public void setNomRol(String nomRol) {
        this.nomRol = nomRol;
    }

    public String getNomTipoId() {
        return nomTipoId;
    }

    public void setNomTipoId(String nomTipoId) {
        this.nomTipoId = nomTipoId;
    }

    public String getNomCargo() {
        return nomCargo;
    }

    public void setNomCargo(String nomCargo) {
        this.nomCargo = nomCargo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

}
