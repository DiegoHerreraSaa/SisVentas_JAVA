
package modelo;

public class Modelo_barrio {
    
    // Variables de la tabla
    private Integer IdBarrio;
    private String Nombre;
    private Integer Comuna;
    
    // Constructores

    public Modelo_barrio() {
    }

    public Modelo_barrio(Integer IdBarrio, String Nombre, Integer Comuna) {
        this.IdBarrio = IdBarrio;
        this.Nombre = Nombre;
        this.Comuna = Comuna;
    }
    
    // Métodos GET y SET

    public Integer getIdBarrio() {
        return IdBarrio;
    }

    public void setIdBarrio(Integer IdBarrio) {
        this.IdBarrio = IdBarrio;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public Integer getComuna() {
        return Comuna;
    }

    public void setComuna(Integer Comuna) {
        this.Comuna = Comuna;
    }
    
    
}
