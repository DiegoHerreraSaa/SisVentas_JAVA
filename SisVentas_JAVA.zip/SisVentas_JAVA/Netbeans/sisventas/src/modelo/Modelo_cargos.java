
package modelo;

public class Modelo_cargos {
    
    private Integer IdCargo;
    private String Nombre;
    private String Descripcion;

    private String estado;

    public Modelo_cargos() {
    }

    public Modelo_cargos(Integer IdCargo, String Nombre, String Descripcion, String estado) {
        this.IdCargo = IdCargo;
        this.Nombre = Nombre;
        this.Descripcion = Descripcion;
        this.estado = estado;
    }

    public Integer getIdCargo() {
        return IdCargo;
    }

    public void setIdCargo(Integer IdCargo) {
        this.IdCargo = IdCargo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
}
