
package modelo;

public class Modelo_caja {
     
    private String CodigoCaja;
    private String IdTipoCaja1;
    private String Ubicacion;
    private String Descripcion;
    
    private String tipoCaja; // Para ComboBox
    private String estado;

    public Modelo_caja() {
    }

    public Modelo_caja(String CodigoCaja, String IdTipoCaja1, String Ubicacion, String Descripcion, String tipoCaja, String estado) {
        this.CodigoCaja = CodigoCaja;
        this.IdTipoCaja1 = IdTipoCaja1;
        this.Ubicacion = Ubicacion;
        this.Descripcion = Descripcion;
        this.tipoCaja = tipoCaja;
        this.estado = estado;
    }

    public String getCodigoCaja() {
        return CodigoCaja;
    }

    public void setCodigoCaja(String CodigoCaja) {
        this.CodigoCaja = CodigoCaja;
    }

    public String getIdTipoCaja1() {
        return IdTipoCaja1;
    }

    public void setIdTipoCaja1(String IdTipoCaja1) {
        this.IdTipoCaja1 = IdTipoCaja1;
    }

    public String getUbicacion() {
        return Ubicacion;
    }

    public void setUbicacion(String Ubicacion) {
        this.Ubicacion = Ubicacion;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public String getTipoCaja() {
        return tipoCaja;
    }

    public void setTipoCaja(String tipoCaja) {
        this.tipoCaja = tipoCaja;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    
    
}
