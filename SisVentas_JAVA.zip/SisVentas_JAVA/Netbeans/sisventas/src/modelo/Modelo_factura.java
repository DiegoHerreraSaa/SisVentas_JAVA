
package modelo;

public class Modelo_factura {
    
    private Integer IdFactura;
    private String idTipoFactura1;
    private String IdDetalleVenta1;
    private String Fecha;
    private String Hora;
    private String CodigoCaja1;
    private String IdEmpleados1;
    private String CodigoCliente1;
    
    private String nomEmpleado;
    private String numDocCliente;
    private String nomCliente;
    private String tipoFactura;
    
    // Manejo de artículos e insertar valores en la tabla detalleVenta
    private String CodigoArticulo1; // para traer el nombre del artículo al momento de buscarlo
    private String nomArticulo; // para buscar el código del articulo al momento de enviar la tabla a la base

    public Modelo_factura() {
    }

    public Modelo_factura(Integer IdFactura, String idTipoFactura1, String IdDetalleVenta1, String Fecha, String Hora, String CodigoCaja1, String IdEmpleados1, String CodigoCliente1, String nomEmpleado, String numDocCliente, String nomCliente, String tipoFactura, String CodigoArticulo1, String nomArticulo) {
        this.IdFactura = IdFactura;
        this.idTipoFactura1 = idTipoFactura1;
        this.IdDetalleVenta1 = IdDetalleVenta1;
        this.Fecha = Fecha;
        this.Hora = Hora;
        this.CodigoCaja1 = CodigoCaja1;
        this.IdEmpleados1 = IdEmpleados1;
        this.CodigoCliente1 = CodigoCliente1;
        this.nomEmpleado = nomEmpleado;
        this.numDocCliente = numDocCliente;
        this.nomCliente = nomCliente;
        this.tipoFactura = tipoFactura;
        this.CodigoArticulo1 = CodigoArticulo1;
        this.nomArticulo = nomArticulo;
    }

    public Integer getIdFactura() {
        return IdFactura;
    }

    public void setIdFactura(Integer IdFactura) {
        this.IdFactura = IdFactura;
    }

    public String getIdTipoFactura1() {
        return idTipoFactura1;
    }

    public void setIdTipoFactura1(String idTipoFactura1) {
        this.idTipoFactura1 = idTipoFactura1;
    }

    public String getIdDetalleVenta1() {
        return IdDetalleVenta1;
    }

    public void setIdDetalleVenta1(String IdDetalleVenta1) {
        this.IdDetalleVenta1 = IdDetalleVenta1;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String Hora) {
        this.Hora = Hora;
    }

    public String getCodigoCaja1() {
        return CodigoCaja1;
    }

    public void setCodigoCaja1(String CodigoCaja1) {
        this.CodigoCaja1 = CodigoCaja1;
    }

    public String getIdEmpleados1() {
        return IdEmpleados1;
    }

    public void setIdEmpleados1(String IdEmpleados1) {
        this.IdEmpleados1 = IdEmpleados1;
    }

    public String getCodigoCliente1() {
        return CodigoCliente1;
    }

    public void setCodigoCliente1(String CodigoCliente1) {
        this.CodigoCliente1 = CodigoCliente1;
    }

    public String getNomEmpleado() {
        return nomEmpleado;
    }

    public void setNomEmpleado(String nomEmpleado) {
        this.nomEmpleado = nomEmpleado;
    }

    public String getNumDocCliente() {
        return numDocCliente;
    }

    public void setNumDocCliente(String numDocCliente) {
        this.numDocCliente = numDocCliente;
    }

    public String getNomCliente() {
        return nomCliente;
    }

    public void setNomCliente(String nomCliente) {
        this.nomCliente = nomCliente;
    }

    public String getTipoFactura() {
        return tipoFactura;
    }

    public void setTipoFactura(String tipoFactura) {
        this.tipoFactura = tipoFactura;
    }

    public String getCodigoArticulo1() {
        return CodigoArticulo1;
    }

    public void setCodigoArticulo1(String CodigoArticulo1) {
        this.CodigoArticulo1 = CodigoArticulo1;
    }

    public String getNomArticulo() {
        return nomArticulo;
    }

    public void setNomArticulo(String nomArticulo) {
        this.nomArticulo = nomArticulo;
    }

}
