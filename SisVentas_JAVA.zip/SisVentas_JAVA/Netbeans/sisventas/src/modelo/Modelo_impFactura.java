package modelo;

public class Modelo_impFactura {

    private String articulo;
    private String precioUnid;
    private String iva;
    private String dscto;
    private String cantidad;
    private String subtotal;

    public Modelo_impFactura(String articulo, String precioUnid, String iva, String dscto, String cantidad, String subtotal) {
        this.articulo = articulo;
        this.precioUnid = precioUnid;
        this.iva = iva;
        this.dscto = dscto;
        this.cantidad = cantidad;
        this.subtotal = subtotal;
    }

    public Modelo_impFactura() {
    }

    public String getArticulo() {
        return articulo;
    }

    public void setArticulo(String articulo) {
        this.articulo = articulo;
    }

    public String getPrecioUnid() {
        return precioUnid;
    }

    public void setPrecioUnid(String precioUnid) {
        this.precioUnid = precioUnid;
    }

    public String getIva() {
        return iva;
    }

    public void setIva(String iva) {
        this.iva = iva;
    }

    public String getDscto() {
        return dscto;
    }

    public void setDscto(String dscto) {
        this.dscto = dscto;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(String subtotal) {
        this.subtotal = subtotal;
    }


    
    

}
