
package modelo;

public class Modelo_subLineaProducto {
    
    private Integer IdSubLinea;
    private String SubLineaDescripcion;
    private String IdLineas1;
    
    private String nomLinea;
    private String estado;

    public Modelo_subLineaProducto() {
    }

    public Modelo_subLineaProducto(Integer IdSubLinea, String SubLineaDescripcion, String IdLineas1, String nomLinea, String estado) {
        this.IdSubLinea = IdSubLinea;
        this.SubLineaDescripcion = SubLineaDescripcion;
        this.IdLineas1 = IdLineas1;
        this.nomLinea = nomLinea;
        this.estado = estado;
    }

    public Integer getIdSubLinea() {
        return IdSubLinea;
    }

    public void setIdSubLinea(Integer IdSubLinea) {
        this.IdSubLinea = IdSubLinea;
    }

    public String getSubLineaDescripcion() {
        return SubLineaDescripcion;
    }

    public void setSubLineaDescripcion(String SubLineaDescripcion) {
        this.SubLineaDescripcion = SubLineaDescripcion;
    }

    public String getIdLineas1() {
        return IdLineas1;
    }

    public void setIdLineas1(String IdLineas1) {
        this.IdLineas1 = IdLineas1;
    }

    public String getNomLinea() {
        return nomLinea;
    }

    public void setNomLinea(String nomLinea) {
        this.nomLinea = nomLinea;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    
}
