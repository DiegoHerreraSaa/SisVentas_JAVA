
package modelo;

public class Modelo_articulo {
    
    private Integer CodigoArticulo;
    private String Descripcion;
    private Double Precio;
    private Double Costo;
    private Double Iva;
    private Double PrecioIva;
    private Double PorcentajeDescuento;
    private Double Descuento;
    private Double PrecioFinal;
    private String IdProveedor1;
    private String IdSublinea1;
    
    private String nomProveedor;
    private String nomSubLinea;
    private String estado;

    public Modelo_articulo() {
    }

    public Modelo_articulo(Integer CodigoArticulo, String Descripcion, Double Precio, Double Costo, Double Iva, Double PrecioIva, Double PorcentajeDescuento, Double Descuento, Double PrecioFinal, String IdProveedor1, String IdSublinea1, String nomProveedor, String nomSubLinea, String estado) {
        this.CodigoArticulo = CodigoArticulo;
        this.Descripcion = Descripcion;
        this.Precio = Precio;
        this.Costo = Costo;
        this.Iva = Iva;
        this.PrecioIva = PrecioIva;
        this.PorcentajeDescuento = PorcentajeDescuento;
        this.Descuento = Descuento;
        this.PrecioFinal = PrecioFinal;
        this.IdProveedor1 = IdProveedor1;
        this.IdSublinea1 = IdSublinea1;
        this.nomProveedor = nomProveedor;
        this.nomSubLinea = nomSubLinea;
        this.estado = estado;
    }

    public Integer getCodigoArticulo() {
        return CodigoArticulo;
    }

    public void setCodigoArticulo(Integer CodigoArticulo) {
        this.CodigoArticulo = CodigoArticulo;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public Double getPrecio() {
        return Precio;
    }

    public void setPrecio(Double Precio) {
        this.Precio = Precio;
    }

    public Double getCosto() {
        return Costo;
    }

    public void setCosto(Double Costo) {
        this.Costo = Costo;
    }

    public Double getIva() {
        return Iva;
    }

    public void setIva(Double Iva) {
        this.Iva = Iva;
    }

    public Double getPrecioIva() {
        return PrecioIva;
    }

    public void setPrecioIva(Double PrecioIva) {
        this.PrecioIva = PrecioIva;
    }

    public Double getPorcentajeDescuento() {
        return PorcentajeDescuento;
    }

    public void setPorcentajeDescuento(Double PorcentajeDescuento) {
        this.PorcentajeDescuento = PorcentajeDescuento;
    }

    public Double getDescuento() {
        return Descuento;
    }

    public void setDescuento(Double Descuento) {
        this.Descuento = Descuento;
    }

    public Double getPrecioFinal() {
        return PrecioFinal;
    }

    public void setPrecioFinal(Double PrecioFinal) {
        this.PrecioFinal = PrecioFinal;
    }

    public String getIdProveedor1() {
        return IdProveedor1;
    }

    public void setIdProveedor1(String IdProveedor1) {
        this.IdProveedor1 = IdProveedor1;
    }

    public String getIdSublinea1() {
        return IdSublinea1;
    }

    public void setIdSublinea1(String IdSublinea1) {
        this.IdSublinea1 = IdSublinea1;
    }

    public String getNomProveedor() {
        return nomProveedor;
    }

    public void setNomProveedor(String nomProveedor) {
        this.nomProveedor = nomProveedor;
    }

    public String getNomSubLinea() {
        return nomSubLinea;
    }

    public void setNomSubLinea(String nomSubLinea) {
        this.nomSubLinea = nomSubLinea;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    
}