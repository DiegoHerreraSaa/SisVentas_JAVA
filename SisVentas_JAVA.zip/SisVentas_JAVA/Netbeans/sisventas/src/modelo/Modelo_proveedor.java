
package modelo;

public class Modelo_proveedor {
    
    private Integer IdProveedor;
    private String NumeroIdentidad;
    private String Nombre;
    private String CodigoCiudad2;
    private String Direccion;
    private String Telefono;
    private String Email;
    
    private String estado;
    private String ciudadProveedor;

    public Modelo_proveedor() {
    }

    public Modelo_proveedor(Integer IdProveedor, String NumeroIdentidad, String Nombre, String CodigoCiudad2, String Direccion, String Telefono, String Email, String estado, String ciudadProveedor) {
        this.IdProveedor = IdProveedor;
        this.NumeroIdentidad = NumeroIdentidad;
        this.Nombre = Nombre;
        this.CodigoCiudad2 = CodigoCiudad2;
        this.Direccion = Direccion;
        this.Telefono = Telefono;
        this.Email = Email;
        this.estado = estado;
        this.ciudadProveedor = ciudadProveedor;
    }

    public Integer getIdProveedor() {
        return IdProveedor;
    }

    public void setIdProveedor(Integer IdProveedor) {
        this.IdProveedor = IdProveedor;
    }

    public String getNumeroIdentidad() {
        return NumeroIdentidad;
    }

    public void setNumeroIdentidad(String NumeroIdentidad) {
        this.NumeroIdentidad = NumeroIdentidad;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getCodigoCiudad2() {
        return CodigoCiudad2;
    }

    public void setCodigoCiudad2(String CodigoCiudad2) {
        this.CodigoCiudad2 = CodigoCiudad2;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCiudadProveedor() {
        return ciudadProveedor;
    }

    public void setCiudadProveedor(String ciudadProveedor) {
        this.ciudadProveedor = ciudadProveedor;
    }

    
   
}