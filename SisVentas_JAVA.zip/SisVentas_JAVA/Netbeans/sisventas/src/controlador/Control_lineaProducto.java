
package controlador;

import conexion.Conexion;
import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.Modelo_lineaProducto;

public class Control_lineaProducto {
    
    private String sql;
    
    public void mostrar_busqueda(Modelo_lineaProducto dtsLinea){
        Conexion conexion = new Conexion();
        sql = " SELECT * FROM lineaproducto WHERE LineaDescripcion LIKE '"+dtsLinea.getLineaDescripcion()+"' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            while (rs.next()) {
                dtsLinea.setIdLineas(Integer.parseInt(rs.getString("IdLineas")));
                dtsLinea.setLineaDescripcion(rs.getString("LineaDescripcion"));
                dtsLinea.setEstado(rs.getString("estado"));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar linea de producto "+e);
        }
    }
    
    
    public void nuevaLinea(Modelo_lineaProducto dtsLinea){
        Conexion conexion = new Conexion();
        sql = " INSERT INTO lineaproducto VALUES( '"+(IdLinea()+1)+"', '"+dtsLinea.getLineaDescripcion()+"', "
                + " '"+dtsLinea.getEstado()+"' ) ";
        
        if(conexion.ejecutar(sql)){
            JOptionPane.showMessageDialog(null, "Registro de línea nueva exitoso");
        }else{
            JOptionPane.showMessageDialog(null, "Error al crear nueva línea");
        }
    }
    
    
    public void editarLinea(Modelo_lineaProducto dtsLinea){
        Conexion conexion = new Conexion();
        sql = " UPDATE lineaproducto SET LineaDescripcion = '"+dtsLinea.getLineaDescripcion()+"', "
                + " estado = '"+dtsLinea.getEstado()+"' WHERE IdLineas LIKE '"+dtsLinea.getIdLineas()+"' ";
        
        if(conexion.ejecutar(sql)){
            JOptionPane.showMessageDialog(null, "La línea fue editada correctamente");
        }else{
            JOptionPane.showMessageDialog(null, "Error al editar la linea de producto");
        }
    }
    
    
//    public boolean eliminarLinea(Modelo_lineaProducto dtsLinea){
//        Conexion conexion = new Conexion();
//        sql = " DELETE FROM lineaproducto WHERE IdLineas LIKE '"+dtsLinea.getIdLineas()+"' ";
//        
//        if(conexion.ejecutar(sql)){
//            JOptionPane.showMessageDialog(null, "La línea fue eliminada correctamente");
//        }else{
//            JOptionPane.showMessageDialog(null, "Error al eliminar línea");
//        }
//        return false;
//    }
    
    
    
    public void llenarCob_lineas(JComboBox cob_lineas){
        Conexion conexion = new Conexion();
        sql = " SELECT LineaDescripcion AS linea FROM lineaproducto ORDER BY LineaDescripcion ASC ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            cob_lineas.addItem("- Buscar Línea -");
            while (rs.next()) {                
                cob_lineas.addItem(rs.getString("linea"));
            }
        } catch (Exception e) {
            System.out.println("Error al llenar ComboBox Línea Producto "+e);
        }
    }
    
    
    
    
    public int IdLinea(){
        int idLinea = 0;
        Conexion conexion = new Conexion();
        sql = " SELECT MAX(IdLineas) AS idlinea FROM lineaproducto ";
        ResultSet rs = conexion.consultar(sql);
        try {
            while (rs.next()) {                
                idLinea = rs.getInt("idlinea");
            }
        } catch (Exception e) {
            System.out.println("Error en el contador Id linea producto "+e);
        }
        return idLinea;
    }
    
}
