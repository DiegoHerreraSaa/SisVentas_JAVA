package controlador;

import conexion.Conexion;
import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.Modelo_empleado;

public class Control_empleado {

    private String sql;
    public String primerApellido, idRol, nomEmpleado;

    public void mostrar_busqueda(Modelo_empleado dtsEmpleado) {
        Conexion conexion = new Conexion();
        sql = " SELECT e.*, r.Nombre AS rol, ti.NombreTipoIdentidad AS nomID, c.Nombre AS cargo FROM empleados e "
                + " JOIN rol r ON r.IdRol = e.IdRol1 JOIN tipoidentidad ti ON ti.IdTipoIdentidad = e.IdTipoIdentidad2 "
                + " JOIN cargos c ON c.IdCargo = e.IdCargo1 WHERE e.NumeroIdentidad LIKE '" + dtsEmpleado.getNumeroIdentidad() + "' ";
        ResultSet rs = conexion.consultar(sql);

        try {
            while (rs.next()) {
                dtsEmpleado.setIdEmpleados(rs.getString("IdEmpleados"));

                dtsEmpleado.setPrimerNombre(rs.getString("PrimerNombre"));
                dtsEmpleado.setSegundoNombre(rs.getString("SegundoNombre"));
                dtsEmpleado.setPrimerApellido(rs.getString("PrimerApellido"));
                dtsEmpleado.setSegundoApellido(rs.getString("SegundoApellido"));
                dtsEmpleado.setNomRol(rs.getString("rol"));
                dtsEmpleado.setSexo(rs.getString("Sexo"));
                dtsEmpleado.setNomTipoId(rs.getString("nomID"));
                dtsEmpleado.setNumeroIdentidad(rs.getString("NumeroIdentidad"));
                dtsEmpleado.setFechaNac(rs.getDate("FechaNac"));
                dtsEmpleado.setNomCargo(rs.getString("cargo"));
                dtsEmpleado.setDireccion(rs.getString("Direccion"));
                dtsEmpleado.setTelefono(rs.getString("Telefono"));
                dtsEmpleado.setHoraEntrada(rs.getString("horaEntrada"));
                dtsEmpleado.setHoraSalida(rs.getString("horaSalida"));
                dtsEmpleado.setEstado(rs.getString("estado"));
            }
        } catch (Exception e) {
            System.out.println("Error al buscar empleado " + e);
        }
    }

    public void nuevoEmpleado(Modelo_empleado dtsEmpleado) {

        Conexion conexion = new Conexion();
        sql = " INSERT INTO empleados VALUES( '" + (contador_IdEmpleados() + 1) + "', '" + dtsEmpleado.getPrimerNombre() + "', "
                + " '" + dtsEmpleado.getSegundoNombre() + "', '" + dtsEmpleado.getPrimerApellido() + "', '" + dtsEmpleado.getSegundoApellido() + "', "
                + " '" + idRol(dtsEmpleado) + "', '" + dtsEmpleado.getSexo() + "', '" + IdTipoIdentidad(dtsEmpleado) + "', "
                + " '" + dtsEmpleado.getNumeroIdentidad() + "', '" + dtsEmpleado.getFechaNac() + "', '" + IdCargo(dtsEmpleado) + "', "
                + " '" + dtsEmpleado.getDireccion() + "', '" + dtsEmpleado.getTelefono() + "', '" + dtsEmpleado.getHoraEntrada() + "', "
                + " '" + dtsEmpleado.getHoraSalida() + "', '"+dtsEmpleado.getEstado()+"' ) ";

        if (conexion.ejecutar(sql)) {
            JOptionPane.showMessageDialog(null, "Registro de empleado exitoso");
        } else {
            JOptionPane.showMessageDialog(null, "Error al registrar empleado");
        }
    }

    
    public void editarEmpleado(Modelo_empleado dtsEmpleado){
        Conexion conexion = new Conexion();
        sql = " UPDATE empleados SET PrimerNombre = '"+dtsEmpleado.getPrimerNombre()+"', SegundoNombre = '"+dtsEmpleado.getSegundoNombre()+"',"
                + " PrimerApellido = '"+dtsEmpleado.getPrimerApellido()+"', SegundoApellido = '"+dtsEmpleado.getSegundoApellido()+"', "
                + " IdRol1 = '"+idRol(dtsEmpleado)+"', Sexo = '"+dtsEmpleado.getSexo()+"', IdTipoIdentidad2 = '"+IdTipoIdentidad(dtsEmpleado)+"',"
                + " NumeroIdentidad = '"+dtsEmpleado.getNumeroIdentidad()+"', FechaNac = '"+dtsEmpleado.getFechaNac()+"', "
                + " IdCargo1 = '"+IdCargo(dtsEmpleado)+"', "
                + " Direccion = '"+dtsEmpleado.getDireccion()+"', Telefono = '"+dtsEmpleado.getTelefono()+"', "
                + " horaEntrada = '"+dtsEmpleado.getHoraEntrada()+"', horaSalida = '"+dtsEmpleado.getHoraSalida()+"',  "
                + " estado = '"+dtsEmpleado.getEstado()+"' WHERE IdEmpleados LIKE '"+dtsEmpleado.getIdEmpleados()+"' ";
        
        if(conexion.ejecutar(sql)){
            JOptionPane.showMessageDialog(null, "El empleado se ha actualizado correctamente");
        } else{
            JOptionPane.showMessageDialog(null, "Error al actualizar empleado");
        }
    }
    
    
    public int consulta_existe(Modelo_empleado dtsEmpleado) {
        int existe = 0;

        Conexion conexion = new Conexion();
        sql = " SELECT IdEmpleados FROM empleados WHERE NumeroIdentidad LIKE '" + dtsEmpleado.getNumeroIdentidad() + "' ";
        ResultSet rs = conexion.consultar(sql);

        try {
            if (rs.next()) {
                existe = 1;
            }
        } catch (Exception e) {
            System.out.println("Error al consultar existencia de empleado " + e);
        }

        return existe;
    }

    
    
    public int contador_IdEmpleados() {
        int idEmpleados = 0;

        Conexion conexion = new Conexion();
        sql = " SELECT MAX(IdEmpleados) AS idEmpleado FROM empleados ";
        ResultSet rs = conexion.consultar(sql);

        try {
            while (rs.next()) {
                idEmpleados = rs.getInt("idEmpleado");
            }
        } catch (Exception e) {
            System.out.println("Error en el contador de empleado " + e);
        }

        return idEmpleados;
    }

    /* ==================  CAPTURAS ID FORÁNEAS ========================= */
    public int idRol(Modelo_empleado dtsEmpleado) {
        int idRol = 0;

        Conexion conexion = new Conexion();
        sql = " SELECT IdRol FROM rol WHERE Nombre LIKE '" + dtsEmpleado.getNomRol() + "' ";
        ResultSet rs = conexion.consultar(sql);

        try {
            while (rs.next()) {
                idRol = rs.getInt("IdRol");
            }
        } catch (Exception e) {
            System.out.println("Error en consulta de id rol empleado " + e);
        }

        return idRol;
    }

    public int IdTipoIdentidad(Modelo_empleado dtsEmpleado) {
        int idTipoIdentidad = 0;

        Conexion conexion = new Conexion();
        sql = " SELECT IdTipoIdentidad FROM tipoidentidad WHERE NombreTipoIdentidad LIKE '" + dtsEmpleado.getNomTipoId() + "' ";
        ResultSet rs = conexion.consultar(sql);

        try {
            while (rs.next()) {
                idTipoIdentidad = rs.getInt("IdTipoIdentidad");
            }
        } catch (Exception e) {
            System.out.println("Error en consulta de id tipo identidad de empleado " + e);
        }

        return idTipoIdentidad;
    }

    public int IdCargo(Modelo_empleado dtsEmpleado) {
        int idCargo = 0;

        Conexion conexion = new Conexion();
        sql = " SELECT IdCargo FROM cargos WHERE Nombre LIKE '" + dtsEmpleado.getNomCargo() + "' ";
        ResultSet rs = conexion.consultar(sql);

        try {
            while (rs.next()) {
                idCargo = rs.getInt("IdCargo");
            }
        } catch (Exception e) {
            System.out.println("Error en consulta de id cargo de empleado " + e);
        }

        return idCargo;
    }

    /* ==================  LLENADO DE COMBOBOX ========================= */
    public void llenarCob_tipoId(JComboBox cob_tipoIdentidad) {

        Conexion conexion = new Conexion();
        sql = " SELECT NombreTipoIdentidad FROM tipoidentidad ORDER BY NombreTipoIdentidad ";
        ResultSet rs = conexion.consultar(sql);

        try {
            while (rs.next()) {
                cob_tipoIdentidad.addItem(rs.getString("NombreTipoIdentidad"));
            }
        } catch (Exception e) {
            System.out.println("Error al cargar ComboBox nombre tipo de identidad " + e);
        }
    }
    

    public void llenarCob_rolEmpleado(JComboBox cob_rolEmpleado) {

        Conexion conexion = new Conexion();
        sql = " SELECT Nombre FROM rol ORDER BY Nombre ";
        ResultSet rs = conexion.consultar(sql);

        try {
            cob_rolEmpleado.addItem("- Seleccione Rol -");
            while (rs.next()) {
                cob_rolEmpleado.addItem(rs.getString("Nombre"));
            }
        } catch (Exception e) {
            System.out.println("Error al cargar ComboBox rol empleado " + e);
        }
    }

    public void llenarCob_cargoEmpleado(JComboBox cob_cargoEmpleado) {

        Conexion conexion = new Conexion();
        sql = " SELECT Nombre FROM cargos ORDER BY Nombre ";
        ResultSet rs = conexion.consultar(sql);

        try {
            cob_cargoEmpleado.addItem("- Seleccione cargo -");
            while (rs.next()) {
                cob_cargoEmpleado.addItem(rs.getString("Nombre"));
            }
        } catch (Exception e) {
            System.out.println("Error al cargar ComboBox rol empleado " + e);
        }
    }
    
    
    
    // ====================== SECCIÓN DE LOGUEO  ========================================
    
    public int login(Modelo_empleado dtsEmpleado){
        int existe = 0;
        Conexion conexion = new Conexion();
        sql = " SELECT PrimerApellido, CONCAT(PrimerNombre,\" \",PrimerApellido,\" \", SegundoApellido) AS nomEmpleado, NumeroIdentidad, estado, IdRol1 FROM empleados "
                + " WHERE PrimerApellido LIKE '"+dtsEmpleado.getPrimerApellido()+"' "
                + " AND NumeroIdentidad LIKE '"+dtsEmpleado.getNumeroIdentidad()+"' "
                + " AND estado LIKE 'Activo' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            if(rs.next()){
                primerApellido = rs.getString("PrimerApellido");
                idRol = rs.getString("IdRol1");
                nomEmpleado = rs.getString("nomEmpleado");
                existe = 1;
            }
        } catch (Exception e) {
            System.out.println("Error en el login control "+e);
        }
        return existe;
    }
    
    
    public void llenarCob_cajaRegistradora(JComboBox cob_cajaRegistradora) {

        Conexion conexion = new Conexion();
        sql = " SELECT CodigoCaja FROM caja WHERE estado = 'Activo' ORDER BY CodigoCaja ASC ";
        ResultSet rs = conexion.consultar(sql);

        try {
            cob_cajaRegistradora.addItem("- Caja -");
            while (rs.next()) {
                cob_cajaRegistradora.addItem(rs.getString("CodigoCaja"));
            }
        } catch (Exception e) {
            System.out.println("Error al cargar ComboBox caja registradora en login " + e);
        }
    }
}
