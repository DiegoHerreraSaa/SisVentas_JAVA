
package controlador;

import conexion.Conexion;
import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.Modelo_proveedor;

public class Control_proveedor {
        
    private String sql;
    
    
    public void nuevoProveedor(Modelo_proveedor dtsProveedor){
        
        Conexion conexion = new Conexion();
        sql = " INSERT INTO proveedores VALUES( '" + (idProveedor() + 1) + "','" + dtsProveedor.getNumeroIdentidad() + "', "
                + " '" + dtsProveedor.getNombre() + "','" + Consultar_codigoCiudad(dtsProveedor) + "', "
                + " '" + dtsProveedor.getDireccion() + "','" + dtsProveedor.getTelefono() + "', "
                + " '" + dtsProveedor.getEmail() + "', '"+dtsProveedor.getEstado()+"' ) ";
        
        try {
            if(conexion.ejecutar(sql)){
            JOptionPane.showMessageDialog(null, "Registro de Proveedor exitoso");
            } else {
                JOptionPane.showMessageDialog(null, "Error al crear Proveedor");
            }
        } catch (Exception e) {
            System.out.println("Error al crear Proveedor "+e);
        }
        
    }
    
    
    public void editarProveedor(Modelo_proveedor dtsProveedor){
        
        Conexion conexion = new Conexion();
        sql = " UPDATE proveedores SET NumeroIdentidad = '"+dtsProveedor.getNumeroIdentidad()+"', "
                + " Nombre = '"+dtsProveedor.getNombre()+"', CodigoCiudad2 = '"+Consultar_codigoCiudad(dtsProveedor)+"', "
                + " Direccion = '"+dtsProveedor.getDireccion()+"', Telefono = '"+dtsProveedor.getTelefono()+"', "
                + " Email = '"+dtsProveedor.getEmail()+"', estado = '"+dtsProveedor.getEstado()+"' "
                + " WHERE IdProveedor LIKE '"+dtsProveedor.getIdProveedor()+"' ";
        
        if (conexion.ejecutar(sql)) {
            JOptionPane.showMessageDialog(null, "El proveedor ha sido actualizado con éxito");
        }else{
            JOptionPane.showMessageDialog(null, "Error al editar el proveedor");
        }
    }
    
    
//    public boolean eliminarProveedor(Modelo_proveedor dtsProveedor){
//        
//        Conexion conexion = new Conexion();
//        sql = " DELETE FROM proveedores WHERE NumeroIdentidad = '"+dtsProveedor.getNumeroIdentidad()+"' ";
//        
//        if(conexion.ejecutar(sql)){
//            JOptionPane.showMessageDialog(null, "El proveedor ha sido eliminado correctamente");
//        }else{
//            JOptionPane.showMessageDialog(null, "Hubo un error al eliminar el proveedor");
//        }
//        
//        return false;
//    }
    
    
    
    
    
    
    
    
    
    
    
    // Cargar ComboBox Ciudad
    public void llenarCob_ciudad(JComboBox cob_ciudadProveedor){
        Conexion conexion = new Conexion();
        sql = " SELECT Nombre AS nomCiudad FROM ciudad ORDER BY Nombre ASC ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            cob_ciudadProveedor.addItem("- Ciudad -");
            while (rs.next()) {                
                cob_ciudadProveedor.addItem(rs.getString("nomCiudad"));
            }
        } catch (Exception e) {
            System.out.println("Error en la consulta de ComboBox ciudad Proveedor" + e);
        }
    }
    
    // Traer CodigoCiudad2
    public int Consultar_codigoCiudad(Modelo_proveedor dts){
        
        int codCiudad = 0;
        
        Conexion conexion = new Conexion();
        sql = " SELECT CodigoCiudad FROM ciudad WHERE Nombre LIKE '" + dts.getCiudadProveedor()+ "' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            while (rs.next()) {                
                codCiudad = rs.getInt("CodigoCiudad");
            }
        } catch (Exception e) {
            System.out.println("Error la consulta de Codigo Ciudad Proveedor " + e);
        }
        return codCiudad;
    }
    
    // Generar IdProveedor
    public int idProveedor(){
        
        int idproveedor = 0;
        
        Conexion conexion = new Conexion();
        sql = " SELECT MAX(idProveedor) AS idProveedor FROM proveedores ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            while (rs.next()) {                
                idproveedor = rs.getInt("idProveedor");
            }
        } catch (Exception e) {
            System.out.println("Error en contador idProveedor "+e);
        }
        return idproveedor;
    }
    
}
