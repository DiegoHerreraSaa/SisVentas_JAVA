
package controlador;

import conexion.Conexion;
import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.Modelo_tipoCaja;

public class Control_tipoCaja {
    
    private String sql;
    
    public void nuevoTipoCaja(Modelo_tipoCaja dtsTipoCaja){
        
        Conexion conexion = new Conexion();
        sql = " INSERT INTO tipocaja VALUES( '"+(contador_IdTipoCaja()+1)+"', "
                + " '"+dtsTipoCaja.getNombre()+"', '"+dtsTipoCaja.getEstado()+"' ) ";
        
        if(conexion.ejecutar(sql)){
            JOptionPane.showMessageDialog(null, "Registro de tipo caja exitoso");
        }else{
            JOptionPane.showMessageDialog(null, "Error al registrar el tipo caja");
        }
    }
    
    public void editarTipoCaja(Modelo_tipoCaja dtsTipoCaja){
        
        Conexion conexion = new Conexion();
        sql = " UPDATE tipocaja SET Nombre = '"+dtsTipoCaja.getNombre()+"', estado = '"+dtsTipoCaja.getEstado()+"' "
                + " WHERE IdTipoCaja LIKE '"+dtsTipoCaja.getIdTipoCaja()+"' ";
        
        if(conexion.ejecutar(sql)){
            JOptionPane.showMessageDialog(null, "Tipo de caja actualizado correctamente");
        }else{
            JOptionPane.showMessageDialog(null, "Error al actualizar el tipo de caja");
        }
    }
    
    
//    public boolean eliminarTipoCaja(Modelo_tipoCaja dtsTipoCaja){
//        
//        Conexion conexion = new Conexion();
//        sql = " DELETE FROM tipocaja WHERE IdTipoCaja LIKE '"+dtsTipoCaja.getIdTipoCaja()+"' ";
//        
//        if (conexion.ejecutar(sql)) {
//            JOptionPane.showMessageDialog(null, "Tipo de caja eliminado correctamente");
//        }else{
//            JOptionPane.showMessageDialog(null, "Error al eliminar tipo de caja");
//        }
//        
//        return false;
//    }
    
    
    public void llenarCob_tipoCaja(JComboBox cob_idCaja){
        
        Conexion conexion = new Conexion();
        sql = " SELECT IdTipoCaja AS idTipo FROM tipocaja ORDER BY IdTipoCaja ASC ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            cob_idCaja.addItem("Buscar");
            while (rs.next()) {                
                cob_idCaja.addItem(rs.getString("idTipo"));
            }
        } catch (Exception e) {
            System.out.println("Error al cargar ComboBox tipo caja "+e);
        }
    }
    
    public int contador_IdTipoCaja(){
        int idTipocaja=0;
        Conexion conexion = new Conexion();
        sql = " SELECT MAX(IdTipoCaja) AS idTCaja FROM tipocaja ";
        ResultSet rs = conexion.consultar(sql);
        try {
            if(rs.next()){
                idTipocaja = rs.getInt("idTCaja");
            }
        } catch (Exception e) {
            System.out.println("Error en el contador id Tipo Caja "+e);
        }
        return idTipocaja;
    }
    
}
