
package controlador;

import conexion.Conexion;
import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.Modelo_subLineaProducto;

public class Control_subLineaProducto {
    private String sql;
    
    public void mostrar_busqueda(Modelo_subLineaProducto dtsSubLinea){
        Conexion conexion = new Conexion();
        sql = " SELECT s.*, l.LineaDescripcion AS linea FROM sublineaproducto s JOIN lineaproducto l "
                + " ON l.IdLineas = s.IdLineas1 WHERE s.SubLineaDescripcion LIKE '"+dtsSubLinea.getSubLineaDescripcion()+"' ";
        ResultSet rs = conexion.consultar(sql);
        try {
            while (rs.next()) {
                dtsSubLinea.setIdSubLinea(rs.getInt("IdSubLinea"));
                dtsSubLinea.setSubLineaDescripcion(rs.getString("SubLineaDescripcion"));
                dtsSubLinea.setNomLinea(rs.getString("linea"));
                dtsSubLinea.setEstado(rs.getString("estado"));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar Sub Línea de producto "+e);
        }
    }
    
    
    public void nuevaSubLinea(Modelo_subLineaProducto dtsSubLinea){
        Conexion conexion = new Conexion();
        sql = " INSERT INTO sublineaproducto VALUES( '"+(IdSubLinea()+1)+"', '"+dtsSubLinea.getSubLineaDescripcion()+"', "
                + " '"+consultar_idLinea(dtsSubLinea)+"', '"+dtsSubLinea.getEstado()+"' ) ";
        
        try {
            if(conexion.ejecutar(sql)){
                JOptionPane.showMessageDialog(null, "Registro de Sub Línea exitoso");
            }else{
                JOptionPane.showMessageDialog(null, "Error al crear Sub Línea");
            }
        } catch (Exception e) {
            System.out.println("Error al crear Sub Línea "+e);
        }
    }
    
    
    public void editar_subLinea(Modelo_subLineaProducto dtsSubLinea){
        Conexion conexion = new Conexion();
        sql = " UPDATE sublineaproducto SET SubLineaDescripcion = '"+dtsSubLinea.getSubLineaDescripcion()+"', "
                + " IdLineas1 = '"+consultar_idLinea(dtsSubLinea)+"', estado = '"+dtsSubLinea.getEstado()+"' "
                + " WHERE IdSubLinea LIKE '"+dtsSubLinea.getIdSubLinea()+"' ";
        
        try {
            if(conexion.ejecutar(sql)){
                JOptionPane.showMessageDialog(null, "La sub Línea ha sido editada correctamente");
            }else{
                JOptionPane.showMessageDialog(null, "Error al editar la sub Línea");
            }
        } catch (Exception e) {
            System.out.println("Error al editar la sub Línea "+e);
        }
    }
    
//    public boolean eliminar_subLinea(Modelo_subLineaProducto dtsSubLinea){
//        Conexion conexion = new Conexion();
//        sql = " DELETE FROM sublineaproducto WHERE IdSubLinea LIKE '"+dtsSubLinea.getIdSubLinea()+"' ";
//        
//        try {
//            if (conexion.ejecutar(sql)) {
//                JOptionPane.showMessageDialog(null, "La sub línea ha sido eliminada");
//            }else {
//                JOptionPane.showMessageDialog(null, "Error al eliminar sub línea");
//            }
//        } catch (Exception e) {
//            System.out.println("Error al eliminar sub línea "+e);
//        }
//        
//        return false;
//    }
    
    
    private String consultar_idLinea(Modelo_subLineaProducto dtsSublinea){
        String idLinea = "";
        Conexion conexion = new Conexion();
        sql = " SELECT IdLineas FROM lineaproducto WHERE LineaDescripcion LIKE '"+dtsSublinea.getNomLinea()+"' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            if(rs.next()){
                idLinea = rs.getString("IdLineas");
            }
        } catch (Exception e) {
            System.out.println("Error en consulta de id Linea "+e);
        }
        
        return idLinea;
    }
    
    
    
    public void llenarCob_buscarSubLinea(JComboBox cob_buscarSubLinea){
        Conexion conexion = new Conexion();
        sql = " SELECT SubLineaDescripcion FROM sublineaproducto ORDER BY SubLineaDescripcion ASC ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            cob_buscarSubLinea.addItem("- Buscar Sub Linea -");
            while (rs.next()) {                
                cob_buscarSubLinea.addItem(rs.getString("SubLineaDescripcion"));
            }
        } catch (Exception e) {
            System.out.println("Error al cargar ComboBox de Sub Linea "+e);
        }
    }
    
    public void llenarCob_Linea(JComboBox cob_Linea){
        Conexion conexion = new Conexion();
        sql = " SELECT LineaDescripcion FROM lineaproducto WHERE estado LIKE 'Activo' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            cob_Linea.addItem("- Seleccionar Línea -");
            while (rs.next()) {                
                cob_Linea.addItem(rs.getString("LineaDescripcion"));
            }
        } catch (Exception e) {
            System.out.println("Error al cargar ComboBox de Linea "+e);
        }
    }
    
    
    private int IdSubLinea(){
        int idSubLinea = 0;
        Conexion conexion = new Conexion();
        sql = " SELECT MAX(IdSubLinea) AS idSubLinea FROM sublineaproducto ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            while (rs.next()) {                
                idSubLinea = rs.getInt("idSubLinea");
            }
        } catch (Exception e) {
            System.out.println("Error en el contador de idSubLinea producto "+e);
        }
        return idSubLinea;
    }
}
