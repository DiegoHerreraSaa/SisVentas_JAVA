
package controlador;

import conexion.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.*;

public class Control_barrio {
    
    private String sql = "";
    
    public void guardar(Modelo_barrio barrio){
        
        Conexion conexion = new Conexion();
        sql = " INSERT INTO barrio VALUES ( "+(Contador_barrio()+1)+", '"+barrio.getNombre()+"', '"+barrio.getComuna()+"' ) ";
        
        if (conexion.ejecutar(sql)) {
            JOptionPane.showMessageDialog(null, "Registro de barrio exitoso");
        }else{
            JOptionPane.showMessageDialog(null, "Registro de barrio no exitoso");
        }
        
        // Cerrar Conexion?
    }
    
    public int Contador_barrio(){
        int idBarrio = 0;
        
        Conexion conexion = new Conexion();
        sql = " SELECT MAX(IdBarrio) AS idBarrio FROM barrio ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            while (rs.next()) {                
                idBarrio = rs.getInt("idBarrio");
            }
        } catch (SQLException ex) {
            System.out.println("Error en el contador "+ex);
        }
        
        return idBarrio;
    }
    
}
