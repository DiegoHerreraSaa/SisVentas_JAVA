
package controlador;

import conexion.Conexion;
import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.Modelo_cargos;

public class Control_cargos {
    
    private String sql;
    
    public void nuevoCargo(Modelo_cargos dtsCargo){
        
        Conexion conexion = new Conexion();
        sql = " INSERT INTO cargos VALUES( '"+(Contador_cargo()+1)+"', '"+dtsCargo.getNombre()+"', "
                + " '"+dtsCargo.getDescripcion()+"', '"+dtsCargo.getEstado()+"' )";
        
        if(conexion.ejecutar(sql)){
            JOptionPane.showMessageDialog(null, "Registro de cargo exitoso");
        } else {
            JOptionPane.showMessageDialog(null, "Registro de cargo no exitoso");
        }
    }
    
    
    public void editarCargo(Modelo_cargos dtsCargo){
        Conexion conexion = new Conexion();
        sql = " UPDATE cargos SET Nombre = '"+dtsCargo.getNombre()+"', Descripcion = '"+dtsCargo.getDescripcion()+"', "
                + " estado = '"+dtsCargo.getEstado()+"' WHERE IdCargo LIKE '"+dtsCargo.getIdCargo()+"' ";
        
        if(conexion.ejecutar(sql)){
            JOptionPane.showMessageDialog(null, "El registro ha sido actualizado correctamente");
        } else {
            JOptionPane.showMessageDialog(null, "Error al actualizar registro");
        }
    }
    
    
//    public boolean eliminarCargo(Modelo_cargos dtsCargo){
//        
//        Conexion conexion = new Conexion();
//        sql = " DELETE FROM cargos WHERE Nombre LIKE '"+dtsCargo.getNombre()+"' ";
//        
//        if(conexion.ejecutar(sql)){
//            JOptionPane.showMessageDialog(null, "El cargo ha sido eliminado correctamente");
//        }else {
//            JOptionPane.showMessageDialog(null, "Error al eliminar cargo");
//        }
//        
//        return false;
//    }
    
    
    public void llenarCobCargo(JComboBox cob_rol){
        Conexion conexion = new Conexion();
        sql = " SELECT Nombre FROM cargos ORDER BY Nombre ASC";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            cob_rol.addItem("- Buscar Cargo -");
            while (rs.next()) {                
                cob_rol.addItem(rs.getString("Nombre"));
            }
        } catch (Exception e) {
            System.out.println("Error al cargar ComboBox de Cargos "+e);
        }
    }
    
    public int Contador_cargo(){
        int idCargo = 0;
        
        Conexion conexion = new Conexion();
        sql = " SELECT MAX(IdCargo) AS idCargo FROM cargos ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            while (rs.next()) {                
                idCargo = rs.getInt("idCargo");
            }
        } catch (Exception ex) {
            System.out.println("Error en el contador de cargo"+ex);
        }
        
        return idCargo;
    }
}
