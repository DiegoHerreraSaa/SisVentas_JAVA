
package controlador;

import conexion.Conexion;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.Modelo_detalleVenta;
import modelo.Modelo_factura;
import vista.Vista_factura;

public class Control_factura {
    
    private String sql;
    
    
    /* =======================================    CONTROL PARA TABLA FACTURA    ============================================================================ */
    
    public void nueva_Factura(Modelo_factura dtsFactura){
        Conexion conexion = new Conexion();
        sql = " INSERT INTO factura VALUES( '"+(idFactura()+1)+"', '"+buscar_idTipoFactura(dtsFactura)+"',"
                + " '"+dtsFactura.getFecha()+"', '"+dtsFactura.getHora()+"', "
                + " '"+dtsFactura.getCodigoCaja1()+"', '"+buscar_idEmpleado(dtsFactura)+"', "
                + " '"+buscar_idCliente(dtsFactura)+"' ) ";
        
        try {
            if(conexion.ejecutar(sql)){
                JOptionPane.showMessageDialog(null, "Registro de factura exitoso");
            }
        } catch (Exception e) {
            System.out.println("Error en el registro de factura "+e);
        }
    }
    
    // Fecha del sistema
    public String sistemaFecha(){
        String fechaActual;
        Date sisFecha = new Date();
        SimpleDateFormat formatoFecha = new SimpleDateFormat("YYYY-MM-dd");
        fechaActual = formatoFecha.format(sisFecha);
        return fechaActual;
    }
    
    
    // llenado ComboBox tipo factura
    public void llenarCob_tipoFactura(JComboBox cob_tipoFactura){
        Conexion conexion = new Conexion();
        sql = " SELECT descripcion FROM tipofactura ORDER BY descripcion ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            cob_tipoFactura.addItem("- Tipo de Factura -");
            while (rs.next()) {                
                cob_tipoFactura.addItem(rs.getString("descripcion"));
            }
        } catch (Exception e) {
            System.out.println("Error al cargar ComboBox tipo factura "+e);
        }
    }
    
    
    // Nombre del cliente
    public String buscarCliente(Modelo_factura dtsFactura){
        String nomCliente = "";
        Conexion conexion = new Conexion();
        sql = " SELECT CONCAT(Nombre, \" \", Apellido) AS nomCliente, estado FROM cliente "
                + " WHERE NumeroDocumento LIKE '"+dtsFactura.getNumDocCliente()+"' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            if (rs.next()) {
                if(rs.getString("estado").equals("Activo")){
                    nomCliente = rs.getString("nomCliente");
                }else{
                    JOptionPane.showMessageDialog(null, "El cliente se encuentra inactivo", "Alerta!",JOptionPane.WARNING_MESSAGE);
                    nomCliente = "CLIENTE DE MOSTRADOR";
                }
            }else{
                JOptionPane.showMessageDialog(null, "El cliente no se encuentra registrado", "Alerta!",JOptionPane.WARNING_MESSAGE);
                nomCliente = "CLIENTE DE MOSTRADOR";
            }
        } catch (Exception e) {
            System.out.println("Error en la busqueda del cliente "+e);
        }
        return nomCliente;
    }
    
    
    // Datos artículos
    public void buscarArticulos(Modelo_detalleVenta dtsVenta){
        Conexion conexion = new Conexion();
        sql = " SELECT * FROM articulo WHERE CodigoArticulo = '"+dtsVenta.getCodigoArticulo1()+"' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            if (rs.next()) {
                if(rs.getString("estado").equals("Activo")){
                    dtsVenta.setNomArticulo(rs.getString("Descripcion"));
                    dtsVenta.setPrecioFinal1(Double.parseDouble(rs.getString("PrecioFinal")));
                    dtsVenta.setPorIva(rs.getString("Iva"));
                    dtsVenta.setPorDscto(rs.getString("PorcentajeDescuento"));
                }else{
                    JOptionPane.showMessageDialog(null, "El producto se encuentra Inactivo", "Alerta!", JOptionPane.WARNING_MESSAGE);
                }
            }
        } catch (Exception e) {
            System.out.println("Error al consultar los datos del artículo "+e);
        }
    }
    
    // Calcular Sub Total
    public Double subTotal(Modelo_detalleVenta dtsVenta){
        double Subtotal = dtsVenta.getPrecioFinal1()*dtsVenta.getCantidad();
        // System.out.println(Subtotal);
        return Subtotal;
    }
    
    
    // Contador idFactura
    public int idFactura(){
        int idfactura = 0;
        Conexion conexion = new Conexion();
        sql = " SELECT MAX(IdFactura) AS idFactura FROM factura ";
        ResultSet rs = conexion.consultar(sql);
        try {
            if(rs.next()){
                idfactura = rs.getInt("idFactura");
            }
        } catch (Exception e) {
            System.out.println("Error en consulta id Factura "+e);
        }
        return idfactura;
    }
    
    
    // Buscar id tipo factura
    public int buscar_idTipoFactura(Modelo_factura dtsFactura){
        int idFactura = 0;
        Conexion conexion = new Conexion();
        sql = "  SELECT idTipoFactura FROM tipofactura WHERE descripcion "
                + " LIKE '"+dtsFactura.getTipoFactura()+"' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            if(rs.next()){
                idFactura = rs.getInt("idTipoFactura");
            }else{
                System.out.println("Error al consultar id tipo factura");
            }
        } catch (Exception e) {
            System.out.println("Error al consultar id tipo factura "+e);
        }
        return idFactura;
    }
    
    
    // Buscar id empleado
    public int buscar_idEmpleado(Modelo_factura dtsFactura){
        int idEmpleado = 0;
        Conexion conexion = new Conexion();
        sql = "  SELECT IdEmpleados FROM empleados WHERE CONCAT(PrimerNombre,\" \",PrimerApellido,\" \",SegundoApellido)"
                + " LIKE '"+dtsFactura.getNomEmpleado()+"' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            if(rs.next()){
                idEmpleado = rs.getInt("IdEmpleados");
            }else{
                System.out.println("Error al consultar id empleado");
            }
        } catch (Exception e) {
            System.out.println("Error al consultar id empleado"+e);
        }
        return idEmpleado;
    }
    
    
    // Buscar Codigo cliente
    public int buscar_idCliente(Modelo_factura dtsFactura){
        int idCliente = 0;
        Conexion conexion = new Conexion();
        sql = "  SELECT CodigoCliente FROM cliente WHERE CONCAT(Nombre,\" \",Apellido)"
                + " LIKE '"+dtsFactura.getNomCliente()+"' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            if(rs.next()){
                idCliente = rs.getInt("CodigoCliente");
            }else{
                System.out.println("Error al consultar id Cliente");
            }
        } catch (Exception e) {
            System.out.println("Error al consultar id Cliente"+e);
        }
        return idCliente;
    }
    
    public int existe_articulo(Modelo_detalleVenta dtsVenta){
        int existe = 0;
        Conexion conexion = new Conexion();
        sql = " SELECT Descripcion FROM articulo WHERE CodigoArticulo = '"+dtsVenta.getCodigoArticulo1()+"' && estado = 'Activo' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            if(rs.next()){
                existe = 1;
            }
        } catch (Exception e) {
            System.out.println("Error al consultar existencia de producto "+e);
        }
        return existe;
    }
    
    
    // ============================= CLIENTE 0 POR DEFECTO  ========================
    
    public String cliente_mostrador(){
        String cMotrador = "";
        Conexion conexion = new Conexion();
        sql = " SELECT CONCAT(Nombre, \" \", Apellido) AS nomCliente FROM cliente WHERE NumeroDocumento LIKE 0 ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            if(rs.next()){
                cMotrador = rs.getString("nomCliente");
            }
        } catch (Exception e) {
            System.out.println("Error en la consulta cliente mostrador "+e);
        }
        return cMotrador;
    }
    
    // ============================= SUMAR COLUMNAS CANTIDAD Y SUBTOTAL ========================
    
    public void suma_Cantidad(){
        int fila = 0;
        int total = 0;
        for(int i = 0; i < Vista_factura.tabla_detalleVta.getRowCount(); i++){
            fila = Integer.parseInt(Vista_factura.tabla_detalleVta.getValueAt(i,5).toString());
            total += fila;
        }
        Vista_factura.lbl_totalRegistros.setText(Integer.toString(total));
    }
    
    public void suma_PagoTotal(){
        double fila = 0;
        double total = 0;
        for(int i = 0; i < Vista_factura.tabla_detalleVta.getRowCount(); i++){
            fila = Double.parseDouble(Vista_factura.tabla_detalleVta.getValueAt(i,6).toString());
            total += fila;
        }
        Vista_factura.lbl_totalPagar.setText(Double.toString(total));
    }
    
    public int Contador_dtalleventa() {
        int idDvta = 0;

        Conexion conexion = new Conexion();
        sql = " SELECT MAX(idDetalleVenta) AS idDventa FROM detalleventa ";
        ResultSet rs = conexion.consultar(sql);

        try {
            while (rs.next()) {
                idDvta = rs.getInt("idDventa");
            }
        } catch (Exception ex) {
            System.out.println("Error en el contador CodigoCliente" + ex);
        }

        return idDvta;
    }
}
