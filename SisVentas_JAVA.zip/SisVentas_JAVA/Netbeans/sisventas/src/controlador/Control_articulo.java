
package controlador;

import conexion.Conexion;
import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Modelo_articulo;

public class Control_articulo {
    
    private String sql;
    public Integer totalregistros;
    
    
    
    public DefaultTableModel mostrar_articulos(String buscar){
        
        DefaultTableModel modelo;
        
        String[] titulos = {"Código","Descripción","Precio","Costo","Iva","Precio Iva","%Dsct","Descuento","Precio Final","Proveedor","Sub Línea","Estado"};
        
        String[] registros = new String[12];
        
        totalregistros = 0;
        
        modelo = new DefaultTableModel(null, titulos);
        
        Conexion conexion = new Conexion();
        sql = " SELECT a.*, p.Nombre AS proveedor, sl.SubLineaDescripcion AS subLinea FROM articulo a "
                + " JOIN proveedores p ON p.IdProveedor = a.IdProveedor1 "
                + " JOIN sublineaproducto sl ON sl.IdSubLinea = a.IdSublinea1 "
                + " WHERE a.Descripcion LIKE '%"+buscar+"%' ORDER BY a.CodigoArticulo DESC ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            while (rs.next()) {                
                registros[0] = rs.getString("CodigoArticulo");
                registros[1] = rs.getString("Descripcion");
                registros[2] = rs.getString("Precio");
                registros[3] = rs.getString("Costo");
                registros[4] = rs.getString("Iva");
                registros[5] = rs.getString("PrecioIva");
                registros[6] = rs.getString("PorcentajeDescuento");
                registros[7] = rs.getString("Descuento");
                registros[8] = rs.getString("PrecioFinal");
                registros[9] = rs.getString("proveedor");
                registros[10] = rs.getString("subLinea");
                registros[11] = rs.getString("estado");
                
                totalregistros+=1;
                modelo.addRow(registros);
            }
            return modelo;
        } catch (Exception e) {
            System.out.println("Error al cargar tabla "+e);
            return null;
        }
    }
    
    
    public double precioIva(Modelo_articulo dtsArticulo){
        double PrecioIva = dtsArticulo.getPrecio()*(((dtsArticulo.getIva())/100)+1);
        return PrecioIva;
    }
    
    public double descuento(Modelo_articulo dtsArticulo){
        double desc = dtsArticulo.getPrecio()*((dtsArticulo.getPorcentajeDescuento())/100);
        return desc;
    }
    
    public double precioFinal(Modelo_articulo dtsArticulo){
        double pFinal = dtsArticulo.getPrecioIva()-(dtsArticulo.getDescuento());
        return pFinal;
    }
    
    
    public void nuevo_articulo(Modelo_articulo dtsArticulo){
        Conexion conexion = new Conexion();
        sql = " INSERT INTO articulo VALUES( '"+(codigo_Articulo()+1)+"', '"+dtsArticulo.getDescripcion()+"', "
                + " '"+dtsArticulo.getPrecio()+"', '"+dtsArticulo.getCosto()+"', '"+dtsArticulo.getIva()+"', "
                + " '"+dtsArticulo.getPrecioIva()+"', '"+dtsArticulo.getPorcentajeDescuento()+"', '"+dtsArticulo.getDescuento()+"', "
                + " '"+dtsArticulo.getPrecioFinal()+"', '"+consultar_idProveedor(dtsArticulo)+"', '"+consultar_idSubLinea(dtsArticulo)+"', "
                + " '"+dtsArticulo.getEstado()+"' ) ";
        
        try {
            if(conexion.ejecutar(sql)){
                JOptionPane.showMessageDialog(null, "Registro de artículo exitoso");
            }else{
                JOptionPane.showMessageDialog(null, "Error al registrar artículo");
            }
        } catch (Exception e) {
            System.out.println("Error al registrar artículo "+e);
        }
    }
    
    
    
    public void editar_articulo(Modelo_articulo dtsArticulo){
        Conexion conexion = new Conexion();
        sql = " UPDATE articulo SET Descripcion = '"+dtsArticulo.getDescripcion()+"', "
                + " Precio = '"+dtsArticulo.getPrecio()+"', Costo = '"+dtsArticulo.getCosto()+"', Iva = '"+dtsArticulo.getIva()+"', PrecioIva = '"+dtsArticulo.getPrecioIva()+"', "
                + " PorcentajeDescuento = '"+dtsArticulo.getPorcentajeDescuento()+"', Descuento = '"+descuento(dtsArticulo)+"', "
                + " PrecioFinal = '"+precioFinal(dtsArticulo)+"', IdProveedor1 = '"+consultar_idProveedor(dtsArticulo)+"', IdSublinea1 = '"+consultar_idSubLinea(dtsArticulo)+"', "
                + " estado = '"+dtsArticulo.getEstado()+"' WHERE CodigoArticulo LIKE '"+dtsArticulo.getCodigoArticulo()+"' ";
        
        try {
            if(conexion.ejecutar(sql)){
                JOptionPane.showMessageDialog(null, "El artículo ha sido editado correctamente");
            }else{
                JOptionPane.showMessageDialog(null, "Error al editar el artículo");
            }
        } catch (Exception e) {
            System.out.println("Error al editar el artículo "+e);
        }
    }
    
    
    
    private String consultar_idProveedor(Modelo_articulo dtsArticulo){
        String idProveedor = "";
        Conexion conexion = new Conexion();
        sql = " SELECT IdProveedor FROM proveedores WHERE Nombre LIKE '"+dtsArticulo.getNomProveedor()+"' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            while(rs.next()){
                idProveedor = rs.getString("IdProveedor");
            }
        } catch (Exception e) {
            System.out.println("Error la consulta de id Proveedor " + e);
        }
        return idProveedor;
    }
    
    
    
    
    private String consultar_idSubLinea(Modelo_articulo dtsArticulo){
        String idSubLinea = "";
        Conexion conexion = new Conexion();
        sql = " SELECT IdSubLinea FROM sublineaproducto WHERE SubLineaDescripcion LIKE '"+dtsArticulo.getNomSubLinea()+"' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            while(rs.next()){
                idSubLinea = rs.getString("IdSubLinea");
            }
        } catch (Exception e) {
            System.out.println("Error la consulta de id Sub Línea " + e);
        }
        return idSubLinea;
    }
    
    public int codigo_Articulo(){
        int codArticulo = 0;
        Conexion conexion = new Conexion();
        sql = " SELECT MAX(CodigoArticulo) AS codArt FROM articulo ";
        ResultSet rs = conexion.consultar(sql);
        try {
            if(rs.next()){
                codArticulo = rs.getInt("codArt");
            }
        } catch (Exception e) {
            System.out.println("Error al consultar el Código del artículo "+e);
        }
        return codArticulo;
    }
    
    
    public int existe_producto(Modelo_articulo dtsArticulo){
        int existeArt = 0;
        Conexion conexion = new Conexion();
        sql = " SELECT Descripcion FROM articulo WHERE  ";
        ResultSet rs = conexion.consultar(sql);
        try {
            if(rs.next()){
                existeArt = 1;
            }
        } catch (Exception e) {
            System.out.println("Error al consultar si existe artículo "+e);
        }
        return existeArt;
    }
    
    
    /* ================ LLENADO COMBOBOX =============== */
    
    public void llenarCob_subLinea(JComboBox cob_subLinea){
        Conexion conexion = new Conexion();
        sql = " SELECT SubLineaDescripcion FROM sublineaproducto WHERE estado = 'Activo' ORDER BY SubLineaDescripcion ASC ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            cob_subLinea.addItem("- Seleccionar Sub Línea -");
            while (rs.next()) {                
                cob_subLinea.addItem(rs.getString("SubLineaDescripcion"));
            }
        } catch (Exception e) {
            System.out.println("Error al cargar ComboBox de Sub Línea "+e);
        }
    }
    
    public void llenarCob_proveedor(JComboBox cob_proveedor){
        Conexion conexion = new Conexion();
        sql = " SELECT Nombre AS NomProveedor FROM proveedores WHERE estado = 'Activo' ORDER BY NomProveedor ASC ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            cob_proveedor.addItem("- Seleccionar Proveedor -");
            while (rs.next()) {                
                cob_proveedor.addItem(rs.getString("NomProveedor"));
            }
        } catch (Exception e) {
            System.out.println("Error al cargar ComboBox de Proveedor "+e);
        }
    }
}
