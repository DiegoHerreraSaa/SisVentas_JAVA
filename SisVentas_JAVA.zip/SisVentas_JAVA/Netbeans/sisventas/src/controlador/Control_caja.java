
package controlador;

import conexion.Conexion;
import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.Modelo_caja;

public class Control_caja {
    
    private String sql;
    
    public void nuevaCaja(Modelo_caja dtsCaja){
        
        Conexion conexion = new Conexion();
        sql = " INSERT INTO caja VALUES('"+(cont_idCaja()+1)+"', '"+buscarIdtipoCaja(dtsCaja)+"', "
                + " '"+dtsCaja.getUbicacion()+"', '"+dtsCaja.getDescripcion()+"', '"+dtsCaja.getEstado()+"' ) ";
        
        if(conexion.ejecutar(sql)){
            JOptionPane.showMessageDialog(null, "Registro de caja exitoso");
        }else{
            JOptionPane.showMessageDialog(null, "Error al crear caja");
        }
    }
    
    
    public void editarCaja(Modelo_caja dtsCaja){
        Conexion conexion = new Conexion();
        sql = " UPDATE caja SET IdTipoCaja1 = '"+buscarIdtipoCaja(dtsCaja)+"', Ubicacion = '"+dtsCaja.getUbicacion()+"', "
                + " Descripcion = '"+dtsCaja.getDescripcion()+"', estado = '"+dtsCaja.getEstado()+"' "
                + " WHERE CodigoCaja LIKE '"+dtsCaja.getCodigoCaja()+"' ";
        
        if(conexion.ejecutar(sql)){
            JOptionPane.showMessageDialog(null, "La caja ha sido modificada correctamente");
        }else{
            JOptionPane.showMessageDialog(null, "Error al modificar la caja");
        }
    }
    
    
    public boolean eliminarCaja(Modelo_caja dtsCaja){
        
        Conexion conexion = new Conexion();
        sql = " DELETE FROM caja WHERE CodigoCaja LIKE '"+dtsCaja.getCodigoCaja()+"' ";
        
        if(conexion.ejecutar(sql)){
            JOptionPane.showMessageDialog(null, "La caja ha sido eliminada");
        }else{
            JOptionPane.showMessageDialog(null, "Error al eliminar la caja");
        }
        
        return false;
    }
    
    
    public int buscarIdtipoCaja(Modelo_caja dtsCaja){
        int idTipoCaja = 0;
        Conexion conexion = new Conexion();
        sql = " SELECT IdTipoCaja FROM tipocaja WHERE Nombre LIKE '"+dtsCaja.getTipoCaja()+"' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            while (rs.next()) {                
                idTipoCaja = Integer.parseInt(rs.getString("IdTipoCaja"));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar id Tipo caja "+e);
        }
        return idTipoCaja;
    }
    
    
    
    
    
    public void llenarCobIdTipoCaja(JComboBox cob_idTipoCaja){
        Conexion conexion = new Conexion();
        sql = " SELECT Nombre FROM tipocaja WHERE estado LIKE 'Activo' ORDER BY Nombre ASC ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            cob_idTipoCaja.addItem("- Tipo Caja -");
            while (rs.next()) {                
                cob_idTipoCaja.addItem(rs.getString("Nombre"));
            }
        } catch (Exception e) {
            System.out.println("Error el consultar nombre tipo caja "+e);
        }
    }
    
    
    
    
    public void llenarCob_codCaja(JComboBox cob_codCaja){
        Conexion conexion = new Conexion();
        sql = " SELECT CodigoCaja FROM caja ORDER BY CodigoCaja ASC ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            cob_codCaja.addItem("Buscar");
            while (rs.next()) {                
                cob_codCaja.addItem(rs.getString("CodigoCaja"));
            }
        } catch (Exception e) {
            System.out.println("Error el consultar Codigo de caja "+e);
        }
    }
    
    public int cont_idCaja(){
        int idCaja=0;
        Conexion conexion = new Conexion();
        sql = " SELECT MAX(CodigoCaja) AS idCaja FROM caja ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            if(rs.next()){
                idCaja = rs.getInt("idCaja");
            }
        } catch (Exception e) {
            System.out.println("Error en el contador Id Caja "+e);
        }
        return idCaja;
    }
    
}
