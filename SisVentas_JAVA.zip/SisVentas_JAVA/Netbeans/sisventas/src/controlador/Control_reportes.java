package controlador;

import conexion.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class Control_reportes {

    private String sql;
    public int totalregistros;
    private String codCli = "";

    // REPORTE DE CLIENTE ============================================================================
    public DefaultTableModel mostrar_articulos(String buscar, String tipoFact) {

        DefaultTableModel modelo;

        String[] titulos = {"Nom Cliente", "Identificación", "Factura", "Tipo Fact", "Fecha", "Artículo", "Iva", "%Dsct", "Precio Unid", "Cant", "SubTotal"};

        String[] registros = new String[11];

        totalregistros = 0;

        modelo = new DefaultTableModel(null, titulos);

        Conexion conexion = new Conexion();
        sql = " SELECT CONCAT(c.Nombre,\" \",c.Apellido) AS nomCliente, c.NumeroDocumento, f.IdFactura, "
                + " f.Fecha, f.idTipoFactura1, a.Descripcion, a.Iva,a.PorcentajeDescuento, dv.precioUnid, dv.cantidad, dv.subTotal "
                + " FROM factura f JOIN detalleventa dv ON dv.idFactura1 = f.IdFactura "
                + " JOIN cliente c ON c.CodigoCliente = f.CodigoCliente1 "
                + " JOIN articulo a ON a.CodigoArticulo = dv.CodigoArticulo1 "
                + " WHERE c.NumeroDocumento LIKE '" + buscar + "' AND f.idTipoFactura1 = '" + tipoFact +"' "
                + " ORDER BY a.Descripcion DESC ";
        ResultSet rs = conexion.consultar(sql);

        try {
            while (rs.next()) {
                registros[0] = rs.getString("nomCliente");
                registros[1] = rs.getString("NumeroDocumento");
                registros[2] = rs.getString("IdFactura");
                registros[3] = rs.getString("idTipoFactura1");
                registros[4] = rs.getString("Fecha");
                registros[5] = rs.getString("Descripcion");
                registros[6] = rs.getString("Iva");
                registros[7] = rs.getString("PorcentajeDescuento");
                registros[8] = rs.getString("precioUnid");
                registros[9] = rs.getString("cantidad");
                registros[10] = rs.getString("subTotal");

                totalregistros += 1;
                modelo.addRow(registros);
            }
            return modelo;
        } catch (Exception e) {
            System.out.println("Error al cargar tabla en control reportes de cliente " + e);
            return null;
        }
    }

    public void consultar_codCliente(String codCliente) {
        Conexion conexion = new Conexion();
        sql = " SELECT CodigoCliente FROM cliente WHERE NumeroDocumento LIKE '" + codCliente + "' ";
        ResultSet rs = conexion.consultar(sql);

        try {
            if (rs.next()) {
                codCli = rs.getString("CodigoCliente");
            }
        } catch (Exception e) {
            System.out.println("Error al consultar código de cliente " + e);
        }
    }

    public int consultar_exiteDv() {
        int existe = 0;
        Conexion conexion = new Conexion();
        sql = " SELECT DISTINCT idTipoFactura1 FROM factura WHERE CodigoCliente1 LIKE '" + codCli + "' ";

        try {
            if (conexion.consultar(sql).next()) {
                existe = 1;
            } 
        } catch (SQLException e) {
            System.out.println("Error al consular existencia de cliente en reporte " + e);
        }
        return existe;
    }

    // REPORTE DE ARTÍCULO por fecha ============================================================================
    
    public DefaultTableModel mostrar_articulosFecha(String Desde, String Hasta) {

        DefaultTableModel modelo;

        String[] titulos = {"Nom Cliente", "Identificación", "Factura", "Tipo Fact", "Fecha", "Artículo", "Iva", "%Dsct", "Precio Unid", "Cant", "SubTotal"};

        String[] registros = new String[11];

        totalregistros = 0;

        modelo = new DefaultTableModel(null, titulos);

        Conexion conexion = new Conexion();
        sql = " SELECT CONCAT(c.Nombre,\" \",c.Apellido) AS nomCliente, c.NumeroDocumento, f.IdFactura, "
                + " f.Fecha, f.idTipoFactura1, a.Descripcion, a.Iva,a.PorcentajeDescuento, dv.precioUnid, dv.cantidad, dv.subTotal "
                + " FROM factura f JOIN detalleventa dv ON dv.idFactura1 = f.IdFactura "
                + " JOIN cliente c ON c.CodigoCliente = f.CodigoCliente1 "
                + " JOIN articulo a ON a.CodigoArticulo = dv.CodigoArticulo1 "
                + " WHERE f.Fecha BETWEEN '" + Desde + "' AND '" + Hasta + "' ORDER BY f.Fecha DESC ";
        ResultSet rs = conexion.consultar(sql);

        try {
            while (rs.next()) {
                registros[0] = rs.getString("nomCliente");
                registros[1] = rs.getString("NumeroDocumento");
                registros[2] = rs.getString("IdFactura");
                registros[3] = rs.getString("idTipoFactura1");
                registros[4] = rs.getString("Fecha");
                registros[5] = rs.getString("Descripcion");
                registros[6] = rs.getString("Iva");
                registros[7] = rs.getString("PorcentajeDescuento");
                registros[8] = rs.getString("precioUnid");
                registros[9] = rs.getString("cantidad");
                registros[10] = rs.getString("subTotal");

                totalregistros += 1;
                modelo.addRow(registros);
            }
            return modelo;
        } catch (Exception e) {
            System.out.println("Error al cargar tabla en control reportes de artículos " + e);
            return null;
        }
    }
    
    public int existe_Fecha(String fDesde, String fHasta){
        int existe = 0;
        Conexion conexion = new Conexion();
        sql = " SELECT IdFactura FROM factura WHERE Fecha BETWEEN '" + fDesde + "' AND '" + fHasta + "' ";
        ResultSet rs = conexion.consultar(sql);
        
        try {
            if(rs.next()){
                existe = 1;
            }
        } catch (Exception e) {
            System.out.println("Error al consultar ecistenca de fechas "+e);
        }
        return existe;
    }

}
