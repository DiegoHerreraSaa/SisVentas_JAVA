package controlador;

import conexion.Conexion;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.Modelo_cliente;

public class Control_cliente {

    private String sql;

    // Guardar Registro
    public void nuevoCliente(Modelo_cliente dtsCliente) {

        Conexion conexion = new Conexion();
        sql = " INSERT INTO cliente VALUES( '" + (Contador_cliente() + 1) + "','" + dtsCliente.getIdTipoIdentidad1() + "', "
                + " '" + dtsCliente.getNumeroDocumento() + "', '" + dtsCliente.getNombre() + "', '" + dtsCliente.getApellido() + "', "
                + " '" + dtsCliente.getGenero() + "', '" + dtsCliente.getFechaNacimiento() + "', '" + dtsCliente.getDireccion() + "', "
                + " '" + dtsCliente.getTelefono() + "', '" + dtsCliente.getEmail() + "', '" + Consultar_idBarrioCliente(dtsCliente) + "', "
                + " '" + Consultar_idCiudadCliente(dtsCliente) + "', '"+dtsCliente.getEstado()+"' )";

        if (conexion.ejecutar(sql)) {
            JOptionPane.showMessageDialog(null, "Registro de cliente exitoso");
        } else {
            JOptionPane.showMessageDialog(null, "Error al crear Cliente");
        }
    }
    
    public void editarCliente(Modelo_cliente dtsCliente){
        Conexion conexion = new Conexion();
        sql = " UPDATE cliente SET IdTipoIdentidad1 = '"+dtsCliente.getIdTipoIdentidad1()+"', NumeroDocumento = '"+dtsCliente.getNumeroDocumento()+"', "
                + " Nombre = '"+dtsCliente.getNombre()+"', Apellido = '"+dtsCliente.getApellido()+"', Genero = '"+dtsCliente.getGenero()+"', "
                + " FechaNacimiento = '"+dtsCliente.getFechaNacimiento()+"', Direccion = '"+dtsCliente.getDireccion()+"', "
                + " Telefono = '"+dtsCliente.getTelefono()+"', Email = '"+dtsCliente.getEmail()+"', IdBarrio1 = '"+Consultar_idBarrioCliente(dtsCliente)+"', "
                + " CodigoCiudad1 = '"+Consultar_idCiudadCliente(dtsCliente)+"', estado = '"+dtsCliente.getEstado()+"' "
                + " WHERE CodigoCliente = '"+dtsCliente.getCodigoCliente()+"' ";
        
        if (conexion.ejecutar(sql)) {
            JOptionPane.showMessageDialog(null, "Registro editado correctamente");
        } else {
            JOptionPane.showMessageDialog(null, "Hubo algún error en la edición de registro");
        }
    }
    
    
    public int consulta_existe(Modelo_cliente dtsCliente){
        int existe = 0;
        Conexion conexion = new Conexion();
        sql = " SELECT CodigoCliente FROM cliente WHERE NumeroDocumento LIKE '"+dtsCliente.getNumeroDocumento()+"' ";
        ResultSet rs = conexion.consultar(sql);
        try {
            if(rs.next()){
                existe = 1;
            }
        } catch (Exception e) {
            System.out.println("Error al consultar existencia de cliente "+e);
        }
        return existe;
    }
    
    
//    public boolean eliminarCliente(Modelo_cliente dtsCliente){
//        Conexion conexion = new Conexion();
//        sql = " DELETE FROM cliente WHERE NumeroDocumento = '"+dtsCliente.getNumeroDocumento()+"'";
//        
//        if (conexion.ejecutar(sql)) {
//            JOptionPane.showMessageDialog(null, "El cliente ha sido eliminado correctamente");
//        } else {
//            JOptionPane.showMessageDialog(null, "Hubo un error al eliminar el cliente");
//        }
//        
//        return false;
//    }
    

    /* =========================================================================================================== */
    
    // Cargas de ComboBox
    
    // LLENAR ARRAYLIST PARA ENVIAR DESPUES AL COMBOBOX de tipo de identidad y captura el idTipoIdentidad
    public ArrayList<Modelo_cliente> consulta_tipoIdentidad() {
        Conexion conexion = new Conexion();
        sql = " SELECT IdTipoIdentidad as id, NombreTipoIdentidad as nombre FROM tipoidentidad ";
        ResultSet rs = conexion.consultar(sql);
        ArrayList<Modelo_cliente> datos = new ArrayList<>();
        try {

            while (rs.next()) {
                Modelo_cliente modelo = new Modelo_cliente();
                modelo.setIdTipoIdentidad1(rs.getString("id"));
                modelo.setNombre_tipo(rs.getString("nombre"));
                datos.add(modelo);
            }

        } catch (Exception e) {
            System.out.println("Error al cargar ComboBox tipo identidad Cliente" + e);
        }
        return datos;
    }

    // Cargar barrio
    public void Consultar_barrio(JComboBox cob_barrioCliente) {

        Conexion conexion = new Conexion();
        sql = " SELECT Nombre FROM barrio ORDER BY Nombre ASC ";
        ResultSet rs = conexion.consultar(sql);

        try {
            cob_barrioCliente.addItem("- Barrio -");
            while (rs.next()) {
                cob_barrioCliente.addItem(rs.getString("Nombre"));
            }
        } catch (Exception e) {
            System.out.println("Error en consulta de ComboBox barrio Cliente " + e);
        }

    }

    // Cargar ciudad
    public void Consultar_ciudad(JComboBox cob_ciudadCliente) {

        Conexion conexion = new Conexion();
        sql = " SELECT CONCAT(Nombre,\" - \",Departamento) AS ciuDep FROM ciudad ORDER BY Nombre ASC ";
        ResultSet rs = conexion.consultar(sql);

        try {
            cob_ciudadCliente.addItem("- Ciudad -");
            while (rs.next()) {
                cob_ciudadCliente.addItem(rs.getString("ciuDep"));
            }
        } catch (Exception e) {
            System.out.println("Error en consulta de ComboBox ciudad Cliente" + e);
        }

    }

    // Carga de codigo de barrio y ciudad
    public int Consultar_idBarrioCliente(Modelo_cliente dts) {

        int idBarrioCliente = 0;

        Conexion conexion = new Conexion();
        sql = " SELECT IdBarrio FROM barrio WHERE Nombre LIKE '" + dts.getBarrioCliente()+ "' ";
        ResultSet rs = conexion.consultar(sql);

        try {
            while (rs.next()) {
                idBarrioCliente = rs.getInt("IdBarrio");
            }
        } catch (Exception e) {
            System.out.println("Error en consulta de id barrio cliente " + e);
        }

        return idBarrioCliente;

    }

    public int Consultar_idCiudadCliente(Modelo_cliente dts) {

        int idCiudadCliente = 0;

        Conexion conexion = new Conexion();
        sql = " SELECT CodigoCiudad FROM ciudad WHERE CONCAT(Nombre,\" - \",Departamento) LIKE '" + dts.getCiudadCliente()+ "' ";
        ResultSet rs = conexion.consultar(sql);

        try {
            while (rs.next()) {
                idCiudadCliente = rs.getInt("CodigoCiudad");
            }
        } catch (Exception e) {
            System.out.println("Error en consulta de id ciudad cliente " + e);
        }

        return idCiudadCliente;

    }

    /* =========================================================================================================== */
    
    public int Contador_cliente() {
        int idCliente = 0;

        Conexion conexion = new Conexion();
        sql = " SELECT MAX(CodigoCliente) AS idCliente FROM cliente ";
        ResultSet rs = conexion.consultar(sql);

        try {
            while (rs.next()) {
                idCliente = rs.getInt("idCliente");
            }
        } catch (Exception ex) {
            System.out.println("Error en el contador CodigoCliente" + ex);
        }

        return idCliente;
    }

}