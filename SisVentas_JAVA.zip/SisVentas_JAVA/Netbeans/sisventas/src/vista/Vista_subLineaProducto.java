package vista;

import controlador.Control_subLineaProducto;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import modelo.Modelo_subLineaProducto;

public class Vista_subLineaProducto extends javax.swing.JInternalFrame {

    private String accion;
    Control_subLineaProducto control = new Control_subLineaProducto();
    Modelo_subLineaProducto dtsSubLinea = new Modelo_subLineaProducto();

    public Vista_subLineaProducto() {
        initComponents();
        setTitle("Sub líneas de producto");

        inhabilitar();
        control.llenarCob_Linea(cob_Linea);
        control.llenarCob_buscarSubLinea(cob_buscarSubLinea);

    }

    void inhabilitar() {
        txt_idSublLinea.setVisible(false);

        txt_nomSubLinea.setEnabled(false);
        cob_Linea.setEnabled(false);
        cob_estado.setEnabled(false);

        btn_guardar.setEnabled(false);

        txt_idSublLinea.setText("");
        txt_nomSubLinea.setText("");
        btn_guardar.setText("Guardar");
        cob_Linea.setSelectedItem("- Seleccionar Línea -");
        cob_buscarSubLinea.setSelectedItem("- Buscar Sub Linea -");
        cob_estado.setSelectedItem("Activo");
    }

    void habilitar() {
        txt_idSublLinea.setVisible(false);

        txt_nomSubLinea.setEnabled(true);
        cob_Linea.setEnabled(true);
        cob_estado.setEnabled(true);

        btn_guardar.setEnabled(true);

        txt_idSublLinea.setText("");
        txt_nomSubLinea.setText("");
        btn_guardar.setText("Guardar");
        cob_Linea.setSelectedItem("- Seleccionar Línea -");
        cob_buscarSubLinea.setSelectedItem("- Buscar Sub Linea -");
        cob_estado.setSelectedItem("Activo");
    }
    
    void buscarSubLinea(){
        
        if (cob_buscarSubLinea.getSelectedItem().toString().equals("- Buscar Sub Linea -")) {
            JOptionPane.showMessageDialog(null, "Selecciona una sub línea a buscar");
            cob_buscarSubLinea.requestFocus();
            return;
        }

        dtsSubLinea.setSubLineaDescripcion(cob_buscarSubLinea.getSelectedItem().toString());

        habilitar();

        control.mostrar_busqueda(dtsSubLinea);

        txt_idSublLinea.setText(dtsSubLinea.getIdSubLinea().toString());
        txt_nomSubLinea.setText(dtsSubLinea.getSubLineaDescripcion());
        cob_Linea.setSelectedItem(dtsSubLinea.getNomLinea());
        cob_estado.setSelectedItem(dtsSubLinea.getEstado());

        txt_nomSubLinea.requestFocus();

        btn_guardar.setText("Editar");
        accion = "editar";
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cob_buscarSubLinea = new javax.swing.JComboBox<>();
        cob_Linea = new javax.swing.JComboBox<>();
        txt_nomSubLinea = new javax.swing.JTextField();
        btn_buscar = new javax.swing.JButton();
        btn_nuevo = new javax.swing.JButton();
        btn_guardar = new javax.swing.JButton();
        txt_idSublLinea = new javax.swing.JTextField();
        cob_estado = new javax.swing.JComboBox<>();

        setClosable(true);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setIconifiable(true);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "ADMINISTRADOR SUB LINEA PRODUCTO", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 18), new java.awt.Color(255, 255, 255))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nombre: ");

        jLabel3.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Línea:");

        cob_buscarSubLinea.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cob_buscarSubLineaKeyPressed(evt);
            }
        });

        btn_buscar.setBackground(new java.awt.Color(51, 51, 51));
        btn_buscar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_buscar.setForeground(new java.awt.Color(255, 255, 255));
        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/search.png"))); // NOI18N
        btn_buscar.setText("Buscar");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });

        btn_nuevo.setBackground(new java.awt.Color(51, 51, 51));
        btn_nuevo.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_nuevo.setForeground(new java.awt.Color(255, 255, 255));
        btn_nuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/checkShadow.png"))); // NOI18N
        btn_nuevo.setText("Nuevo");
        btn_nuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nuevoActionPerformed(evt);
            }
        });

        btn_guardar.setBackground(new java.awt.Color(51, 51, 51));
        btn_guardar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_guardar.setForeground(new java.awt.Color(255, 255, 255));
        btn_guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/guardar.png"))); // NOI18N
        btn_guardar.setText("Guardar");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });

        cob_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(cob_buscarSubLinea, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(15, 15, 15)
                                .addComponent(btn_buscar))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(btn_nuevo)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btn_guardar)
                                    .addGap(213, 213, 213))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel3))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txt_nomSubLinea)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(cob_Linea, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(cob_estado, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(txt_idSublLinea, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(txt_idSublLinea, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cob_buscarSubLinea, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_buscar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_nomSubLinea, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cob_Linea)
                    .addComponent(cob_estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_nuevo)
                    .addComponent(btn_guardar))
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed

        buscarSubLinea();

    }//GEN-LAST:event_btn_buscarActionPerformed

    private void btn_nuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_nuevoActionPerformed

        habilitar();

        accion = "nuevo";
        txt_nomSubLinea.requestFocus();

    }//GEN-LAST:event_btn_nuevoActionPerformed

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed

        if (txt_nomSubLinea.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingresa el nombre de la Sub Línea de producto");
            txt_nomSubLinea.requestFocus();
            return;
        }
        if (cob_Linea.getSelectedItem().toString().equals("- Seleccionar Línea -")) {
            JOptionPane.showMessageDialog(null, "Selecciona una Línea");
            cob_Linea.requestFocus();
            return;
        }

        dtsSubLinea.setSubLineaDescripcion(txt_nomSubLinea.getText());
        dtsSubLinea.setNomLinea(cob_Linea.getSelectedItem().toString());
        dtsSubLinea.setEstado(cob_estado.getSelectedItem().toString());

        if (accion.equals("nuevo")) {
            control.nuevaSubLinea(dtsSubLinea);
            inhabilitar();
        } else if (accion.equals("editar")) {
            dtsSubLinea.setIdSubLinea(Integer.parseInt(txt_idSublLinea.getText()));
            control.editar_subLinea(dtsSubLinea);
            inhabilitar();
        }

        cob_buscarSubLinea.removeAllItems();
        control.llenarCob_buscarSubLinea(cob_buscarSubLinea);

    }//GEN-LAST:event_btn_guardarActionPerformed

    private void cob_buscarSubLineaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cob_buscarSubLineaKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            buscarSubLinea();
        }
    }//GEN-LAST:event_cob_buscarSubLineaKeyPressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista_subLineaProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista_subLineaProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista_subLineaProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista_subLineaProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vista_subLineaProducto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JButton btn_nuevo;
    private javax.swing.JComboBox<String> cob_Linea;
    private javax.swing.JComboBox<String> cob_buscarSubLinea;
    private javax.swing.JComboBox<String> cob_estado;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txt_idSublLinea;
    private javax.swing.JTextField txt_nomSubLinea;
    // End of variables declaration//GEN-END:variables
}
