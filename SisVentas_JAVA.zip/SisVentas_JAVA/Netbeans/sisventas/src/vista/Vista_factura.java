package vista;

import conexion.Conexion;
import controlador.Control_factura;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import modelo.Modelo_detalleVenta;
import modelo.Modelo_factura;
import modelo.Modelo_impFactura;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperPrintManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

public class Vista_factura extends javax.swing.JInternalFrame {

    Control_factura controlFact = new Control_factura();
    DefaultTableModel modelo;
    Object[] articulos = new Object[7];

    public Vista_factura() {
        initComponents();
        setTitle("Facturar compras");

        txt_fechaSistema.setText(controlFact.sistemaFecha());

        // Hora Sistema
        Timer tiempo = new Timer(100, new Vista_factura.horas());
        tiempo.start();

        controlFact.llenarCob_tipoFactura(cob_tipoFactura);
        modelo = (DefaultTableModel) tabla_detalleVta.getModel();
        txt_nomVendedor.setText(MDI_Vista_inicio.txt_nomEmpleado.getText());
        txt_caja.setText(MDI_Vista_inicio.txt_codCaja.getText());
        inhabilitar();

        txt_nomCliente.setText(controlFact.cliente_mostrador());

        lbl_totalRegistros.setText("0");
        lbl_totalPagar.setText("0");
        
    }

    // Hora Sistema
    class horas implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            Date sisHora = new Date();
            String pmAm = "hh:mm:ss a";
            SimpleDateFormat formatoHora = new SimpleDateFormat(pmAm);
            Calendar hoy = Calendar.getInstance();
            txt_horaSistema.setText(String.format(formatoHora.format(sisHora), hoy));
        }
    }

    void inhabilitar() {
        txt_fechaSistema.setEditable(false);
        txt_horaSistema.setEditable(false);
        txt_nomVendedor.setEditable(false);
        txt_caja.setEditable(false);

        cob_tipoFactura.requestFocus();
        txt_nomCliente.setEditable(false);
        txt_nomArticulo.setEditable(false);
        txt_precioFinal.setEditable(false);
        txt_porIva.setEditable(false);
        txt_porDcto.setEditable(false);

    }
    
    
    public void imprimir_y_agregarFactura(){
        if (cob_tipoFactura.getSelectedItem().toString().equals("- Tipo de Factura -")) {
            JOptionPane.showMessageDialog(null, "Debes elegir un tipo de factura");
            cob_tipoFactura.requestFocus();
            return;
        }


        if (tabla_detalleVta.getRowCount() > 0) {
            // envío informacion a IReport
            List lista = new ArrayList<>();
            for (int i = 0; i < tabla_detalleVta.getRowCount(); i++) {
                Modelo_impFactura compra = new Modelo_impFactura();
                compra.setArticulo(tabla_detalleVta.getValueAt(i, 1).toString());
                compra.setPrecioUnid(tabla_detalleVta.getValueAt(i, 2).toString());
                compra.setIva(tabla_detalleVta.getValueAt(i, 3).toString());
                compra.setDscto(tabla_detalleVta.getValueAt(i, 4).toString());
                compra.setCantidad(tabla_detalleVta.getValueAt(i, 5).toString());
                compra.setSubtotal(tabla_detalleVta.getValueAt(i, 6).toString());
                lista.add(compra);
            }

            try {
                JasperReport reporte = (JasperReport) JRLoader.loadObjectFromFile("factura_imp.jasper");
                JasperPrint jprint = JasperFillManager.fillReport(reporte, null, new JRBeanCollectionDataSource(lista));
                //JasperViewer.viewReport(jprint);

                Map parametro = new HashMap();

                parametro.put("vendedor", txt_nomVendedor.getText());
                parametro.put("caja", txt_caja.getText());
                parametro.put("cliente", txt_nomCliente.getText());
                parametro.put("tipo", cob_tipoFactura.getSelectedItem().toString());
                parametro.put("totalpagar", lbl_totalPagar.getText());

                JasperPrint jp = JasperFillManager.fillReport(reporte, parametro, new JRBeanCollectionDataSource(lista));
                JasperPrintManager.printReport(jp, true);
                JasperViewer.viewReport(jp,false);

            } catch (JRException e) {
                System.out.println("Error al imprimir la factura en JasperReport " + e);
            }

            // Envío información para la base de datos
            Modelo_factura dtsFactura = new Modelo_factura();

            dtsFactura.setTipoFactura(cob_tipoFactura.getSelectedItem().toString());
            dtsFactura.setFecha(txt_fechaSistema.getText());
            dtsFactura.setHora(txt_horaSistema.getText());
            dtsFactura.setCodigoCaja1(txt_caja.getText());
            dtsFactura.setNomEmpleado(txt_nomVendedor.getText());
            dtsFactura.setNomCliente(txt_nomCliente.getText());

            try {
                controlFact.nueva_Factura(dtsFactura);
            } catch (Exception e) {
                System.out.println("Error al crear la nueva factura " + e);
            }

            int idVenta = controlFact.idFactura();

            Conexion conexion = new Conexion();
            for (int i = 0; i < tabla_detalleVta.getRowCount(); i++) {
                try {
                    String sql = " INSERT INTO detalleventa VALUES( '"+(controlFact.Contador_dtalleventa()+1)+"', "
                            + " '" + idVenta + "', '" + tabla_detalleVta.getValueAt(i, 0) + "',"
                            + " '" + tabla_detalleVta.getValueAt(i, 2) + "', '" + tabla_detalleVta.getValueAt(i, 5) + "',"
                            + " '" + tabla_detalleVta.getValueAt(i, 6) + "') ";
                    if (conexion.ejecutar(sql)) {
                        // System.out.println("Registro en detalle venta correcto");
                    }
                } catch (Exception e) {
                    System.out.println("Error el insertar en detalle venta " + e);
                }
            }
            txt_numDocCliente.setText("");
            txt_nomCliente.setText("");
            txt_nomCliente.setText(controlFact.cliente_mostrador());
            modelo.setRowCount(0);
            lbl_totalRegistros.setText("0");
            lbl_totalPagar.setText("0");
            cob_tipoFactura.setSelectedItem("- Tipo de Factura -");
        } else {
            JOptionPane.showMessageDialog(null, "No hay productos para facturar", "Alerta!", JOptionPane.WARNING_MESSAGE);
            txt_codArticulo.requestFocus();
        }
    }
    
    public void agregar_articulo(){
        if (txt_nomArticulo.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Buscar los artículos por el código");
            txt_codArticulo.requestFocus();
            return;
        }
        if (txt_cantidad.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes ingresar una cantidad de artículos");
            txt_cantidad.requestFocus();
            return;
        }
        Modelo_detalleVenta dtsVenta = new Modelo_detalleVenta();

        dtsVenta.setPrecioFinal1(Double.parseDouble(txt_precioFinal.getText()));
        dtsVenta.setCantidad(Integer.parseInt(txt_cantidad.getText()));

        dtsVenta.setSubTotal(controlFact.subTotal(dtsVenta).toString());

        articulos[0] = txt_codArticulo.getText();
        articulos[1] = txt_nomArticulo.getText();
        articulos[2] = txt_precioFinal.getText();
        articulos[3] = txt_porIva.getText();
        articulos[4] = txt_porDcto.getText();
        articulos[5] = txt_cantidad.getText();
        articulos[6] = dtsVenta.getSubTotal();
        modelo.addRow(articulos);

        txt_codArticulo.setText("");
        txt_nomArticulo.setText("");
        txt_precioFinal.setText("");
        txt_porIva.setText("");
        txt_porDcto.setText("");
        txt_cantidad.setText("");
        txt_codArticulo.requestFocus();

        controlFact.suma_Cantidad();
        controlFact.suma_PagoTotal();
    }
    
    public void buscar() {
        if (txt_codArticulo.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingresa un código de artículo a buscar");
            txt_codArticulo.requestFocus();
            return;
        }

        Modelo_detalleVenta dtsVenta = new Modelo_detalleVenta();
        dtsVenta.setCodigoArticulo1(txt_codArticulo.getText());

        if (controlFact.existe_articulo(dtsVenta) == 1) {
            controlFact.buscarArticulos(dtsVenta);

            txt_nomArticulo.setText(dtsVenta.getNomArticulo());
            txt_precioFinal.setText(Double.toString(dtsVenta.getPrecioFinal1()));
            txt_porIva.setText(dtsVenta.getPorIva());
            txt_porDcto.setText(dtsVenta.getPorDscto());

            txt_cantidad.setText("");
            txt_cantidad.requestFocus();
        } else if (controlFact.existe_articulo(dtsVenta) == 0) {
            JOptionPane.showMessageDialog(null, "El artículo no se encuentra en la base de datos o esta Inactivo");
            txt_nomArticulo.setText("");
            txt_precioFinal.setText("");
            txt_porIva.setText("");
            txt_porDcto.setText("");
            txt_cantidad.setText("");
            txt_codArticulo.setText("");
            txt_codArticulo.requestFocus();
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        cob_tipoFactura = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txt_caja = new javax.swing.JTextField();
        txt_nomVendedor = new javax.swing.JTextField();
        txt_horaSistema = new javax.swing.JTextField();
        txt_fechaSistema = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txt_numDocCliente = new javax.swing.JTextField();
        btn_buscarCliente = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txt_nomCliente = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        txt_codArticulo = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btn_buscarArticulo = new javax.swing.JButton();
        txt_nomArticulo = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txt_precioFinal = new javax.swing.JTextField();
        txt_porIva = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txt_porDcto = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txt_cantidad = new javax.swing.JTextField();
        btn_agregarArt = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla_detalleVta = new javax.swing.JTable();
        lbl1 = new javax.swing.JLabel();
        btn_eliminarArt = new javax.swing.JButton();
        btn_factura = new javax.swing.JButton();
        lbl_totalRegistros = new javax.swing.JLabel();
        lbl2 = new javax.swing.JLabel();
        lbl_totalPagar = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setClosable(true);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setIconifiable(true);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Información Interna", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 14))); // NOI18N

        cob_tipoFactura.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cob_tipoFacturaKeyPressed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel1.setText("*Vendedor:");

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel2.setText("*Caja:");

        txt_nomVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nomVendedorActionPerformed(evt);
            }
        });

        txt_fechaSistema.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_fechaSistemaKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txt_fechaSistema, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txt_horaSistema, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_nomVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_caja, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cob_tipoFactura, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_horaSistema, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_fechaSistema, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(txt_caja, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cob_tipoFactura)
                    .addComponent(txt_nomVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel3.setText("FACTURACIÓN");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos Cliente", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 14))); // NOI18N

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel4.setText("Buscar por Número de identificación:");

        txt_numDocCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_numDocClienteKeyPressed(evt);
            }
        });

        btn_buscarCliente.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_buscarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/search.png"))); // NOI18N
        btn_buscarCliente.setText("Buscar");
        btn_buscarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarClienteActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel5.setText("*Nombre:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_numDocCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_buscarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_nomCliente)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txt_numDocCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_buscarCliente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txt_nomCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Artículos", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 14))); // NOI18N

        txt_codArticulo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_codArticuloKeyPressed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel6.setText("Código:");

        btn_buscarArticulo.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_buscarArticulo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/search.png"))); // NOI18N
        btn_buscarArticulo.setText("Buscar");
        btn_buscarArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarArticuloActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel7.setText("*Precio:");

        jLabel8.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel8.setText("*Iva:");

        jLabel9.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel9.setText("*Descuento:");

        jLabel10.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel10.setText("Cantidad:");

        txt_cantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_cantidadKeyPressed(evt);
            }
        });

        btn_agregarArt.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_agregarArt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/masCarrito.png"))); // NOI18N
        btn_agregarArt.setText("Agregar artículo");
        btn_agregarArt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregarArtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(txt_codArticulo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn_buscarArticulo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_nomArticulo))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(txt_precioFinal)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_porIva, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_porDcto, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btn_agregarArt)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_codArticulo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(btn_buscarArticulo)
                    .addComponent(txt_nomArticulo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txt_precioFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(txt_porIva, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(txt_porDcto, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txt_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btn_agregarArt)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Detalle Venta", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 14))); // NOI18N

        tabla_detalleVta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cod", "Producto", "Precio Unid", "Iva", "Dscto", "Cant", "Subtotal"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabla_detalleVta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tabla_detalleVtaKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tabla_detalleVta);

        lbl1.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        lbl1.setText("Total artículos:");

        btn_eliminarArt.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_eliminarArt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/menosCarrito.png"))); // NOI18N
        btn_eliminarArt.setText("Eliminar artículo");
        btn_eliminarArt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarArtActionPerformed(evt);
            }
        });

        btn_factura.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_factura.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/facturaAzul.png"))); // NOI18N
        btn_factura.setText("Generar factura");
        btn_factura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_facturaActionPerformed(evt);
            }
        });
        btn_factura.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btn_facturaKeyPressed(evt);
            }
        });

        lbl_totalRegistros.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        lbl_totalRegistros.setForeground(new java.awt.Color(0, 102, 0));
        lbl_totalRegistros.setText("\n");

        lbl2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        lbl2.setText("Total a pagar:");

        lbl_totalPagar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        lbl_totalPagar.setForeground(new java.awt.Color(0, 102, 0));
        lbl_totalPagar.setText("\n");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 552, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(btn_eliminarArt)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_factura))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lbl1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbl_totalRegistros, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbl2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbl_totalPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 354, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lbl2)
                        .addComponent(lbl_totalPagar))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lbl1)
                        .addComponent(lbl_totalRegistros)))
                .addGap(22, 22, 22)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_eliminarArt)
                    .addComponent(btn_factura))
                .addContainerGap())
        );

        jLabel11.setText("* Campos NO modificables");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel3))
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel11))
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_buscarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarClienteActionPerformed

        if (txt_numDocCliente.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingresa un número de documento a buscar");
            txt_numDocCliente.requestFocus();
            return;
        }

        Modelo_factura dtsFactura = new Modelo_factura();
        dtsFactura.setNumDocCliente(txt_numDocCliente.getText());

        txt_nomCliente.setText(controlFact.buscarCliente(dtsFactura));

    }//GEN-LAST:event_btn_buscarClienteActionPerformed

    private void btn_buscarArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarArticuloActionPerformed

        buscar();

    }//GEN-LAST:event_btn_buscarArticuloActionPerformed

    private void btn_agregarArtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregarArtActionPerformed

        agregar_articulo();

    }//GEN-LAST:event_btn_agregarArtActionPerformed
    
    private void btn_eliminarArtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarArtActionPerformed

        if (tabla_detalleVta.getSelectedRow() != -1) {
            modelo.removeRow(tabla_detalleVta.getSelectedRow());
            controlFact.suma_Cantidad();
            controlFact.suma_PagoTotal();
        } else {
            JOptionPane.showMessageDialog(null, "No has seleccionado ningún articulo");
        }

    }//GEN-LAST:event_btn_eliminarArtActionPerformed

    private void btn_facturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_facturaActionPerformed

        imprimir_y_agregarFactura();

    }//GEN-LAST:event_btn_facturaActionPerformed

    private void txt_nomVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nomVendedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nomVendedorActionPerformed

    private void txt_codArticuloKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_codArticuloKeyPressed

        txt_codArticulo.setFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS, java.util.Collections.EMPTY_SET);
        
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            buscar();
        } else if(evt.getKeyCode() == KeyEvent.VK_TAB){
            btn_factura.requestFocus();
        }
    }//GEN-LAST:event_txt_codArticuloKeyPressed

    private void txt_cantidadKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_cantidadKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            agregar_articulo();
        }
    }//GEN-LAST:event_txt_cantidadKeyPressed

    private void txt_numDocClienteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_numDocClienteKeyPressed
        
        txt_numDocCliente.setFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS, java.util.Collections.EMPTY_SET);
            if(evt.getKeyCode() == KeyEvent.VK_TAB){
            txt_codArticulo.requestFocus();
        }
            
        if (evt.getKeyCode() == KeyEvent.VK_ENTER){
            if (txt_numDocCliente.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingresa un número de documento a buscar");
            txt_numDocCliente.requestFocus();
            return;
        }
            
            
        
        Modelo_factura dtsFactura = new Modelo_factura();
        dtsFactura.setNumDocCliente(txt_numDocCliente.getText());

        txt_nomCliente.setText(controlFact.buscarCliente(dtsFactura));
        txt_numDocCliente.setText("");
        }
    }//GEN-LAST:event_txt_numDocClienteKeyPressed

    private void tabla_detalleVtaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabla_detalleVtaKeyPressed

        if (tabla_detalleVta.getSelectedRow() != -1) {
            if(evt.getKeyCode() == KeyEvent.VK_DELETE){
                modelo.removeRow(tabla_detalleVta.getSelectedRow());
                controlFact.suma_Cantidad();
                controlFact.suma_PagoTotal();
            }
        } 
        
    }//GEN-LAST:event_tabla_detalleVtaKeyPressed

    private void btn_facturaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btn_facturaKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            imprimir_y_agregarFactura();
        }
    }//GEN-LAST:event_btn_facturaKeyPressed

    private void txt_fechaSistemaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_fechaSistemaKeyPressed
        
    }//GEN-LAST:event_txt_fechaSistemaKeyPressed

    private void cob_tipoFacturaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cob_tipoFacturaKeyPressed
        
    }//GEN-LAST:event_cob_tipoFacturaKeyPressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista_factura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista_factura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista_factura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista_factura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vista_factura().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_agregarArt;
    private javax.swing.JButton btn_buscarArticulo;
    private javax.swing.JButton btn_buscarCliente;
    private javax.swing.JButton btn_eliminarArt;
    private javax.swing.JButton btn_factura;
    private javax.swing.JComboBox<String> cob_tipoFactura;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl1;
    private javax.swing.JLabel lbl2;
    public static javax.swing.JLabel lbl_totalPagar;
    public static javax.swing.JLabel lbl_totalRegistros;
    public static javax.swing.JTable tabla_detalleVta;
    public static javax.swing.JTextField txt_caja;
    private javax.swing.JTextField txt_cantidad;
    private javax.swing.JTextField txt_codArticulo;
    private javax.swing.JTextField txt_fechaSistema;
    private javax.swing.JTextField txt_horaSistema;
    private javax.swing.JTextField txt_nomArticulo;
    private javax.swing.JTextField txt_nomCliente;
    public static javax.swing.JTextField txt_nomVendedor;
    private javax.swing.JTextField txt_numDocCliente;
    private javax.swing.JTextField txt_porDcto;
    private javax.swing.JTextField txt_porIva;
    private javax.swing.JTextField txt_precioFinal;
    // End of variables declaration//GEN-END:variables
}
