
package vista;

import Diseño.fondo;
import javax.swing.ImageIcon;

public class MDI_Vista_inicio extends javax.swing.JFrame {
    
     
    public MDI_Vista_inicio() {
        initComponents();
        
        setIconImage(new ImageIcon(getClass().getResource("/archivos/Icono.png")).getImage());
        
        this.setExtendedState(MDI_Vista_inicio.MAXIMIZED_BOTH);
        this.setTitle("SISTEMA DE GESTIÓN DE VENTA - SISVENTAS");
        txt_nomEmpleado.setEditable(false);
        txt_rol.setEditable(false);
        txt_codCaja.setEditable(false);
        
        escritorio.setBorder(new fondo());
        
        if(txt_rol.getText().equals("1")){
            menu_admin.setEnabled(true);
        }else if(txt_rol.getText().equals("2")){
            menu_admin.setEnabled(false);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem3 = new javax.swing.JMenuItem();
        escritorio = new javax.swing.JDesktopPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txt_nomEmpleado = new javax.swing.JTextField();
        txt_rol = new javax.swing.JTextField();
        txt_codCaja = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        menu_registrar = new javax.swing.JMenu();
        menu_admin = new javax.swing.JMenu();
        adminEmpleados = new javax.swing.JMenuItem();
        adminClientes = new javax.swing.JMenuItem();
        amindProveedores = new javax.swing.JMenuItem();
        adminTipoCaja = new javax.swing.JMenuItem();
        adminCaja = new javax.swing.JMenuItem();
        adminCargos = new javax.swing.JMenuItem();
        adminLinea = new javax.swing.JMenuItem();
        adminSubLinea = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        menu_reportes = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        menu_acerca = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        btn_salir = new javax.swing.JMenu();

        jMenuItem3.setText("jMenuItem3");

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos de logueo", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 14), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.setToolTipText("");

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Usuario");

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Rol empleado");

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Codigo caja");

        txt_rol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_rolActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_nomEmpleado)
                    .addComponent(txt_rol, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                    .addComponent(txt_codCaja, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_nomEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txt_rol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txt_codCaja, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        escritorio.add(jPanel1);
        jPanel1.setBounds(30, 60, 320, 140);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/logoTipo.png"))); // NOI18N
        escritorio.add(jLabel5);
        jLabel5.setBounds(440, 110, 860, 460);

        menuBar.setBackground(new java.awt.Color(51, 51, 51));

        fileMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/inicio.png"))); // NOI18N
        fileMenu.setMnemonic('f');
        menuBar.add(fileMenu);

        menu_registrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/cajaSuper.png"))); // NOI18N
        menu_registrar.setMnemonic('e');
        menu_registrar.setText("Registrar");
        menu_registrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menu_registrarMouseClicked(evt);
            }
        });
        menu_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_registrarActionPerformed(evt);
            }
        });
        menuBar.add(menu_registrar);

        menu_admin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/proyecto.png"))); // NOI18N
        menu_admin.setMnemonic('h');
        menu_admin.setText("Administración");

        adminEmpleados.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        adminEmpleados.setMnemonic('c');
        adminEmpleados.setText("Empleados");
        adminEmpleados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                adminEmpleadosMouseClicked(evt);
            }
        });
        adminEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminEmpleadosActionPerformed(evt);
            }
        });
        menu_admin.add(adminEmpleados);

        adminClientes.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        adminClientes.setMnemonic('a');
        adminClientes.setText("Clientes");
        adminClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminClientesActionPerformed(evt);
            }
        });
        menu_admin.add(adminClientes);

        amindProveedores.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        amindProveedores.setText("Proveedores");
        amindProveedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                amindProveedoresActionPerformed(evt);
            }
        });
        menu_admin.add(amindProveedores);

        adminTipoCaja.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_MASK));
        adminTipoCaja.setText("Tipo Caja");
        adminTipoCaja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminTipoCajaActionPerformed(evt);
            }
        });
        menu_admin.add(adminTipoCaja);

        adminCaja.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        adminCaja.setText("Caja");
        adminCaja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminCajaActionPerformed(evt);
            }
        });
        menu_admin.add(adminCaja);

        adminCargos.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_W, java.awt.event.InputEvent.CTRL_MASK));
        adminCargos.setText("Cargos");
        adminCargos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminCargosActionPerformed(evt);
            }
        });
        menu_admin.add(adminCargos);

        adminLinea.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
        adminLinea.setText("Línea Producto");
        adminLinea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminLineaActionPerformed(evt);
            }
        });
        menu_admin.add(adminLinea);

        adminSubLinea.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        adminSubLinea.setText("Sub Línea");
        adminSubLinea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminSubLineaActionPerformed(evt);
            }
        });
        menu_admin.add(adminSubLinea);

        menuBar.add(menu_admin);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/comestibles.png"))); // NOI18N
        jMenu1.setText("Productos");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        menuBar.add(jMenu1);

        menu_reportes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/reportar.png"))); // NOI18N
        menu_reportes.setText("Reportes");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("Cleinte");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        menu_reportes.add(jMenuItem1);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setText("Fechas");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        menu_reportes.add(jMenuItem2);

        menuBar.add(menu_reportes);

        menu_acerca.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/ayudar.png"))); // NOI18N
        menu_acerca.setText("Acerca de");
        menu_acerca.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menu_acercaMouseClicked(evt);
            }
        });
        menu_acerca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_acercaActionPerformed(evt);
            }
        });
        menuBar.add(menu_acerca);

        jMenu2.setText("                                                                                                                                                                                                                                           ");
        menuBar.add(jMenu2);

        btn_salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/systemshutdown_94125.png"))); // NOI18N
        btn_salir.setText("Salir");
        btn_salir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_salirMouseClicked(evt);
            }
        });
        menuBar.add(btn_salir);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(escritorio, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(escritorio, javax.swing.GroupLayout.DEFAULT_SIZE, 481, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void adminEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminEmpleadosActionPerformed
        
        Vista_empleado empleado = new Vista_empleado();
        
        escritorio.add(empleado);
        
        empleado.toFront();
        empleado.setVisible(true);
        
    }//GEN-LAST:event_adminEmpleadosActionPerformed

    private void btn_salirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_salirMouseClicked
        
        //System.exit(0);
        this.dispose();
        
        Vista_login login = new Vista_login();
        login.toFront();
        login.setVisible(true);
        
    }//GEN-LAST:event_btn_salirMouseClicked

    private void adminEmpleadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adminEmpleadosMouseClicked
        
    }//GEN-LAST:event_adminEmpleadosMouseClicked

    private void adminClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminClientesActionPerformed
        
        Vista_cliente cliente = new Vista_cliente();
        
        escritorio.add(cliente);
        cliente.toFront();
        cliente.setVisible(true);
        
    }//GEN-LAST:event_adminClientesActionPerformed

    private void menu_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_registrarActionPerformed
        
        
        
    }//GEN-LAST:event_menu_registrarActionPerformed

    private void menu_registrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menu_registrarMouseClicked
        
        Vista_factura factura = new Vista_factura();
        
        escritorio.add(factura);
        
        factura.toFront();
        factura.setVisible(true);
        
    }//GEN-LAST:event_menu_registrarMouseClicked

    private void txt_rolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_rolActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_rolActionPerformed

    private void menu_acercaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_acercaActionPerformed
        
        
    }//GEN-LAST:event_menu_acercaActionPerformed

    private void menu_acercaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menu_acercaMouseClicked
        
        Vista_acerca acerca = new Vista_acerca();
        
        escritorio.add(acerca);
        acerca.toFront();
        acerca.setVisible(true);
        acerca.setLocale(null);
        
    }//GEN-LAST:event_menu_acercaMouseClicked

    private void adminCargosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminCargosActionPerformed
        
        Vista_cargo cargos = new Vista_cargo();
        
        escritorio.add(cargos);
        cargos.toFront();
        cargos.setVisible(rootPaneCheckingEnabled);
        
    }//GEN-LAST:event_adminCargosActionPerformed

    private void amindProveedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_amindProveedoresActionPerformed
        
        Vista_proveedor proveedor = new Vista_proveedor();
        
        escritorio.add(proveedor);
        proveedor.toFront();
        proveedor.setVisible(true);
        
    }//GEN-LAST:event_amindProveedoresActionPerformed

    private void adminTipoCajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminTipoCajaActionPerformed
        
        Vista_tipoCaja tipoCaja = new Vista_tipoCaja();
        
        escritorio.add(tipoCaja);
        tipoCaja.toFront();
        tipoCaja.setVisible(true);
        
    }//GEN-LAST:event_adminTipoCajaActionPerformed

    private void adminCajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminCajaActionPerformed
        
        Vista_caja caja = new Vista_caja();
        
        escritorio.add(caja);
        caja.toFront();
        caja.setVisible(true);
        
    }//GEN-LAST:event_adminCajaActionPerformed

    private void adminLineaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminLineaActionPerformed
        
        Vista_lineaProducto linea = new Vista_lineaProducto();
        
        escritorio.add(linea);
        linea.toFront();
        linea.setVisible(true);
        
    }//GEN-LAST:event_adminLineaActionPerformed

    private void adminSubLineaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminSubLineaActionPerformed
        
        Vista_subLineaProducto sublinea = new Vista_subLineaProducto();
        
        escritorio.add(sublinea);
        sublinea.toFront();
        sublinea.setVisible(true);
        
    }//GEN-LAST:event_adminSubLineaActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        
        Vista_ReporteCliente reporCliente = new Vista_ReporteCliente();
        
        escritorio.add(reporCliente);
        reporCliente.toFront();
        reporCliente.setVisible(true);
        
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        
        Vista_ReporteArticulo reporArticulo = new Vista_ReporteArticulo();
        
        escritorio.add(reporArticulo);
        reporArticulo.toFront();
        reporArticulo.setVisible(true);
        
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        
        Vista_articulo articulo = new Vista_articulo();
        
        escritorio.add(articulo);
        
        articulo.toFront();
        articulo.setVisible(true);
        
    }//GEN-LAST:event_jMenu1MouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MDI_Vista_inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MDI_Vista_inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MDI_Vista_inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MDI_Vista_inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MDI_Vista_inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem adminCaja;
    private javax.swing.JMenuItem adminCargos;
    private javax.swing.JMenuItem adminClientes;
    private javax.swing.JMenuItem adminEmpleados;
    private javax.swing.JMenuItem adminLinea;
    private javax.swing.JMenuItem adminSubLinea;
    private javax.swing.JMenuItem adminTipoCaja;
    private javax.swing.JMenuItem amindProveedores;
    private javax.swing.JMenu btn_salir;
    private javax.swing.JDesktopPane escritorio;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenu menu_acerca;
    public static javax.swing.JMenu menu_admin;
    private javax.swing.JMenu menu_registrar;
    private javax.swing.JMenu menu_reportes;
    public static javax.swing.JTextField txt_codCaja;
    public static javax.swing.JTextField txt_nomEmpleado;
    public static javax.swing.JTextField txt_rol;
    // End of variables declaration//GEN-END:variables

}
