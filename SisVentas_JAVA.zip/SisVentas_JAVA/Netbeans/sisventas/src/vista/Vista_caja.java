package vista;

import conexion.Conexion;
import controlador.Control_caja;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import modelo.Modelo_caja;

public class Vista_caja extends javax.swing.JInternalFrame {

    private String accion;
    Control_caja control = new Control_caja();

    public Vista_caja() {
        initComponents();

        control.llenarCob_codCaja(cob_codCaja);
        control.llenarCobIdTipoCaja(cob_tipoCaja);
        inhabilitar();

        if (MDI_Vista_inicio.txt_rol.getText().equals("1")) {
            btn_nuevo.setEnabled(true);
        } else if (MDI_Vista_inicio.txt_rol.getText().equals("2")) {
            btn_nuevo.setEnabled(false);
        }
        
        setTitle("Cajas");
    }

    void inhabilitar() {
        txt_codCaja.setEnabled(false);
        txt_ubiCaja.setEnabled(false);
        txt_descripcionCaja.setEnabled(false);
        cob_tipoCaja.setEnabled(false);
        cob_estado.setEnabled(false);

        btn_guardar.setEnabled(false);

        txt_codCaja.setText("");
        txt_ubiCaja.setText("");
        txt_descripcionCaja.setText("");

        cob_codCaja.setSelectedItem("Buscar");
        cob_tipoCaja.setSelectedItem("- Tipo Caja -");
        cob_estado.setSelectedItem("Activo");
    }

    void habilitar() {
        txt_codCaja.setEditable(false);
        txt_ubiCaja.setEnabled(true);
        txt_descripcionCaja.setEnabled(true);
        cob_tipoCaja.setEnabled(true);
        cob_estado.setEnabled(true);

        btn_guardar.setEnabled(true);

        txt_codCaja.setText("");
        txt_ubiCaja.setText("");
        txt_descripcionCaja.setText("");

        cob_codCaja.setSelectedItem("Buscar");
        cob_tipoCaja.setSelectedItem("- Tipo Caja -");
        cob_estado.setSelectedItem("Activo");
    }
    
    void buscarCaja(){
        if (cob_codCaja.getSelectedItem().toString().equals("Buscar")) {
            JOptionPane.showMessageDialog(null, "Selecciona una caja a buscar");
            cob_codCaja.requestFocus();
            return;
        }

        Conexion conexion = new Conexion();
        String sql = " SELECT c.*, tc.Nombre AS tipoCaja FROM caja c JOIN tipocaja tc ON tc.IdTipoCaja = c.IdTipoCaja1 "
                + " WHERE c.CodigoCaja LIKE '" + cob_codCaja.getSelectedItem().toString() + "' ";
        ResultSet rs = conexion.consultar(sql);

        try {
            if (rs.next()) {
                rs.beforeFirst();
                habilitar();
                while (rs.next()) {
                    txt_codCaja.setText(rs.getString("CodigoCaja"));
                    txt_ubiCaja.setText(rs.getString("Ubicacion"));
                    cob_tipoCaja.setSelectedItem(rs.getString("tipoCaja"));
                    txt_descripcionCaja.setText(rs.getString("Descripcion"));
                    cob_estado.setSelectedItem(rs.getString("estado"));
                }
                btn_guardar.setText("Editar");
                accion = "editar";
                txt_codCaja.setEditable(false);

            } else {
                JOptionPane.showMessageDialog(null, "La caja no esta registrada");
                inhabilitar();
            }
        } catch (Exception e) {
            System.out.println("Error en la busqueda del cliente" + e);
            inhabilitar();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txt_codCaja = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        btn_nuevo = new javax.swing.JButton();
        txt_ubiCaja = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btn_buscar = new javax.swing.JButton();
        btn_guardar = new javax.swing.JButton();
        cob_codCaja = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_descripcionCaja = new javax.swing.JTextArea();
        jLabel7 = new javax.swing.JLabel();
        cob_tipoCaja = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        cob_estado = new javax.swing.JComboBox<>();

        setClosable(true);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setIconifiable(true);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "ADMINISTRADOR CAJA", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 18), new java.awt.Color(255, 255, 255))); // NOI18N

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Código Caja:");

        txt_codCaja.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        txt_codCaja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_codCajaActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Ubicación:");

        btn_nuevo.setBackground(new java.awt.Color(51, 51, 51));
        btn_nuevo.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_nuevo.setForeground(new java.awt.Color(255, 255, 255));
        btn_nuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/checkShadow.png"))); // NOI18N
        btn_nuevo.setText("Nuevo");
        btn_nuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nuevoActionPerformed(evt);
            }
        });

        txt_ubiCaja.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        txt_ubiCaja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_ubiCajaActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Buscar  No:");

        btn_buscar.setBackground(new java.awt.Color(51, 51, 51));
        btn_buscar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_buscar.setForeground(new java.awt.Color(255, 255, 255));
        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/search.png"))); // NOI18N
        btn_buscar.setText("Buscar");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });

        btn_guardar.setBackground(new java.awt.Color(51, 51, 51));
        btn_guardar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_guardar.setForeground(new java.awt.Color(255, 255, 255));
        btn_guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/guardar.png"))); // NOI18N
        btn_guardar.setText("Guardar");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });

        cob_codCaja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cob_codCajaActionPerformed(evt);
            }
        });
        cob_codCaja.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cob_codCajaKeyPressed(evt);
            }
        });

        txt_descripcionCaja.setColumns(20);
        txt_descripcionCaja.setRows(5);
        jScrollPane1.setViewportView(txt_descripcionCaja);

        jLabel7.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Descripción:");

        cob_tipoCaja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cob_tipoCajaActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Estado:");

        cob_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_nuevo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_guardar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txt_ubiCaja, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(txt_codCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cob_codCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cob_tipoCaja, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_buscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addComponent(jScrollPane1)
                            .addComponent(cob_estado, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(btn_buscar)
                    .addComponent(txt_codCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(cob_codCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_ubiCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(cob_tipoCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cob_estado, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_nuevo)
                    .addComponent(btn_guardar))
                .addGap(33, 33, 33))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 329, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_codCajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_codCajaActionPerformed

    }//GEN-LAST:event_txt_codCajaActionPerformed

    private void btn_nuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_nuevoActionPerformed

        btn_guardar.setText("Guardar");
        accion = "nuevo";
        habilitar();


    }//GEN-LAST:event_btn_nuevoActionPerformed

    private void txt_ubiCajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_ubiCajaActionPerformed

    }//GEN-LAST:event_txt_ubiCajaActionPerformed

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed

        buscarCaja();

    }//GEN-LAST:event_btn_buscarActionPerformed

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed

        if (txt_ubiCaja.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes digitar una ubicación para la caja");
            txt_ubiCaja.requestFocus();
            return;
        }
        if (cob_tipoCaja.getSelectedItem().toString().equals("- Tipo Caja -")) {
            JOptionPane.showMessageDialog(null, "Debes seleccionar un tipo de caja");
            cob_tipoCaja.requestFocus();
            return;
        }
        if (txt_descripcionCaja.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes digitar una descripción para la caja");
            txt_descripcionCaja.requestFocus();
            return;
        }
        Modelo_caja dtsCaja = new Modelo_caja();

        dtsCaja.setTipoCaja(cob_tipoCaja.getSelectedItem().toString());
        dtsCaja.setUbicacion(txt_ubiCaja.getText());
        dtsCaja.setDescripcion(txt_descripcionCaja.getText());
        dtsCaja.setEstado(cob_estado.getSelectedItem().toString());

        if (accion.equals("nuevo")) {
            control.nuevaCaja(dtsCaja);
            cob_codCaja.removeAllItems();
            control.llenarCob_codCaja(cob_codCaja);
            inhabilitar();
        } else if (accion.equals("editar")) {
            dtsCaja.setCodigoCaja(txt_codCaja.getText());
            control.editarCaja(dtsCaja);
            inhabilitar();
        }

    }//GEN-LAST:event_btn_guardarActionPerformed

    private void cob_codCajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cob_codCajaActionPerformed


    }//GEN-LAST:event_cob_codCajaActionPerformed

    private void cob_tipoCajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cob_tipoCajaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cob_tipoCajaActionPerformed

    private void cob_codCajaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cob_codCajaKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            buscarCaja();
        }
    }//GEN-LAST:event_cob_codCajaKeyPressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista_caja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista_caja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista_caja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista_caja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vista_caja().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JButton btn_nuevo;
    private javax.swing.JComboBox<String> cob_codCaja;
    private javax.swing.JComboBox<String> cob_estado;
    private javax.swing.JComboBox<String> cob_tipoCaja;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txt_codCaja;
    private javax.swing.JTextArea txt_descripcionCaja;
    private javax.swing.JTextField txt_ubiCaja;
    // End of variables declaration//GEN-END:variables
}
