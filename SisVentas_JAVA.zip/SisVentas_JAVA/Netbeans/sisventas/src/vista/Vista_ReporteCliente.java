
package vista;

import controlador.Control_reportes;
import java.awt.event.KeyEvent;
import java.text.*;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author DAHS
 */
public class Vista_ReporteCliente extends javax.swing.JInternalFrame {
    
    Control_reportes control = new Control_reportes();

    public Vista_ReporteCliente() {
        initComponents();
        mostrar_articulos("","");
        setTitle("Reporte compras por cliente");
    }
    
    void mostrar_articulos(String buscar, String tipoFact) {
        try {
            DefaultTableModel modelo;
            modelo = control.mostrar_articulos(buscar,tipoFact);
            tabla_reporte.setModel(modelo);
            lbl_total_registros.setText("Total de registros: " + Integer.toString(control.totalregistros));
        } catch (Exception e) {
            System.out.println("Error al cargar tabla en vista reporte " + e);
        }
    }
    
    void buscarReporte(){
        if(txt_buscarCliente.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Ingresa un número de documento a buscar");
            txt_buscarCliente.requestFocus();
            return;
        }
        if(cob_tipoFact.getSelectedItem().equals("- Tipo Factura -")){
            JOptionPane.showMessageDialog(null, "Selecciona un tipo de factura a buscar");
            cob_tipoFact.requestFocus();
            return;
        }
        
        control.consultar_codCliente(txt_buscarCliente.getText());
        
        if(control.consultar_exiteDv() == 1){
            // System.out.println(control.consultar_exiteDv());
            //System.out.println("SIIII tiene");
            mostrar_articulos(txt_buscarCliente.getText(), cob_tipoFact.getSelectedItem().toString());
            txt_buscarCliente.requestFocus();
        }else if(control.consultar_exiteDv() == 0) {
            // System.out.println("no tiene");
            // System.out.println(control.consultar_exiteDv());
            JOptionPane.showMessageDialog(null, "El número buscado no tiene facturas asociadas");
            txt_buscarCliente.requestFocus();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txt_buscarCliente = new javax.swing.JTextField();
        btn_buscarCliente = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla_reporte = new javax.swing.JTable();
        lbl_total_registros = new javax.swing.JLabel();
        btn_imprimir = new javax.swing.JButton();
        cob_tipoFact = new javax.swing.JComboBox<>();

        setClosable(true);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setIconifiable(true);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "REPORTE POR CLIENTES", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 18), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Buscar por número de documento:");

        txt_buscarCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_buscarClienteKeyPressed(evt);
            }
        });

        btn_buscarCliente.setBackground(new java.awt.Color(51, 51, 51));
        btn_buscarCliente.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_buscarCliente.setForeground(new java.awt.Color(255, 255, 255));
        btn_buscarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/search.png"))); // NOI18N
        btn_buscarCliente.setText("Buscar");
        btn_buscarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarClienteActionPerformed(evt);
            }
        });

        tabla_reporte.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabla_reporte);

        lbl_total_registros.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        lbl_total_registros.setForeground(new java.awt.Color(255, 255, 255));
        lbl_total_registros.setText("Total registros:");

        btn_imprimir.setBackground(new java.awt.Color(51, 51, 51));
        btn_imprimir.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_imprimir.setForeground(new java.awt.Color(255, 255, 255));
        btn_imprimir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/imprimir.png"))); // NOI18N
        btn_imprimir.setText("Imprimir");
        btn_imprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_imprimirActionPerformed(evt);
            }
        });

        cob_tipoFact.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cob_tipoFact.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Tipo Factura -", "1", "2" }));
        cob_tipoFact.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cob_tipoFactKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_buscarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cob_tipoFact, 0, 122, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_buscarCliente)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_imprimir))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lbl_total_registros, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txt_buscarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_buscarCliente)
                    .addComponent(btn_imprimir)
                    .addComponent(cob_tipoFact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 326, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbl_total_registros)
                .addGap(29, 29, 29))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_buscarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarClienteActionPerformed

        buscarReporte();
        
    }//GEN-LAST:event_btn_buscarClienteActionPerformed

    private void btn_imprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_imprimirActionPerformed

        MessageFormat header = new MessageFormat("Reporte de artículos por cliente");
        MessageFormat footer = new MessageFormat("Página {0,number,integer}");

        try {
            tabla_reporte.print(JTable.PrintMode.NORMAL, header, footer);
        } catch (Exception e) {
            System.out.println("Error al imprimir reporte de artículos "+e);
        }

    }//GEN-LAST:event_btn_imprimirActionPerformed

    private void txt_buscarClienteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_buscarClienteKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            cob_tipoFact.requestFocus();
        }
    }//GEN-LAST:event_txt_buscarClienteKeyPressed

    private void cob_tipoFactKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cob_tipoFactKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            buscarReporte();
        }
    }//GEN-LAST:event_cob_tipoFactKeyPressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista_ReporteCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista_ReporteCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista_ReporteCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista_ReporteCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vista_ReporteCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_buscarCliente;
    private javax.swing.JButton btn_imprimir;
    private javax.swing.JComboBox<String> cob_tipoFact;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_total_registros;
    private javax.swing.JTable tabla_reporte;
    private javax.swing.JTextField txt_buscarCliente;
    // End of variables declaration//GEN-END:variables
}
