package vista;

import conexion.Conexion;
import controlador.Control_proveedor;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import modelo.Modelo_proveedor;

public class Vista_proveedor extends javax.swing.JInternalFrame {

    Control_proveedor control = new Control_proveedor();
    private String accion;

    public Vista_proveedor() {
        initComponents();

        control.llenarCob_ciudad(cob_ciudadProveedor);
        inhabilitar();
        setTitle("Proveedores");

    }

    void inhabilitar() {
        txt_IdProveedor.setVisible(false);

        txt_nitProveedor.setEnabled(false);
        txt_nombreProveedor.setEnabled(false);
        txt_dirProveedor.setEnabled(false);
        txt_telProveedor.setEnabled(false);
        txt_emailProveedor.setEnabled(false);
        cob_ciudadProveedor.setEnabled(false);
        cob_estado.setEnabled(false);
        btn_guardar.setEnabled(false);

        txt_buscarProveedor.setText("");
        txt_nitProveedor.setText("");
        txt_nombreProveedor.setText("");
        txt_dirProveedor.setText("");
        txt_telProveedor.setText("");
        txt_emailProveedor.setText("");
        txt_IdProveedor.setText("");
        cob_ciudadProveedor.setSelectedItem("- Ciudad -");
        cob_estado.setSelectedItem("Activo");
    }

    void habilitar() {
        txt_IdProveedor.setVisible(false);

        txt_nitProveedor.setEnabled(true);
        txt_nombreProveedor.setEnabled(true);
        txt_dirProveedor.setEnabled(true);
        txt_telProveedor.setEnabled(true);
        txt_emailProveedor.setEnabled(true);
        cob_ciudadProveedor.setEnabled(true);
        cob_estado.setEnabled(true);
        btn_guardar.setEnabled(true);
        btn_nuevo.setEnabled(true);

        txt_buscarProveedor.setText("");
        txt_nitProveedor.setText("");
        txt_nombreProveedor.setText("");
        txt_dirProveedor.setText("");
        txt_telProveedor.setText("");
        txt_emailProveedor.setText("");
        cob_ciudadProveedor.setSelectedItem("- Ciudad -");
        cob_estado.setSelectedItem("Activo");
    }
    
    void buscarProveedor(){
        if(txt_buscarProveedor.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Ingresa un nit a buscar");
            txt_buscarProveedor.requestFocus();
            return;
        }
        Conexion conexion = new Conexion();
        String sql = " SELECT p.*, cd.Nombre AS ciudad FROM proveedores p "
                + " JOIN ciudad cd ON p.CodigoCiudad2 = cd.CodigoCiudad "
                + " WHERE p.NumeroIdentidad LIKE '" + txt_buscarProveedor.getText() + "' ";
        ResultSet rs = conexion.consultar(sql);

        try {
            if (rs.next()) {
                rs.beforeFirst();
                habilitar();
                while (rs.next()) {
                    txt_nombreProveedor.setText(rs.getString("Nombre"));
                    txt_nitProveedor.setText(rs.getString("NumeroIdentidad"));
                    txt_dirProveedor.setText(rs.getString("Direccion"));
                    txt_telProveedor.setText(rs.getString("Telefono"));
                    txt_emailProveedor.setText(rs.getString("Email"));
                    cob_ciudadProveedor.setSelectedItem(rs.getString("ciudad"));
                    cob_estado.setSelectedItem(rs.getString("estado"));
                    txt_IdProveedor.setText(rs.getString("IdProveedor"));
                }
                btn_guardar.setText("Editar");
                accion = "editar";

            } else {
                JOptionPane.showMessageDialog(null, "El Proveedor no esta registrado");
                accion = "nuevo";
                txt_buscarProveedor.setText("");
                txt_buscarProveedor.requestFocus();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en consulta cliente " + e);
            accion = "nuevo";
            txt_buscarProveedor.setText("");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btn_guardar = new javax.swing.JButton();
        txt_emailProveedor = new javax.swing.JTextField();
        txt_nitProveedor = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        cob_ciudadProveedor = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        txt_telProveedor = new javax.swing.JTextField();
        btn_buscar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        txt_nombreProveedor = new javax.swing.JTextField();
        txt_buscarProveedor = new javax.swing.JTextField();
        btn_nuevo = new javax.swing.JButton();
        txt_IdProveedor = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txt_dirProveedor = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        cob_estado = new javax.swing.JComboBox<>();

        setClosable(true);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setIconifiable(true);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "ADMINISTRADOR DE PROVEEDORES", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 18), new java.awt.Color(255, 255, 255))); // NOI18N

        btn_guardar.setBackground(new java.awt.Color(51, 51, 51));
        btn_guardar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_guardar.setForeground(new java.awt.Color(255, 255, 255));
        btn_guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/guardar.png"))); // NOI18N
        btn_guardar.setText("Guardar");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });

        txt_emailProveedor.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        txt_nitProveedor.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nit:");

        jLabel9.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Teléfono:");

        jLabel12.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Ciudad:");

        jLabel10.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Correo Electrónico:");

        cob_ciudadProveedor.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel13.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Buscar proveedor por Nit:");

        txt_telProveedor.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        btn_buscar.setBackground(new java.awt.Color(51, 51, 51));
        btn_buscar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_buscar.setForeground(new java.awt.Color(255, 255, 255));
        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/search.png"))); // NOI18N
        btn_buscar.setText("Buscar");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Nombre:");

        txt_nombreProveedor.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        txt_buscarProveedor.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        txt_buscarProveedor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_buscarProveedorKeyPressed(evt);
            }
        });

        btn_nuevo.setBackground(new java.awt.Color(51, 51, 51));
        btn_nuevo.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_nuevo.setForeground(new java.awt.Color(255, 255, 255));
        btn_nuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/checkShadow.png"))); // NOI18N
        btn_nuevo.setText("Nuevo");
        btn_nuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nuevoActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Dirección:");

        txt_dirProveedor.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel14.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Estado:");

        cob_estado.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cob_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txt_IdProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txt_buscarProveedor)
                                .addGap(18, 18, 18)
                                .addComponent(btn_buscar))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_dirProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txt_nombreProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_telProveedor))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(6, 6, 6)
                                .addComponent(txt_nitProveedor))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_nuevo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_guardar)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addGap(18, 18, 18)
                                .addComponent(cob_estado, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(114, 114, 114))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addGap(18, 18, 18)
                                .addComponent(cob_ciudadProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 131, Short.MAX_VALUE)
                                .addComponent(txt_emailProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(jLabel10)))))
                .addGap(28, 28, 28))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(txt_IdProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(btn_buscar)
                    .addComponent(txt_buscarProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_nitProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txt_nombreProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txt_telProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_dirProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txt_emailProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(cob_ciudadProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(cob_estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_guardar)
                    .addComponent(btn_nuevo))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed

        if (txt_nitProveedor.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingresa un nit para el proveedor");
            txt_nitProveedor.requestFocus();
            return;
        }
        if (txt_nombreProveedor.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingresa un nombre");
            txt_nombreProveedor.requestFocus();
            return;
        }
        if (cob_ciudadProveedor.getSelectedItem().toString().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes elegir una ciudad");
            cob_ciudadProveedor.requestFocus();
            return;
        }
        if (txt_dirProveedor.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingresa una dirección");
            txt_dirProveedor.requestFocus();
            return;
        }
        if (txt_telProveedor.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingresa un número de contacto");
            txt_telProveedor.requestFocus();
            return;
        }
        if (txt_emailProveedor.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingresa un correo eléctronico");
            txt_emailProveedor.requestFocus();
            return;
        }

        Modelo_proveedor dtsProveedor = new Modelo_proveedor();

        dtsProveedor.setNumeroIdentidad(txt_nitProveedor.getText());
        dtsProveedor.setNombre(txt_nombreProveedor.getText());
        dtsProveedor.setCiudadProveedor(cob_ciudadProveedor.getSelectedItem().toString());
        dtsProveedor.setDireccion(txt_dirProveedor.getText());
        dtsProveedor.setTelefono(txt_telProveedor.getText());
        dtsProveedor.setEmail(txt_emailProveedor.getText());
        dtsProveedor.setEstado(cob_estado.getSelectedItem().toString());

        if (accion.equals("nuevo")) {
            control.nuevoProveedor(dtsProveedor);
            inhabilitar();
        } else if (accion.equals("editar")) {
            dtsProveedor.setIdProveedor(Integer.parseInt(txt_IdProveedor.getText()));
            control.editarProveedor(dtsProveedor);
            inhabilitar();
        }


    }//GEN-LAST:event_btn_guardarActionPerformed

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed

        buscarProveedor();

    }//GEN-LAST:event_btn_buscarActionPerformed

    private void btn_nuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_nuevoActionPerformed

        btn_guardar.setText("Guardar");
        accion = "nuevo";
        txt_nombreProveedor.requestFocus();

        habilitar();

    }//GEN-LAST:event_btn_nuevoActionPerformed

    private void txt_buscarProveedorKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_buscarProveedorKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            buscarProveedor();
        }
    }//GEN-LAST:event_txt_buscarProveedorKeyPressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista_proveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista_proveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista_proveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista_proveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vista_proveedor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JButton btn_nuevo;
    private javax.swing.JComboBox<String> cob_ciudadProveedor;
    private javax.swing.JComboBox<String> cob_estado;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txt_IdProveedor;
    private javax.swing.JTextField txt_buscarProveedor;
    private javax.swing.JTextField txt_dirProveedor;
    private javax.swing.JTextField txt_emailProveedor;
    private javax.swing.JTextField txt_nitProveedor;
    private javax.swing.JTextField txt_nombreProveedor;
    private javax.swing.JTextField txt_telProveedor;
    // End of variables declaration//GEN-END:variables
}
