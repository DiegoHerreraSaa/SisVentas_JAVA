package vista;

import controlador.Control_empleado;
import java.awt.event.KeyEvent;
import java.sql.Date;
import java.util.Calendar;
import javax.swing.JOptionPane;
import modelo.Modelo_empleado;

public class Vista_empleado extends javax.swing.JInternalFrame {

    Control_empleado control = new Control_empleado();
    private String accion;

    public Vista_empleado() {
        initComponents();
        setTitle("Empleados");

        control.llenarCob_tipoId(cob_tipoIdentidad);
        control.llenarCob_rolEmpleado(cob_rolEmpleado);
        control.llenarCob_cargoEmpleado(cob_cargoEmpleado);
        txt_buscarEmpleado.requestFocus();
        inhabilitar();

    }

    void inhabilitar() {
        txt_idEmpleado.setVisible(false);

        cob_tipoIdentidad.setEnabled(false);
        txt_numeroDocumento.setEnabled(false);
        txt_1erNombre.setEnabled(false);
        txt_2doNombre.setEnabled(false);
        txt_1erApellido.setEnabled(false);
        txt_2doApellido.setEnabled(false);
        dc_fNacimiento.setEnabled(false);
        cob_sexo.setEnabled(false);
        txt_telEmpleado.setEnabled(false);
        txt_dirEmpleado.setEnabled(false);
        cob_rolEmpleado.setEnabled(false);
        cob_cargoEmpleado.setEnabled(false);
        cob_hEntrada.setEnabled(false);
        cob_hSalida.setEnabled(false);
        cob_estado.setEnabled(false);

        btn_guardar.setEnabled(false);

        txt_idEmpleado.setText("");

        txt_numeroDocumento.setText("");
        txt_1erNombre.setText("");
        txt_2doNombre.setText("");
        txt_1erApellido.setText("");
        txt_2doApellido.setText("");
        txt_telEmpleado.setText("");
        txt_dirEmpleado.setText("");

        cob_tipoIdentidad.setSelectedItem("Cédula Ciudadania");
        cob_cargoEmpleado.setSelectedItem("- Seleccione cargo -");
        cob_rolEmpleado.setSelectedItem("- Seleccione Rol -");
        cob_hEntrada.setSelectedItem("- Hora -");
        cob_hSalida.setSelectedItem("- Hora -");

        btn_guardar.setText("Guardar");
        txt_buscarEmpleado.requestFocus();

    }

    void habilitar() {
        txt_idEmpleado.setVisible(false);

        cob_tipoIdentidad.setEnabled(true);
        txt_numeroDocumento.setEnabled(true);
        txt_1erNombre.setEnabled(true);
        txt_2doNombre.setEnabled(true);
        txt_1erApellido.setEnabled(true);
        txt_2doApellido.setEnabled(true);
        dc_fNacimiento.setEnabled(true);
        cob_sexo.setEnabled(true);
        txt_telEmpleado.setEnabled(true);
        txt_dirEmpleado.setEnabled(true);
        cob_rolEmpleado.setEnabled(true);
        cob_cargoEmpleado.setEnabled(true);
        cob_hEntrada.setEnabled(true);
        cob_hSalida.setEnabled(true);
        cob_estado.setEnabled(true);

        btn_guardar.setEnabled(true);

        txt_idEmpleado.setText("");

        txt_numeroDocumento.setText("");
        txt_1erNombre.setText("");
        txt_2doNombre.setText("");
        txt_1erApellido.setText("");
        txt_2doApellido.setText("");
        txt_telEmpleado.setText("");
        txt_dirEmpleado.setText("");
        txt_buscarEmpleado.setText("");

        cob_tipoIdentidad.setSelectedItem("Cédula Ciudadania");
        cob_cargoEmpleado.setSelectedItem("- Seleccione cargo -");
        cob_rolEmpleado.setSelectedItem("- Seleccione Rol -");
        cob_hEntrada.setSelectedItem("- Hora -");
        cob_hSalida.setSelectedItem("- Hora -");

        btn_guardar.setText("Guardar");

    }
    
    void buscarEmpleado(){
        if(txt_buscarEmpleado.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Ingresa un numero de identificación a buscar");
            txt_buscarEmpleado.requestFocus();
            return;
        }
        Modelo_empleado dtsEmpleado = new Modelo_empleado();
        dtsEmpleado.setNumeroIdentidad(txt_buscarEmpleado.getText());

        control.mostrar_busqueda(dtsEmpleado);

        if (control.consulta_existe(dtsEmpleado) == 1) {
            habilitar();
            txt_idEmpleado.setText(dtsEmpleado.getIdEmpleados());

            cob_tipoIdentidad.setSelectedItem(dtsEmpleado.getNomTipoId());
            txt_numeroDocumento.setText(dtsEmpleado.getNumeroIdentidad());
            txt_1erNombre.setText(dtsEmpleado.getPrimerNombre());
            txt_2doNombre.setText(dtsEmpleado.getSegundoNombre());
            txt_1erApellido.setText(dtsEmpleado.getPrimerApellido());
            txt_2doApellido.setText(dtsEmpleado.getSegundoApellido());
            dc_fNacimiento.setDate(dtsEmpleado.getFechaNac());
            cob_sexo.setSelectedItem(dtsEmpleado.getSexo());
            txt_telEmpleado.setText(dtsEmpleado.getTelefono());
            txt_dirEmpleado.setText(dtsEmpleado.getDireccion());
            cob_rolEmpleado.setSelectedItem(dtsEmpleado.getNomRol());
            cob_cargoEmpleado.setSelectedItem(dtsEmpleado.getNomCargo());
            cob_hEntrada.setSelectedItem(dtsEmpleado.getHoraEntrada());
            cob_hSalida.setSelectedItem(dtsEmpleado.getHoraSalida());
            cob_estado.setSelectedItem(dtsEmpleado.getEstado());

            cob_tipoIdentidad.setEnabled(false);
            txt_numeroDocumento.setEnabled(false);

            btn_guardar.setText("Editar");
            accion = "editar";

        } else if (control.consulta_existe(dtsEmpleado) == 0) {
            JOptionPane.showMessageDialog(null, "El empleado no se encuentra registrado");
            txt_buscarEmpleado.setText("");
            inhabilitar();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        txt_2doNombre = new javax.swing.JTextField();
        btn_nuevo = new javax.swing.JButton();
        txt_idEmpleado = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        cob_sexo = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        dc_fNacimiento = new com.toedter.calendar.JDateChooser();
        jLabel8 = new javax.swing.JLabel();
        txt_dirEmpleado = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btn_guardar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        cob_tipoIdentidad = new javax.swing.JComboBox<>();
        txt_numeroDocumento = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        btn_buscar = new javax.swing.JButton();
        txt_buscarEmpleado = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        cob_rolEmpleado = new javax.swing.JComboBox<>();
        txt_telEmpleado = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_1erNombre = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txt_1erApellido = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txt_2doApellido = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        cob_hEntrada = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        cob_hSalida = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        cob_cargoEmpleado = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        cob_estado = new javax.swing.JComboBox<>();

        setClosable(true);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setIconifiable(true);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "ADMINISTRADOR DE EMPLEADOS", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 18), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jPanel1KeyPressed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Segundo nombre:");

        txt_2doNombre.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        btn_nuevo.setBackground(new java.awt.Color(51, 51, 51));
        btn_nuevo.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_nuevo.setForeground(new java.awt.Color(255, 255, 255));
        btn_nuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/checkShadow.png"))); // NOI18N
        btn_nuevo.setText("Nuevo");
        btn_nuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nuevoActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Sexo:");

        cob_sexo.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cob_sexo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M", "F" }));

        jLabel7.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Fecha de Nacimiento:");

        jLabel8.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Dirección:");

        txt_dirEmpleado.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        btn_guardar.setBackground(new java.awt.Color(51, 51, 51));
        btn_guardar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_guardar.setForeground(new java.awt.Color(255, 255, 255));
        btn_guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/guardar.png"))); // NOI18N
        btn_guardar.setText("Guardar");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Tipo de identidad:");

        cob_tipoIdentidad.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cob_tipoIdentidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cob_tipoIdentidadActionPerformed(evt);
            }
        });

        txt_numeroDocumento.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Número identidad:");

        jLabel9.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Teléfono:");

        jLabel13.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Buscar empleado por número de documento:");

        btn_buscar.setBackground(new java.awt.Color(51, 51, 51));
        btn_buscar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_buscar.setForeground(new java.awt.Color(255, 255, 255));
        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/search.png"))); // NOI18N
        btn_buscar.setText("Buscar");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });

        txt_buscarEmpleado.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        txt_buscarEmpleado.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_buscarEmpleadoKeyPressed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Rol:");

        cob_rolEmpleado.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        txt_telEmpleado.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Primer nombre:");

        txt_1erNombre.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel14.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Primer apellido:");

        txt_1erApellido.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel15.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Segundo apellido:");

        txt_2doApellido.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel16.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Hora entrada:");

        cob_hEntrada.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cob_hEntrada.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Hora -", "12:00:00 a. m.", "12:30:00 a. m.", "1:00:00 a. m.", "1:30:00 a. m.", "2:00:00 a. m.", "2:30:00 a. m.", "3:00:00 a. m.", "3:30:00 a. m.", "4:00:00 a. m.", "4:30:00 a. m.", "5:00:00 a. m.", "5:30:00 a. m.", "6:00:00 a. m.", "6:30:00 a. m.", "7:00:00 a. m.", "7:30:00 a. m.", "8:00:00 a. m.", "8:30:00 a. m.", "9:00:00 a. m.", "9:30:00 a. m.", "10:00:00 a. m.", "10:30:00 a. m.", "11:00:00 a. m.", "11:30:00 a. m.", "12:00:00 p. m.", "12:30:00 p. m.", "1:00:00 p. m.", "1:30:00 p. m.", "2:00:00 p. m.", "2:30:00 p. m.", "3:00:00 p. m.", "3:30:00 p. m.", "4:00:00 p. m.", "4:30:00 p. m.", "5:00:00 p. m.", "5:30:00 p. m.", "6:00:00 p. m.", "6:30:00 p. m.", "7:00:00 p. m.", "7:30:00 p. m.", "8:00:00 p. m.", "8:30:00 p. m.", "9:00:00 p. m.", "9:30:00 p. m.", "10:00:00 p. m.", "10:30:00 p. m.", "11:00:00 p. m.", "11:30:00 p. m." }));

        jLabel17.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Hora salida:");

        cob_hSalida.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cob_hSalida.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Hora -", "12:00:00 a. m.", "12:30:00 a. m.", "1:00:00 a. m.", "1:30:00 a. m.", "2:00:00 a. m.", "2:30:00 a. m.", "3:00:00 a. m.", "3:30:00 a. m.", "4:00:00 a. m.", "4:30:00 a. m.", "5:00:00 a. m.", "5:30:00 a. m.", "6:00:00 a. m.", "6:30:00 a. m.", "7:00:00 a. m.", "7:30:00 a. m.", "8:00:00 a. m.", "8:30:00 a. m.", "9:00:00 a. m.", "9:30:00 a. m.", "10:00:00 a. m.", "10:30:00 a. m.", "11:00:00 a. m.", "11:30:00 a. m.", "12:00:00 p. m.", "12:30:00 p. m.", "1:00:00 p. m.", "1:30:00 p. m.", "2:00:00 p. m.", "2:30:00 p. m.", "3:00:00 p. m.", "3:30:00 p. m.", "4:00:00 p. m.", "4:30:00 p. m.", "5:00:00 p. m.", "5:30:00 p. m.", "6:00:00 p. m.", "6:30:00 p. m.", "7:00:00 p. m.", "7:30:00 p. m.", "8:00:00 p. m.", "8:30:00 p. m.", "9:00:00 p. m.", "9:30:00 p. m.", "10:00:00 p. m.", "10:30:00 p. m.", "11:00:00 p. m.", "11:30:00 p. m." }));

        jLabel19.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Cargo:");

        cob_cargoEmpleado.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel18.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Estado:");

        cob_estado.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cob_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(dc_fNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addComponent(cob_sexo, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txt_telEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(32, 32, 32)
                                .addComponent(txt_dirEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btn_nuevo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn_guardar))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel16)
                                        .addComponent(jLabel17))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(cob_hSalida, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(cob_hEntrada, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(112, 112, 112)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel19)
                                        .addComponent(jLabel12))
                                    .addGap(25, 25, 25)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(cob_cargoEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(cob_estado, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txt_idEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel13)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(txt_buscarEmpleado)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(btn_buscar))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel2)
                                                .addComponent(jLabel4))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(txt_1erNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(cob_tipoIdentidad, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(txt_1erApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel14)
                                            .addGap(244, 244, 244)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel5)
                                                .addComponent(jLabel15)
                                                .addComponent(jLabel3))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(txt_2doNombre, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                                .addComponent(txt_numeroDocumento, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                                .addComponent(txt_2doApellido, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)))
                                        .addComponent(cob_rolEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(96, 96, 96))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txt_idEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(btn_buscar)
                    .addComponent(txt_buscarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cob_tipoIdentidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_numeroDocumento, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_1erNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(txt_2doNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(txt_1erApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(txt_2doApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(dc_fNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(cob_sexo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(txt_telEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel7))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txt_dirEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cob_rolEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(cob_hEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel18)
                                .addComponent(cob_estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel17)
                                .addComponent(cob_hSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(cob_cargoEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_guardar)
                    .addComponent(btn_nuevo))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 691, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed

        buscarEmpleado();

    }//GEN-LAST:event_btn_buscarActionPerformed

    private void cob_tipoIdentidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cob_tipoIdentidadActionPerformed

    }//GEN-LAST:event_cob_tipoIdentidadActionPerformed

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed

        if (txt_numeroDocumento.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes ingresar el número de documento");
            txt_numeroDocumento.requestFocus();
            return;
        }
        if (txt_1erNombre.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes ingresar el primer nombre del cliente");
            txt_1erNombre.requestFocus();
            return;
        }
        if (txt_1erApellido.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes ingresar el primer apellido del cliente");
            txt_1erApellido.requestFocus();
            return;
        }
        if (txt_2doApellido.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes ingresar el segundo apellido del cliente");
            txt_2doApellido.requestFocus();
            return;
        }
        if (dc_fNacimiento.getDate() == null) {
            JOptionPane.showMessageDialog(null, "Debes elegir una fecha de nacimiento");
            dc_fNacimiento.requestFocus();
            return;
        }
        if (txt_telEmpleado.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes ingresar un número de contacto");
            txt_telEmpleado.requestFocus();
            return;
        }
        if (txt_dirEmpleado.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes ingresar una dirección");
            txt_dirEmpleado.requestFocus();
            return;
        }
        if (cob_rolEmpleado.getSelectedItem().toString().equals("- Seleccione Rol -")) {
            JOptionPane.showMessageDialog(null, "Debes seleccionar un rol");
            cob_rolEmpleado.requestFocus();
            return;
        }
        if (cob_cargoEmpleado.getSelectedItem().toString().equals("- Seleccione cargo -")) {
            JOptionPane.showMessageDialog(null, "Debes seleccionar un cargo");
            cob_cargoEmpleado.requestFocus();
            return;
        }
        if (cob_hEntrada.getSelectedItem().toString().equals("- Hora -")) {
            JOptionPane.showMessageDialog(null, "Debes elegir una hora de entrada");
            cob_hEntrada.requestFocus();
            return;
        }
        if (cob_hSalida.getSelectedItem().toString().equals("- Hora -")) {
            JOptionPane.showMessageDialog(null, "Debes elegir una hora de salida");
            cob_hSalida.requestFocus();
            return;
        }

        Modelo_empleado dtsEmpleado = new Modelo_empleado();

        dtsEmpleado.setPrimerNombre(txt_1erNombre.getText());
        dtsEmpleado.setSegundoNombre(txt_2doNombre.getText());
        dtsEmpleado.setPrimerApellido(txt_1erApellido.getText());
        dtsEmpleado.setSegundoApellido(txt_2doApellido.getText());
        dtsEmpleado.setNomRol(cob_rolEmpleado.getSelectedItem().toString());
        dtsEmpleado.setSexo(cob_sexo.getSelectedItem().toString());
        dtsEmpleado.setNomTipoId(cob_tipoIdentidad.getSelectedItem().toString());
        dtsEmpleado.setNumeroIdentidad(txt_numeroDocumento.getText());

        // Captura fecha
        Calendar cal;
        int d, m, a;
        cal = dc_fNacimiento.getCalendar();
        d = cal.get(Calendar.DAY_OF_MONTH);
        m = cal.get(Calendar.MONTH);
        a = cal.get(Calendar.YEAR) - 1900;
        dtsEmpleado.setFechaNac(new Date(a, m, d));

        dtsEmpleado.setNomCargo(cob_cargoEmpleado.getSelectedItem().toString());
        dtsEmpleado.setDireccion(txt_dirEmpleado.getText());
        dtsEmpleado.setTelefono(txt_telEmpleado.getText());
        dtsEmpleado.setHoraEntrada(cob_hEntrada.getSelectedItem().toString());
        dtsEmpleado.setHoraSalida(cob_hSalida.getSelectedItem().toString());
        dtsEmpleado.setEstado(cob_estado.getSelectedItem().toString());

        if (accion.equals("nuevo")) {
            if (control.consulta_existe(dtsEmpleado) == 0) {
                control.nuevoEmpleado(dtsEmpleado);
            } else if (control.consulta_existe(dtsEmpleado) == 1) {
                JOptionPane.showMessageDialog(null, "El empleado ya se encuentra registrado");
            }
        } else if (accion.equals("editar")) {
            dtsEmpleado.setIdEmpleados(txt_idEmpleado.getText());
            control.editarEmpleado(dtsEmpleado);
        }

        inhabilitar();

    }//GEN-LAST:event_btn_guardarActionPerformed

    private void btn_nuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_nuevoActionPerformed

        accion = "nuevo";

        habilitar();
        txt_numeroDocumento.requestFocus();

    }//GEN-LAST:event_btn_nuevoActionPerformed

    private void txt_buscarEmpleadoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_buscarEmpleadoKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            buscarEmpleado();
        }
    }//GEN-LAST:event_txt_buscarEmpleadoKeyPressed

    private void jPanel1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jPanel1KeyPressed
    }//GEN-LAST:event_jPanel1KeyPressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista_empleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista_empleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista_empleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista_empleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vista_empleado().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JButton btn_nuevo;
    private javax.swing.JComboBox<String> cob_cargoEmpleado;
    private javax.swing.JComboBox<String> cob_estado;
    private javax.swing.JComboBox<String> cob_hEntrada;
    private javax.swing.JComboBox<String> cob_hSalida;
    private javax.swing.JComboBox<String> cob_rolEmpleado;
    private javax.swing.JComboBox<String> cob_sexo;
    private javax.swing.JComboBox<String> cob_tipoIdentidad;
    private com.toedter.calendar.JDateChooser dc_fNacimiento;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txt_1erApellido;
    private javax.swing.JTextField txt_1erNombre;
    private javax.swing.JTextField txt_2doApellido;
    private javax.swing.JTextField txt_2doNombre;
    private javax.swing.JTextField txt_buscarEmpleado;
    private javax.swing.JTextField txt_dirEmpleado;
    private javax.swing.JTextField txt_idEmpleado;
    private javax.swing.JTextField txt_numeroDocumento;
    private javax.swing.JTextField txt_telEmpleado;
    // End of variables declaration//GEN-END:variables
}
