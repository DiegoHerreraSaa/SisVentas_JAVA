package vista;

import conexion.Conexion;
import controlador.Control_tipoCaja;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import modelo.Modelo_tipoCaja;

public class Vista_tipoCaja extends javax.swing.JInternalFrame {

    private String accion;
    Control_tipoCaja control = new Control_tipoCaja();

    public Vista_tipoCaja() {
        initComponents();
        setTitle("Tipos de caja");

        control.llenarCob_tipoCaja(cob_idCaja);
        inhabilitar();

    }

    void inhabilitar() {

        txt_idTpoCaja.setEnabled(false);
        txt_nombreCaja.setEnabled(false);
        cob_estado.setEnabled(false);

        btn_guardar.setEnabled(false);

        txt_idTpoCaja.setText("");
        txt_nombreCaja.setText("");

        cob_idCaja.setSelectedItem("Buscar");
        cob_estado.setSelectedItem("Activo");
    }

    void habilitar() {

        txt_idTpoCaja.setEditable(false);
        txt_nombreCaja.setEnabled(true);
        cob_estado.setEnabled(true);

        btn_guardar.setEnabled(true);

        txt_idTpoCaja.setText("");
        txt_nombreCaja.setText("");

        cob_idCaja.setSelectedItem("Buscar");
        cob_estado.setSelectedItem("Activo");
    }
    
    void buscarTipoCaja(){
        if (cob_idCaja.getSelectedItem().toString().equals("Buscar")) {
            JOptionPane.showMessageDialog(null, "Selecciona un tipo a buscar");
            cob_idCaja.requestFocus();
            return;
        }
        Conexion conexion = new Conexion();
        String sql = " SELECT * FROM tipocaja WHERE IdTipoCaja LIKE '" + cob_idCaja.getSelectedItem().toString() + "' ";
        ResultSet rs = conexion.consultar(sql);

        try {
            habilitar();
            while (rs.next()) {
                txt_idTpoCaja.setText(rs.getString("IdTipoCaja"));
                txt_nombreCaja.setText(rs.getString("Nombre"));
                cob_estado.setSelectedItem(rs.getString("estado"));
            }
            btn_guardar.setText("Editar");
            accion = "editar";
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al buscar tipo caja " + e);
            inhabilitar();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        btn_buscar = new javax.swing.JButton();
        btn_guardar = new javax.swing.JButton();
        cob_idCaja = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        txt_idTpoCaja = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        btn_nuevo = new javax.swing.JButton();
        txt_nombreCaja = new javax.swing.JTextField();
        cob_estado = new javax.swing.JComboBox<>();

        setClosable(true);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setIconifiable(true);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "ADMINISTRADOR TIPO CAJA", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 18), new java.awt.Color(255, 255, 255))); // NOI18N

        jLabel6.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Buscar  No:");

        btn_buscar.setBackground(new java.awt.Color(51, 51, 51));
        btn_buscar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_buscar.setForeground(new java.awt.Color(255, 255, 255));
        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/search.png"))); // NOI18N
        btn_buscar.setText("Buscar");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });

        btn_guardar.setBackground(new java.awt.Color(51, 51, 51));
        btn_guardar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_guardar.setForeground(new java.awt.Color(255, 255, 255));
        btn_guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/guardar.png"))); // NOI18N
        btn_guardar.setText("Guardar");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });

        cob_idCaja.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cob_idCajaKeyPressed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Id Tipo Caja:");

        txt_idTpoCaja.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        txt_idTpoCaja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_idTpoCajaActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Nombre:");

        btn_nuevo.setBackground(new java.awt.Color(51, 51, 51));
        btn_nuevo.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_nuevo.setForeground(new java.awt.Color(255, 255, 255));
        btn_nuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/checkShadow.png"))); // NOI18N
        btn_nuevo.setText("Nuevo");
        btn_nuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nuevoActionPerformed(evt);
            }
        });

        txt_nombreCaja.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        txt_nombreCaja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nombreCajaActionPerformed(evt);
            }
        });

        cob_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txt_idTpoCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cob_idCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                                .addComponent(btn_buscar))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txt_nombreCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cob_estado, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btn_nuevo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_guardar)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(btn_buscar)
                    .addComponent(txt_idTpoCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(cob_idCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cob_estado)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_nombreCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5)))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_nuevo)
                    .addComponent(btn_guardar))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed

        buscarTipoCaja();

    }//GEN-LAST:event_btn_buscarActionPerformed

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed

        if (txt_nombreCaja.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes ingresar un nombre al tipo de caja");
            txt_nombreCaja.requestFocus();
            return;
        }

        Modelo_tipoCaja dtsTipoCaja = new Modelo_tipoCaja();

        dtsTipoCaja.setNombre(txt_nombreCaja.getText());
        dtsTipoCaja.setEstado(cob_estado.getSelectedItem().toString());

        if (accion.equals("nuevo")) {
            control.nuevoTipoCaja(dtsTipoCaja);
            cob_idCaja.removeAllItems();
            control.llenarCob_tipoCaja(cob_idCaja);
            inhabilitar();
        } else if (accion.equals("editar")) {
            dtsTipoCaja.setIdTipoCaja(Integer.parseInt(txt_idTpoCaja.getText()));
            control.editarTipoCaja(dtsTipoCaja);
            cob_idCaja.removeAllItems();
            control.llenarCob_tipoCaja(cob_idCaja);
            inhabilitar();
        }

    }//GEN-LAST:event_btn_guardarActionPerformed

    private void btn_nuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_nuevoActionPerformed

        btn_guardar.setText("Guardar");
        accion = "nuevo";

        txt_nombreCaja.requestFocus();

        habilitar();

    }//GEN-LAST:event_btn_nuevoActionPerformed

    private void txt_idTpoCajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_idTpoCajaActionPerformed
        txt_nombreCaja.requestFocus();
    }//GEN-LAST:event_txt_idTpoCajaActionPerformed

    private void txt_nombreCajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nombreCajaActionPerformed
        btn_guardar.requestFocus();
    }//GEN-LAST:event_txt_nombreCajaActionPerformed

    private void cob_idCajaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cob_idCajaKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            buscarTipoCaja();
        }
    }//GEN-LAST:event_cob_idCajaKeyPressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista_tipoCaja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista_tipoCaja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista_tipoCaja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista_tipoCaja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vista_tipoCaja().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JButton btn_nuevo;
    private javax.swing.JComboBox<String> cob_estado;
    private javax.swing.JComboBox<String> cob_idCaja;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txt_idTpoCaja;
    private javax.swing.JTextField txt_nombreCaja;
    // End of variables declaration//GEN-END:variables
}
