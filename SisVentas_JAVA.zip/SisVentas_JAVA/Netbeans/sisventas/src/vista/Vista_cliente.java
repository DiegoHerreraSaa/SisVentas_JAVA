package vista;

import com.sun.glass.events.KeyEvent;
import conexion.Conexion;
import controlador.*;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JOptionPane;
import modelo.*;

public class Vista_cliente extends javax.swing.JInternalFrame {

    Control_cliente control = new Control_cliente();

    public Vista_cliente() {
        initComponents();
        setTitle("Clientes");

        control.Consultar_barrio(cob_barrioCliente);
        control.Consultar_ciudad(cob_ciudadCliente);

        llenar_tipo(); // Codigo Alejandro ComboBox - tipo identidad

        inhabilitar();

    }

    private String accion;

    void inhabilitar() {
        txt_codigoCliente.setVisible(false);

        cob_tipoIdentidad.setEnabled(false);
        txt_numeroDocumento.setEnabled(false);
        txt_nombreCliente.setEnabled(false);
        cob_genero.setEnabled(false);
        txt_apellidoCliente.setEnabled(false);
        dc_fNacimiento.setEnabled(false);
        txt_dirCliente.setEnabled(false);
        txt_telCliente.setEnabled(false);
        txt_emailCliente.setEnabled(false);
        cob_barrioCliente.setEnabled(false);
        cob_ciudadCliente.setEnabled(false);
        cob_estado.setEnabled(false);

        btn_agregarBarrio.setEnabled(false);
        btn_guardar.setEnabled(false);
        btn_recargar.setEnabled(false);

        txt_buscarCliente.setText("");
        txt_numeroDocumento.setText("");
        txt_nombreCliente.setText("");
        txt_apellidoCliente.setText("");
        txt_dirCliente.setText("");
        txt_telCliente.setText("");
        txt_emailCliente.setText("");
        txt_codigoCliente.setText("");
        cob_tipoIdentidad.setSelectedItem("Cédula Ciudadania");
        cob_barrioCliente.setSelectedItem("- Barrio -");
        cob_ciudadCliente.setSelectedItem("- Ciudad -");
        cob_estado.setSelectedItem("Activo");
    }

    void habilitar() {
        txt_codigoCliente.setVisible(false);

        cob_tipoIdentidad.setEnabled(true);
        txt_numeroDocumento.setEnabled(true);
        txt_nombreCliente.setEnabled(true);
        cob_genero.setEnabled(true);
        txt_apellidoCliente.setEnabled(true);
        dc_fNacimiento.setEnabled(true);
        txt_dirCliente.setEnabled(true);
        txt_telCliente.setEnabled(true);
        txt_emailCliente.setEnabled(true);
        cob_barrioCliente.setEnabled(true);
        cob_ciudadCliente.setEnabled(true);
        cob_estado.setEnabled(true);

        btn_agregarBarrio.setEnabled(true);
        btn_guardar.setEnabled(true);
        btn_nuevo.setEnabled(true);
        btn_recargar.setEnabled(true);

        txt_buscarCliente.setText("");
        txt_numeroDocumento.setText("");
        txt_nombreCliente.setText("");
        txt_apellidoCliente.setText("");
        txt_dirCliente.setText("");
        txt_telCliente.setText("");
        txt_emailCliente.setText("");
        cob_tipoIdentidad.setSelectedItem("Cédula Ciudadania");
        cob_barrioCliente.setSelectedItem("- Barrio -");
        cob_ciudadCliente.setSelectedItem("- Ciudad -");
        cob_estado.setSelectedItem("Activo");
    }
    
    void buscarCliente(){
        if(txt_buscarCliente.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Ingresa un numero de identificación a buscar");
            txt_buscarCliente.requestFocus();
            return;
        }
        Conexion conexion = new Conexion();
        String sql = " SELECT c.*, b.Nombre AS barrio, ti.NombreTipoIdentidad AS nomID, CONCAT(cd.Nombre,\" - \",cd.Departamento) AS ciudad "
                + " FROM cliente c JOIN tipoidentidad ti ON ti.IdTipoIdentidad = c.IdTipoIdentidad1 "
                + " JOIN barrio b ON c.IdBarrio1 = b.IdBarrio "
                + " JOIN ciudad cd ON c.CodigoCiudad1 = cd.CodigoCiudad "
                + " WHERE c.NumeroDocumento LIKE '" + txt_buscarCliente.getText() + "' ";
        ResultSet rs = conexion.consultar(sql);

        try {
            if (rs.next()) {
                rs.beforeFirst();
                habilitar();
                while (rs.next()) {
                    cob_tipoIdentidad.setSelectedItem(rs.getString("nomID"));
                    txt_numeroDocumento.setText(rs.getString("NumeroDocumento"));
                    txt_nombreCliente.setText(rs.getString("Nombre"));
                    txt_apellidoCliente.setText(rs.getString("Apellido"));
                    cob_genero.setSelectedItem(rs.getString("Genero"));
                    dc_fNacimiento.setDate(rs.getDate("FechaNacimiento"));
                    txt_dirCliente.setText(rs.getString("Direccion"));
                    txt_telCliente.setText(rs.getString("Telefono"));
                    txt_emailCliente.setText(rs.getString("Email"));
                    cob_barrioCliente.setSelectedItem(rs.getString("barrio"));
                    cob_ciudadCliente.setSelectedItem(rs.getString("ciudad"));
                    cob_estado.setSelectedItem(rs.getString("estado"));

                    txt_codigoCliente.setText(rs.getString("CodigoCliente"));
                }
                btn_guardar.setText("Editar");
                accion = "editar";

            } else {
                JOptionPane.showMessageDialog(null, "El cliente no esta registrado");
                inhabilitar();
                txt_buscarCliente.requestFocus();
            }

        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Error en consulta cliente " + e);
            inhabilitar();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txt_emailCliente = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        cob_barrioCliente = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        cob_ciudadCliente = new javax.swing.JComboBox<>();
        txt_telCliente = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_nombreCliente = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txt_apellidoCliente = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        cob_genero = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        dc_fNacimiento = new com.toedter.calendar.JDateChooser();
        jLabel8 = new javax.swing.JLabel();
        txt_dirCliente = new javax.swing.JTextField();
        btn_guardar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        cob_tipoIdentidad = new javax.swing.JComboBox<>();
        txt_numeroDocumento = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btn_agregarBarrio = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        btn_buscarCliente = new javax.swing.JButton();
        txt_buscarCliente = new javax.swing.JTextField();
        btn_nuevo = new javax.swing.JButton();
        txt_codigoCliente = new javax.swing.JTextField();
        btn_recargar = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        cob_estado = new javax.swing.JComboBox<>();

        setClosable(true);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setIconifiable(true);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "ADMINISTRADOR DE CLIENTES", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 18), new java.awt.Color(255, 255, 255))); // NOI18N

        txt_emailCliente.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel11.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Barrio:");

        cob_barrioCliente.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel12.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Ciudad:");

        cob_ciudadCliente.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        txt_telCliente.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Nombre:");

        txt_nombreCliente.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Apellido:");

        txt_apellidoCliente.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Género:");

        cob_genero.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cob_genero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M", "F" }));

        jLabel7.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Fecha de Nacimiento:");

        jLabel8.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Dirección:");

        txt_dirCliente.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        btn_guardar.setBackground(new java.awt.Color(51, 51, 51));
        btn_guardar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_guardar.setForeground(new java.awt.Color(255, 255, 255));
        btn_guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/guardar.png"))); // NOI18N
        btn_guardar.setText("Guardar");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Tipo de identidad:");

        cob_tipoIdentidad.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cob_tipoIdentidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cob_tipoIdentidadActionPerformed(evt);
            }
        });

        txt_numeroDocumento.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Número:");

        btn_agregarBarrio.setBackground(new java.awt.Color(51, 51, 51));
        btn_agregarBarrio.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_agregarBarrio.setForeground(new java.awt.Color(255, 255, 255));
        btn_agregarBarrio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/mas.png"))); // NOI18N
        btn_agregarBarrio.setText("Agregar Barrio");
        btn_agregarBarrio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregarBarrioActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Teléfono:");

        jLabel10.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Correo Electrónico:");

        jLabel13.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Buscar cliente por Num Documento:");

        btn_buscarCliente.setBackground(new java.awt.Color(51, 51, 51));
        btn_buscarCliente.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_buscarCliente.setForeground(new java.awt.Color(255, 255, 255));
        btn_buscarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/search.png"))); // NOI18N
        btn_buscarCliente.setText("Buscar");
        btn_buscarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarClienteActionPerformed(evt);
            }
        });

        txt_buscarCliente.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        txt_buscarCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_buscarClienteKeyPressed(evt);
            }
        });

        btn_nuevo.setBackground(new java.awt.Color(51, 51, 51));
        btn_nuevo.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_nuevo.setForeground(new java.awt.Color(255, 255, 255));
        btn_nuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/checkShadow.png"))); // NOI18N
        btn_nuevo.setText("Nuevo");
        btn_nuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nuevoActionPerformed(evt);
            }
        });

        btn_recargar.setBackground(new java.awt.Color(51, 51, 51));
        btn_recargar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        btn_recargar.setForeground(new java.awt.Color(255, 255, 255));
        btn_recargar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/refrescar.png"))); // NOI18N
        btn_recargar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_recargarActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Estado:");

        cob_estado.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cob_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cob_barrioCliente, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_dirCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel10))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_nuevo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_guardar))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(txt_codigoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel13)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(txt_buscarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(btn_buscarCliente)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addComponent(btn_agregarBarrio, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btn_recargar, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel14)
                            .addGap(18, 18, 18)
                            .addComponent(cob_estado, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(104, 104, 104))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel11)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel12)
                            .addGap(18, 18, 18)
                            .addComponent(cob_ciudadCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txt_emailCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel7)
                                    .addGap(6, 6, 6)
                                    .addComponent(dc_fNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jLabel6)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(cob_genero, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jLabel9)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txt_telCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel4)
                                            .addGap(19, 19, 19)
                                            .addComponent(txt_nombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel5)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel2)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(cob_tipoIdentidad, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel3))))
                                    .addGap(6, 6, 6)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txt_numeroDocumento, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                        .addComponent(txt_apellidoCliente)))))))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(txt_codigoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(btn_buscarCliente)
                    .addComponent(txt_buscarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cob_tipoIdentidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_numeroDocumento, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_nombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(txt_apellidoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(6, 6, 6)
                            .addComponent(jLabel7))
                        .addComponent(dc_fNacimiento, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6)
                        .addComponent(cob_genero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9)
                        .addComponent(txt_telCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_dirCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel10)
                    .addComponent(txt_emailCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(cob_barrioCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(cob_ciudadCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_recargar)
                    .addComponent(btn_agregarBarrio)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel14)
                        .addComponent(cob_estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_guardar)
                    .addComponent(btn_nuevo))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed

        if (txt_numeroDocumento.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes ingresar un número de identificación", "Alerta!", JOptionPane.WARNING_MESSAGE);
            txt_numeroDocumento.requestFocus();
            return;
        }
        if (txt_nombreCliente.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes ingresar el nombre del cliente", "Alerta!", JOptionPane.WARNING_MESSAGE);
            txt_nombreCliente.requestFocus();
            return;
        }
        if (txt_apellidoCliente.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes ingresar el apellido del cliente", "Alerta!", JOptionPane.WARNING_MESSAGE);
            txt_apellidoCliente.requestFocus();
            return;
        }
        if (dc_fNacimiento.getDate() == null) {
            JOptionPane.showMessageDialog(null, "Debes seleccionar una fecha de nacimiento", "Alerta!", JOptionPane.WARNING_MESSAGE);
            dc_fNacimiento.requestFocus();
            return;
        }
        if (txt_emailCliente.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes ingresar un correo electrónico", "Alerta!", JOptionPane.WARNING_MESSAGE);
            txt_emailCliente.requestFocus();
            return;
        }
        if (cob_barrioCliente.getSelectedItem().toString().equals("- Barrio -")) {
            JOptionPane.showMessageDialog(null, "Debes seleccionar un barrio", "Alerta!", JOptionPane.WARNING_MESSAGE);
            cob_barrioCliente.requestFocus();
            return;
        }
        if (cob_ciudadCliente.getSelectedItem().toString().equals("- Ciudad -")) {
            JOptionPane.showMessageDialog(null, "Debes seleccionar una ciudad", "Alerta!", JOptionPane.WARNING_MESSAGE);
            cob_ciudadCliente.requestFocus();
            return;
        }

        Modelo_cliente dtsCliente = new Modelo_cliente();

        dtsCliente.setIdTipoIdentidad1(idtipo());
        dtsCliente.setBarrioCliente(cob_barrioCliente.getSelectedItem().toString());
        dtsCliente.setCiudadCliente(cob_ciudadCliente.getSelectedItem().toString());

        dtsCliente.setNumeroDocumento(txt_numeroDocumento.getText());
        dtsCliente.setNombre(txt_nombreCliente.getText());
        dtsCliente.setApellido(txt_apellidoCliente.getText());
        dtsCliente.setGenero(cob_genero.getSelectedItem().toString());

        // Fecha
        Calendar cal;
        int d, m, a;
        cal = dc_fNacimiento.getCalendar();
        d = cal.get(Calendar.DAY_OF_MONTH);
        m = cal.get(Calendar.MONTH);
        a = cal.get(Calendar.YEAR) - 1900;
        dtsCliente.setFechaNacimiento(new Date(a, m, d));

        dtsCliente.setDireccion(txt_dirCliente.getText());
        dtsCliente.setTelefono(txt_telCliente.getText());
        dtsCliente.setEmail(txt_emailCliente.getText());
        dtsCliente.setEstado(cob_estado.getSelectedItem().toString());

        if (accion.equals("nuevo")) {
            if (control.consulta_existe(dtsCliente) == 0) {
                control.nuevoCliente(dtsCliente);
                inhabilitar();
            } else if (control.consulta_existe(dtsCliente) == 1) {
                JOptionPane.showMessageDialog(null, "El cliente ya se encuentra registrado");
                inhabilitar();
            }
        } else if (accion.equals("editar")) {
            dtsCliente.setCodigoCliente(Integer.parseInt(txt_codigoCliente.getText()));
            control.editarCliente(dtsCliente);
            inhabilitar();
        }

    }//GEN-LAST:event_btn_guardarActionPerformed

    private void cob_tipoIdentidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cob_tipoIdentidadActionPerformed
    }//GEN-LAST:event_cob_tipoIdentidadActionPerformed

    private void btn_agregarBarrioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregarBarrioActionPerformed

        Vista_barrio nbarrio = new Vista_barrio();
        nbarrio.toFront();
        nbarrio.setVisible(true);

    }//GEN-LAST:event_btn_agregarBarrioActionPerformed

    private void btn_buscarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarClienteActionPerformed

        buscarCliente();

    }//GEN-LAST:event_btn_buscarClienteActionPerformed

    private void btn_nuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_nuevoActionPerformed

        habilitar();
        btn_guardar.setText("Guardar");
        accion = "nuevo";
        txt_numeroDocumento.requestFocus();

    }//GEN-LAST:event_btn_nuevoActionPerformed

    private void btn_recargarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_recargarActionPerformed

        cob_barrioCliente.removeAllItems();
        control.Consultar_barrio(cob_barrioCliente);

    }//GEN-LAST:event_btn_recargarActionPerformed

    private void txt_buscarClienteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_buscarClienteKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            buscarCliente();
        }
    }//GEN-LAST:event_txt_buscarClienteKeyPressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista_cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista_cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista_cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista_cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vista_cliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_agregarBarrio;
    private javax.swing.JButton btn_buscarCliente;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JButton btn_nuevo;
    private javax.swing.JButton btn_recargar;
    private javax.swing.JComboBox<String> cob_barrioCliente;
    private javax.swing.JComboBox<String> cob_ciudadCliente;
    private javax.swing.JComboBox<String> cob_estado;
    private javax.swing.JComboBox<String> cob_genero;
    private javax.swing.JComboBox<String> cob_tipoIdentidad;
    private com.toedter.calendar.JDateChooser dc_fNacimiento;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txt_apellidoCliente;
    private javax.swing.JTextField txt_buscarCliente;
    private javax.swing.JTextField txt_codigoCliente;
    private javax.swing.JTextField txt_dirCliente;
    private javax.swing.JTextField txt_emailCliente;
    private javax.swing.JTextField txt_nombreCliente;
    private javax.swing.JTextField txt_numeroDocumento;
    private javax.swing.JTextField txt_telCliente;
    // End of variables declaration//GEN-END:variables

    // CARGAR COMBOBOX TIPO IDENTIDAD
    ArrayList<Modelo_cliente> llenar_cobIdentidad;

    public ArrayList<Modelo_cliente> llenar_tipo() {

        llenar_cobIdentidad = control.consulta_tipoIdentidad();
        cob_tipoIdentidad.removeAllItems();//eliminando los item

        for (int i = 0; i < llenar_cobIdentidad.size(); i++) {
            cob_tipoIdentidad.addItem(llenar_cobIdentidad.get(i).getNombre_tipo());
            // System.out.println(llenar_cobIdentidad.get(i).getNombre_tipo());
        }
        return llenar_cobIdentidad;
    }

    // EXTRAER ID TIPO IDENTIDAD
    public String idtipo() {

        String id = "";
        // System.out.println("cantidad datos " + llenar_cobIdentidad.size());

        for (int i = 0; i < llenar_cobIdentidad.size(); i++) {
            if (llenar_cobIdentidad.get(i).getNombre_tipo().equals(cob_tipoIdentidad.getSelectedItem().toString())) {
                id = llenar_cobIdentidad.get(i).getIdTipoIdentidad1();
                // System.out.println("  id  tipoIdentidad: " + llenar_cobIdentidad.get(i).getIdTipoIdentidad1() + " " + llenar_cobIdentidad.get(i).getNombre_tipo());

            } else {
                //System.out.println("Error al cargar idTipoIdentidad");
            }
        }
        return id;
    }

}
