-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 29-06-2019 a las 05:28:00
-- Versión del servidor: 5.7.24
-- Versión de PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sisventas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulo`
--

DROP TABLE IF EXISTS `articulo`;
CREATE TABLE IF NOT EXISTS `articulo` (
  `CodigoArticulo` int(11) NOT NULL,
  `Descripcion` varchar(80) COLLATE latin1_spanish_ci NOT NULL,
  `Precio` decimal(12,2) NOT NULL,
  `Costo` decimal(12,2) NOT NULL,
  `Iva` decimal(5,2) NOT NULL,
  `PrecioIva` double(15,2) NOT NULL,
  `PorcentajeDescuento` double(10,2) NOT NULL,
  `Descuento` decimal(12,2) NOT NULL,
  `PrecioFinal` double(15,2) NOT NULL,
  `IdProveedor1` bigint(20) NOT NULL,
  `IdSublinea1` int(11) NOT NULL,
  `estado` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`CodigoArticulo`),
  KEY `FK_IdProveedor1` (`IdProveedor1`),
  KEY `FK_IdSublinea1` (`IdSublinea1`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `articulo`
--

INSERT INTO `articulo` (`CodigoArticulo`, `Descripcion`, `Precio`, `Costo`, `Iva`, `PrecioIva`, `PorcentajeDescuento`, `Descuento`, `PrecioFinal`, `IdProveedor1`, `IdSublinea1`, `estado`) VALUES
(1, 'Camisas Hombre M 3*2', '15000.00', '10500.00', '8.00', 16200.00, 0.00, '0.00', 16200.00, 1, 1, 'Activo'),
(2, 'Pantalones Mujer drill 34', '32000.00', '25000.00', '19.00', 38080.00, 10.00, '3200.00', 34880.00, 4, 2, 'Activo'),
(3, 'Tv Led 65p Smart ', '2350000.00', '1890000.00', '19.00', 2796500.00, 12.00, '282000.00', 2514500.00, 3, 3, 'Activo'),
(4, 'Samsung A5 4g', '1320000.00', '950000.00', '19.00', 1570800.00, 0.00, '0.00', 1570800.00, 2, 4, 'Activo'),
(5, 'Camisa Maga Larga XL', '24500.00', '19800.00', '10.00', 26950.00, 0.00, '0.00', 26950.00, 4, 1, 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `barrio`
--

DROP TABLE IF EXISTS `barrio`;
CREATE TABLE IF NOT EXISTS `barrio` (
  `IdBarrio` int(11) NOT NULL,
  `Nombre` varchar(75) COLLATE latin1_spanish_ci NOT NULL,
  `Comuna` int(11) NOT NULL,
  PRIMARY KEY (`IdBarrio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `barrio`
--

INSERT INTO `barrio` (`IdBarrio`, `Nombre`, `Comuna`) VALUES
(0, '0', 0),
(1, 'Napoles', 18),
(2, 'Laureles', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caja`
--

DROP TABLE IF EXISTS `caja`;
CREATE TABLE IF NOT EXISTS `caja` (
  `CodigoCaja` int(11) NOT NULL,
  `IdTipoCaja1` int(11) NOT NULL,
  `Ubicacion` varchar(80) COLLATE latin1_spanish_ci NOT NULL,
  `Descripcion` varchar(80) COLLATE latin1_spanish_ci NOT NULL,
  `estado` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`CodigoCaja`),
  KEY `FK_IdTipoCaja1` (`IdTipoCaja1`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `caja`
--

INSERT INTO `caja` (`CodigoCaja`, `IdTipoCaja1`, `Ubicacion`, `Descripcion`, `estado`) VALUES
(1, 2, 'Entrada Norte', 'Caja Normal entrada norte', 'Activo'),
(2, 1, 'Entrada Sur', 'Caja Rápida entrada sur\nsolo 6 productos', 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargos`
--

DROP TABLE IF EXISTS `cargos`;
CREATE TABLE IF NOT EXISTS `cargos` (
  `IdCargo` int(11) NOT NULL,
  `Nombre` varchar(60) COLLATE latin1_spanish_ci NOT NULL,
  `Descripcion` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  `estado` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`IdCargo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `cargos`
--

INSERT INTO `cargos` (`IdCargo`, `Nombre`, `Descripcion`, `estado`) VALUES
(1, 'Gerente', 'Supervisa y controla las operaciones\nde la organización', 'Activo'),
(2, 'Cajero', 'Registrar productos en cajas', 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ciudad`
--

DROP TABLE IF EXISTS `ciudad`;
CREATE TABLE IF NOT EXISTS `ciudad` (
  `CodigoCiudad` int(11) NOT NULL,
  `Nombre` varchar(40) COLLATE latin1_spanish_ci NOT NULL,
  `Departamento` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`CodigoCiudad`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `ciudad`
--

INSERT INTO `ciudad` (`CodigoCiudad`, `Nombre`, `Departamento`) VALUES
(0, '0', '0'),
(5001, 'Medellin', 'Antioquia'),
(5042, 'Santafe De Antioquia', 'Antioquia'),
(5045, 'Apartado', 'Antioquia'),
(5051, 'Arboletes', 'Antioquia'),
(5055, 'Argelia', 'Antioquia'),
(5059, 'Armenia', 'Antioquia'),
(5079, 'Barbosa', 'Antioquia'),
(5088, 'Bello', 'Antioquia'),
(5101, 'Ciudad Bolivar', 'Antioquia'),
(5107, 'Briceño', 'Antioquia'),
(5113, 'Buritica', 'Antioquia'),
(5120, 'Caceres', 'Antioquia'),
(5125, 'Caicedo', 'Antioquia'),
(5129, 'Caldas', 'Antioquia'),
(5134, 'Campamento', 'Antioquia'),
(5138, 'Cañasgordas', 'Antioquia'),
(5142, 'Caracoli', 'Antioquia'),
(5145, 'Caramanta', 'Antioquia'),
(5154, 'Caucasia', 'Antioquia'),
(5172, 'Chigorodo', 'Antioquia'),
(5190, 'Cisneros', 'Antioquia'),
(5206, 'Concepcion', 'Antioquia'),
(5209, 'Concordia', 'Antioquia'),
(5212, 'Copacabana', 'Antioquia'),
(5266, 'Envigado', 'Antioquia'),
(5282, 'Fredonia', 'Antioquia'),
(5306, 'Giraldo', 'Antioquia'),
(5308, 'Girardota', 'Antioquia'),
(5310, 'Gomez Plata', 'Antioquia'),
(5313, 'Granada', 'Antioquia'),
(5315, 'Guadalupe', 'Antioquia'),
(5318, 'Guarne', 'Antioquia'),
(5321, 'Guatape', 'Antioquia'),
(5347, 'Heliconia', 'Antioquia'),
(5360, 'Itagui', 'Antioquia'),
(5361, 'Ituango', 'Antioquia'),
(5364, 'Jardin', 'Antioquia'),
(5368, 'Jerico', 'Antioquia'),
(5376, 'La Ceja', 'Antioquia'),
(5380, 'La Estrella', 'Antioquia'),
(5390, 'La Pintada', 'Antioquia'),
(5400, 'La Union', 'Antioquia'),
(5411, 'Liborina', 'Antioquia'),
(5425, 'Maceo', 'Antioquia'),
(5440, 'Marinilla', 'Antioquia'),
(5467, 'Montebello', 'Antioquia'),
(5475, 'Murindo', 'Antioquia'),
(5480, 'Mutata', 'Antioquia'),
(5483, 'Nariño', 'Antioquia'),
(5490, 'Necocli', 'Antioquia'),
(5501, 'Olaya', 'Antioquia'),
(5576, 'Pueblorrico', 'Antioquia'),
(5579, 'Puerto Berrio', 'Antioquia'),
(5585, 'Puerto Nare', 'Antioquia'),
(5591, 'Puerto Triunfo', 'Antioquia'),
(5604, 'Remedios', 'Antioquia'),
(5607, 'Retiro', 'Antioquia'),
(5615, 'Rionegro', 'Antioquia'),
(5628, 'Sabanalarga', 'Antioquia'),
(5631, 'Sabaneta', 'Antioquia'),
(5642, 'Salgar', 'Antioquia'),
(5647, 'San Andres De Cuerquia', 'Antioquia'),
(5649, 'San Carlos', 'Antioquia'),
(5652, 'San Francisco', 'Antioquia'),
(5656, 'San Jeronimo', 'Antioquia'),
(5658, 'San Jose De La Montaña', 'Antioquia'),
(5659, 'San Juan De Uraba', 'Antioquia'),
(5660, 'San Luis', 'Antioquia'),
(5664, 'San Pedro', 'Antioquia'),
(5665, 'San Pedro De Uraba', 'Antioquia'),
(5667, 'San Rafael', 'Antioquia'),
(5670, 'San Roque', 'Antioquia'),
(5674, 'San Vicente', 'Antioquia'),
(5679, 'Santa Barbara', 'Antioquia'),
(5686, 'Santa Rosa De Osos', 'Antioquia'),
(5690, 'Santo Domingo', 'Antioquia'),
(5697, 'El Santuario', 'Antioquia'),
(5736, 'Segovia', 'Antioquia'),
(5756, 'Sonson', 'Antioquia'),
(5761, 'Sopetran', 'Antioquia'),
(5789, 'Tamesis', 'Antioquia'),
(5790, 'Taraza', 'Antioquia'),
(5792, 'Tarso', 'Antioquia'),
(5809, 'Titiribi', 'Antioquia'),
(5819, 'Toledo', 'Antioquia'),
(5837, 'Turbo', 'Antioquia'),
(5842, 'Uramita', 'Antioquia'),
(5847, 'Urrao', 'Antioquia'),
(5854, 'Valdivia', 'Antioquia'),
(5856, 'Valparaiso', 'Antioquia'),
(5858, 'Vegachi', 'Antioquia'),
(5861, 'Venecia', 'Antioquia'),
(5873, 'Vigia Del Fuerte', 'Antioquia'),
(5885, 'Yali', 'Antioquia'),
(5887, 'Yarumal', 'Antioquia'),
(5890, 'Yolombo', 'Antioquia'),
(5893, 'Yondo', 'Antioquia'),
(5895, 'Zaragoza', 'Antioquia'),
(8001, 'Barranquilla', 'Atlantico'),
(8078, 'Baranoa', 'Atlantico'),
(8137, 'Campo De La Cruz', 'Atlantico'),
(8141, 'Candelaria', 'Atlantico'),
(8296, 'Galapa', 'Atlantico'),
(8372, 'Juan De Acosta', 'Atlantico'),
(8421, 'Luruaco', 'Atlantico'),
(8433, 'Malambo', 'Atlantico'),
(8436, 'Manati', 'Atlantico'),
(8520, 'Palmar De Varela', 'Atlantico'),
(8549, 'Piojo', 'Atlantico'),
(8558, 'Polonuevo', 'Atlantico'),
(8560, 'Ponedera', 'Atlantico'),
(8573, 'Puerto Colombia', 'Atlantico'),
(8606, 'Repelon', 'Atlantico'),
(8634, 'Sabanagrande', 'Atlantico'),
(8638, 'Sabanalarga', 'Atlantico'),
(8675, 'Santa Lucia', 'Atlantico'),
(8685, 'Santo Tomas', 'Atlantico'),
(8758, 'Soledad', 'Atlantico'),
(8770, 'Suan', 'Atlantico'),
(8832, 'Tubara', 'Atlantico'),
(8849, 'Usiacuri', 'Atlantico'),
(11001, 'Bogota, D.C.', 'Bogota'),
(13001, 'Cartagena', 'Bolivar'),
(13006, 'Achi', 'Bolivar'),
(13030, 'Altos Del Rosario', 'Bolivar'),
(13042, 'Arenal', 'Bolivar'),
(13052, 'Arjona', 'Bolivar'),
(13062, 'Arroyohondo', 'Bolivar'),
(13074, 'Barranco De Loba', 'Bolivar'),
(13140, 'Calamar', 'Bolivar'),
(13160, 'Cantagallo', 'Bolivar'),
(13188, 'Cicuco', 'Bolivar'),
(13212, 'Cordoba', 'Bolivar'),
(13222, 'Clemencia', 'Bolivar'),
(13244, 'El Carmen De Bolivar', 'Bolivar'),
(13248, 'El Guamo', 'Bolivar'),
(13268, 'El Peñon', 'Bolivar'),
(13300, 'Hatillo De Loba', 'Bolivar'),
(13430, 'Magangue', 'Bolivar'),
(13433, 'Mahates', 'Bolivar'),
(13440, 'Margarita', 'Bolivar'),
(13442, 'Maria La Baja', 'Bolivar'),
(13458, 'Montecristo', 'Bolivar'),
(13468, 'Mompos', 'Bolivar'),
(13473, 'Morales', 'Bolivar'),
(13490, 'Norosi', 'Bolivar'),
(13549, 'Pinillos', 'Bolivar'),
(13580, 'Regidor', 'Bolivar'),
(13600, 'Rio Viejo', 'Bolivar'),
(13620, 'San Cristobal', 'Bolivar'),
(13647, 'San Estanislao', 'Bolivar'),
(13650, 'San Fernando', 'Bolivar'),
(13654, 'San Jacinto', 'Bolivar'),
(13655, 'San Jacinto Del Cauca', 'Bolivar'),
(13657, 'San Juan Nepomuceno', 'Bolivar'),
(13667, 'San Martin De Loba', 'Bolivar'),
(13670, 'San Pablo', 'Bolivar'),
(13673, 'Santa Catalina', 'Bolivar'),
(13683, 'Santa Rosa', 'Bolivar'),
(13688, 'Santa Rosa Del Sur', 'Bolivar'),
(13744, 'Simiti', 'Bolivar'),
(13760, 'Soplaviento', 'Bolivar'),
(13780, 'Talaigua Nuevo', 'Bolivar'),
(13810, 'Tiquisio', 'Bolivar'),
(13836, 'Turbaco', 'Bolivar'),
(13838, 'Turbana', 'Bolivar'),
(13873, 'Villanueva', 'Bolivar'),
(13894, 'Zambrano', 'Bolivar'),
(15001, 'Tunja', 'Boyaca'),
(15022, 'Almeida', 'Boyaca'),
(15047, 'Aquitania', 'Boyaca'),
(15051, 'Arcabuco', 'Boyaca'),
(15087, 'Belen', 'Boyaca'),
(15090, 'Berbeo', 'Boyaca'),
(15092, 'Beteitiva', 'Boyaca'),
(15097, 'Boavita', 'Boyaca'),
(15104, 'Boyaca', 'Boyaca'),
(15106, 'Briceño', 'Boyaca'),
(15109, 'Buenavista', 'Boyaca'),
(15114, 'Busbanza', 'Boyaca'),
(15131, 'Caldas', 'Boyaca'),
(15135, 'Campohermoso', 'Boyaca'),
(15162, 'Cerinza', 'Boyaca'),
(15172, 'Chinavita', 'Boyaca'),
(15176, 'Chiquinquira', 'Boyaca'),
(15180, 'Chiscas', 'Boyaca'),
(15183, 'Chita', 'Boyaca'),
(15185, 'Chitaraque', 'Boyaca'),
(15187, 'Chivata', 'Boyaca'),
(15189, 'Cienega', 'Boyaca'),
(15204, 'Combita', 'Boyaca'),
(15212, 'Coper', 'Boyaca'),
(15215, 'Corrales', 'Boyaca'),
(15218, 'Covarachia', 'Boyaca'),
(15223, 'Cubara', 'Boyaca'),
(15224, 'Cucaita', 'Boyaca'),
(15226, 'Cuitiva', 'Boyaca'),
(15232, 'Chiquiza', 'Boyaca'),
(15236, 'Chivor', 'Boyaca'),
(15238, 'Duitama', 'Boyaca'),
(15244, 'El Cocuy', 'Boyaca'),
(15248, 'El Espino', 'Boyaca'),
(15272, 'Firavitoba', 'Boyaca'),
(15276, 'Floresta', 'Boyaca'),
(15293, 'Gachantiva', 'Boyaca'),
(15296, 'Gameza', 'Boyaca'),
(15299, 'Garagoa', 'Boyaca'),
(15317, 'Guacamayas', 'Boyaca'),
(15322, 'Guateque', 'Boyaca'),
(15325, 'Guayata', 'Boyaca'),
(15332, 'Gsican', 'Boyaca'),
(15362, 'Iza', 'Boyaca'),
(15367, 'Jenesano', 'Boyaca'),
(15368, 'Jerico', 'Boyaca'),
(15377, 'Labranzagrande', 'Boyaca'),
(15380, 'La Capilla', 'Boyaca'),
(15401, 'La Victoria', 'Boyaca'),
(15403, 'La Uvita', 'Boyaca'),
(15407, 'Villa De Leyva', 'Boyaca'),
(15425, 'Macanal', 'Boyaca'),
(15442, 'Maripi', 'Boyaca'),
(15455, 'Miraflores', 'Boyaca'),
(15464, 'Mongua', 'Boyaca'),
(15466, 'Mongui', 'Boyaca'),
(15469, 'Moniquira', 'Boyaca'),
(15476, 'Motavita', 'Boyaca'),
(15480, 'Muzo', 'Boyaca'),
(15491, 'Nobsa', 'Boyaca'),
(15494, 'Nuevo Colon', 'Boyaca'),
(15500, 'Oicata', 'Boyaca'),
(15507, 'Otanche', 'Boyaca'),
(15511, 'Pachavita', 'Boyaca'),
(15514, 'Paez', 'Boyaca'),
(15516, 'Paipa', 'Boyaca'),
(15518, 'Pajarito', 'Boyaca'),
(15522, 'Panqueba', 'Boyaca'),
(15531, 'Pauna', 'Boyaca'),
(15533, 'Paya', 'Boyaca'),
(15537, 'Paz De Rio', 'Boyaca'),
(15542, 'Pesca', 'Boyaca'),
(15550, 'Pisba', 'Boyaca'),
(15572, 'Puerto Boyaca', 'Boyaca'),
(15580, 'Quipama', 'Boyaca'),
(15599, 'Ramiriqui', 'Boyaca'),
(15600, 'Raquira', 'Boyaca'),
(15621, 'Rondon', 'Boyaca'),
(15632, 'Saboya', 'Boyaca'),
(15638, 'Sachica', 'Boyaca'),
(15646, 'Samaca', 'Boyaca'),
(15660, 'San Eduardo', 'Boyaca'),
(15664, 'San Jose De Pare', 'Boyaca'),
(15667, 'San Luis De Gaceno', 'Boyaca'),
(15673, 'San Mateo', 'Boyaca'),
(15676, 'San Miguel De Sema', 'Boyaca'),
(15681, 'San Pablo De Borbur', 'Boyaca'),
(15686, 'Santana', 'Boyaca'),
(15690, 'Santa Maria', 'Boyaca'),
(15693, 'Santa Rosa De Viterbo', 'Boyaca'),
(15696, 'Santa Sofia', 'Boyaca'),
(15720, 'Sativanorte', 'Boyaca'),
(15723, 'Sativasur', 'Boyaca'),
(15740, 'Siachoque', 'Boyaca'),
(15753, 'Soata', 'Boyaca'),
(15755, 'Socota', 'Boyaca'),
(15757, 'Socha', 'Boyaca'),
(15759, 'Sogamoso', 'Boyaca'),
(15761, 'Somondoco', 'Boyaca'),
(15762, 'Sora', 'Boyaca'),
(15763, 'Sotaquira', 'Boyaca'),
(15764, 'Soraca', 'Boyaca'),
(15774, 'Susacon', 'Boyaca'),
(15776, 'Sutamarchan', 'Boyaca'),
(15778, 'Sutatenza', 'Boyaca'),
(15790, 'Tasco', 'Boyaca'),
(15798, 'Tenza', 'Boyaca'),
(15804, 'Tibana', 'Boyaca'),
(15806, 'Tibasosa', 'Boyaca'),
(15808, 'Tinjaca', 'Boyaca'),
(15810, 'Tipacoque', 'Boyaca'),
(15814, 'Toca', 'Boyaca'),
(15816, 'Togsi', 'Boyaca'),
(15820, 'Topaga', 'Boyaca'),
(15822, 'Tota', 'Boyaca'),
(15832, 'Tunungua', 'Boyaca'),
(15835, 'Turmeque', 'Boyaca'),
(15837, 'Tuta', 'Boyaca'),
(15839, 'Tutaza', 'Boyaca'),
(15842, 'Umbita', 'Boyaca'),
(15861, 'Ventaquemada', 'Boyaca'),
(15879, 'Viracacha', 'Boyaca'),
(15897, 'Zetaquira', 'Boyaca'),
(17001, 'Manizales', 'Caldas'),
(17013, 'Aguadas', 'Caldas'),
(17042, 'Anserma', 'Caldas'),
(17050, 'Aranzazu', 'Caldas'),
(17088, 'Belalcazar', 'Caldas'),
(17174, 'Chinchina', 'Caldas'),
(17272, 'Filadelfia', 'Caldas'),
(17380, 'La Dorada', 'Caldas'),
(17388, 'La Merced', 'Caldas'),
(17433, 'Manzanares', 'Caldas'),
(17442, 'Marmato', 'Caldas'),
(17444, 'Marquetalia', 'Caldas'),
(17446, 'Marulanda', 'Caldas'),
(17486, 'Neira', 'Caldas'),
(17495, 'Norcasia', 'Caldas'),
(17513, 'Pacora', 'Caldas'),
(17524, 'Palestina', 'Caldas'),
(17541, 'Pensilvania', 'Caldas'),
(17614, 'Riosucio', 'Caldas'),
(17616, 'Risaralda', 'Caldas'),
(17653, 'Salamina', 'Caldas'),
(17662, 'Samana', 'Caldas'),
(17665, 'San Jose', 'Caldas'),
(17777, 'Supia', 'Caldas'),
(17867, 'Victoria', 'Caldas'),
(17873, 'Villamaria', 'Caldas'),
(17877, 'Viterbo', 'Caldas'),
(18001, 'Florencia', 'Caqueta'),
(18029, 'Albania', 'Caqueta'),
(18094, 'Belen De Los Andaquies', 'Caqueta'),
(18150, 'Cartagena Del Chaira', 'Caqueta'),
(18205, 'Curillo', 'Caqueta'),
(18247, 'El Doncello', 'Caqueta'),
(18256, 'El Paujil', 'Caqueta'),
(18410, 'La Montañita', 'Caqueta'),
(18460, 'Milan', 'Caqueta'),
(18479, 'Morelia', 'Caqueta'),
(18592, 'Puerto Rico', 'Caqueta'),
(18610, 'San Jose Del Fragua', 'Caqueta'),
(18753, 'San Vicente Del Caguan', 'Caqueta'),
(18756, 'Solano', 'Caqueta'),
(18785, 'Solita', 'Caqueta'),
(18860, 'Valparaiso', 'Caqueta'),
(19001, 'Popayan', 'Cauca'),
(19022, 'Almaguer', 'Cauca'),
(19050, 'Argelia', 'Cauca'),
(19075, 'Balboa', 'Cauca'),
(19100, 'Bolivar', 'Cauca'),
(19110, 'Buenos Aires', 'Cauca'),
(19130, 'Cajibio', 'Cauca'),
(19137, 'Caldono', 'Cauca'),
(19142, 'Caloto', 'Cauca'),
(19212, 'Corinto', 'Cauca'),
(19256, 'El Tambo', 'Cauca'),
(19290, 'Florencia', 'Cauca'),
(19300, 'Guachene', 'Cauca'),
(19318, 'Guapi', 'Cauca'),
(19355, 'Inza', 'Cauca'),
(19364, 'Jambalo', 'Cauca'),
(19392, 'La Sierra', 'Cauca'),
(19397, 'La Vega', 'Cauca'),
(19418, 'Lopez', 'Cauca'),
(19450, 'Mercaderes', 'Cauca'),
(19455, 'Miranda', 'Cauca'),
(19473, 'Morales', 'Cauca'),
(19513, 'Padilla', 'Cauca'),
(19517, 'Paez', 'Cauca'),
(19532, 'Patia', 'Cauca'),
(19533, 'Piamonte', 'Cauca'),
(19548, 'Piendamo', 'Cauca'),
(19573, 'Puerto Tejada', 'Cauca'),
(19585, 'Purace', 'Cauca'),
(19622, 'Rosas', 'Cauca'),
(19693, 'San Sebastian', 'Cauca'),
(19698, 'Santander De Quilichao', 'Cauca'),
(19701, 'Santa Rosa', 'Cauca'),
(19743, 'Silvia', 'Cauca'),
(19760, 'Sotara', 'Cauca'),
(19780, 'Suarez', 'Cauca'),
(19785, 'Sucre', 'Cauca'),
(19807, 'Timbio', 'Cauca'),
(19809, 'Timbiqui', 'Cauca'),
(19821, 'Toribio', 'Cauca'),
(19824, 'Totoro', 'Cauca'),
(19845, 'Villa Rica', 'Cauca'),
(20001, 'Valledupar', 'Cesar'),
(20011, 'Aguachica', 'Cesar'),
(20013, 'Agustin Codazzi', 'Cesar'),
(20032, 'Astrea', 'Cesar'),
(20045, 'Becerril', 'Cesar'),
(20060, 'Bosconia', 'Cesar'),
(20175, 'Chimichagua', 'Cesar'),
(20178, 'Chiriguana', 'Cesar'),
(20228, 'Curumani', 'Cesar'),
(20238, 'El Copey', 'Cesar'),
(20250, 'El Paso', 'Cesar'),
(20295, 'Gamarra', 'Cesar'),
(20310, 'Gonzalez', 'Cesar'),
(20383, 'La Gloria', 'Cesar'),
(20400, 'La Jagua De Ibirico', 'Cesar'),
(20443, 'Manaure', 'Cesar'),
(20517, 'Pailitas', 'Cesar'),
(20550, 'Pelaya', 'Cesar'),
(20570, 'Pueblo Bello', 'Cesar'),
(20614, 'Rio De Oro', 'Cesar'),
(20621, 'La Paz', 'Cesar'),
(20710, 'San Alberto', 'Cesar'),
(20750, 'San Diego', 'Cesar'),
(20770, 'San Martin', 'Cesar'),
(20787, 'Tamalameque', 'Cesar'),
(23001, 'Monteria', 'Cordoba'),
(23068, 'Ayapel', 'Cordoba'),
(23079, 'Buenavista', 'Cordoba'),
(23090, 'Canalete', 'Cordoba'),
(23162, 'Cerete', 'Cordoba'),
(23168, 'Chima', 'Cordoba'),
(23182, 'Chinu', 'Cordoba'),
(23189, 'Cienaga De Oro', 'Cordoba'),
(23300, 'Cotorra', 'Cordoba'),
(23350, 'La Apartada', 'Cordoba'),
(23417, 'Lorica', 'Cordoba'),
(23419, 'Los Cordobas', 'Cordoba'),
(23464, 'Momil', 'Cordoba'),
(23466, 'Montelibano', 'Cordoba'),
(23500, 'Moñitos', 'Cordoba'),
(23555, 'Planeta Rica', 'Cordoba'),
(23570, 'Pueblo Nuevo', 'Cordoba'),
(23574, 'Puerto Escondido', 'Cordoba'),
(23580, 'Puerto Libertador', 'Cordoba'),
(23586, 'Purisima', 'Cordoba'),
(23660, 'Sahagun', 'Cordoba'),
(23670, 'San Andres Sotavento', 'Cordoba'),
(23672, 'San Antero', 'Cordoba'),
(23675, 'San Bernardo Del Viento', 'Cordoba'),
(23678, 'San Carlos', 'Cordoba'),
(23686, 'San Pelayo', 'Cordoba'),
(23807, 'Tierralta', 'Cordoba'),
(23855, 'Valencia', 'Cordoba'),
(25001, 'Agua De Dios', 'Cundinamarca'),
(25019, 'Alban', 'Cundinamarca'),
(25035, 'Anapoima', 'Cundinamarca'),
(25040, 'Anolaima', 'Cundinamarca'),
(25053, 'Arbelaez', 'Cundinamarca'),
(25086, 'Beltran', 'Cundinamarca'),
(25095, 'Bituima', 'Cundinamarca'),
(25099, 'Bojaca', 'Cundinamarca'),
(25120, 'Cabrera', 'Cundinamarca'),
(25123, 'Cachipay', 'Cundinamarca'),
(25126, 'Cajica', 'Cundinamarca'),
(25148, 'Caparrapi', 'Cundinamarca'),
(25151, 'Caqueza', 'Cundinamarca'),
(25154, 'Carmen De Carupa', 'Cundinamarca'),
(25168, 'Chaguani', 'Cundinamarca'),
(25175, 'Chia', 'Cundinamarca'),
(25178, 'Chipaque', 'Cundinamarca'),
(25181, 'Choachi', 'Cundinamarca'),
(25183, 'Choconta', 'Cundinamarca'),
(25200, 'Cogua', 'Cundinamarca'),
(25214, 'Cota', 'Cundinamarca'),
(25224, 'Cucunuba', 'Cundinamarca'),
(25245, 'El Colegio', 'Cundinamarca'),
(25258, 'El Peñon', 'Cundinamarca'),
(25260, 'El Rosal', 'Cundinamarca'),
(25269, 'Facatativa', 'Cundinamarca'),
(25279, 'Fomeque', 'Cundinamarca'),
(25281, 'Fosca', 'Cundinamarca'),
(25286, 'Funza', 'Cundinamarca'),
(25288, 'Fuquene', 'Cundinamarca'),
(25290, 'Fusagasuga', 'Cundinamarca'),
(25293, 'Gachala', 'Cundinamarca'),
(25295, 'Gachancipa', 'Cundinamarca'),
(25297, 'Gacheta', 'Cundinamarca'),
(25299, 'Gama', 'Cundinamarca'),
(25307, 'Girardot', 'Cundinamarca'),
(25312, 'Granada', 'Cundinamarca'),
(25317, 'Guacheta', 'Cundinamarca'),
(25320, 'Guaduas', 'Cundinamarca'),
(25322, 'Guasca', 'Cundinamarca'),
(25324, 'Guataqui', 'Cundinamarca'),
(25326, 'Guatavita', 'Cundinamarca'),
(25328, 'Guayabal De Siquima', 'Cundinamarca'),
(25335, 'Guayabetal', 'Cundinamarca'),
(25339, 'Gutierrez', 'Cundinamarca'),
(25368, 'Jerusalen', 'Cundinamarca'),
(25372, 'Junin', 'Cundinamarca'),
(25377, 'La Calera', 'Cundinamarca'),
(25386, 'La Mesa', 'Cundinamarca'),
(25394, 'La Palma', 'Cundinamarca'),
(25398, 'La Peña', 'Cundinamarca'),
(25402, 'La Vega', 'Cundinamarca'),
(25407, 'Lenguazaque', 'Cundinamarca'),
(25426, 'Macheta', 'Cundinamarca'),
(25430, 'Madrid', 'Cundinamarca'),
(25436, 'Manta', 'Cundinamarca'),
(25438, 'Medina', 'Cundinamarca'),
(25473, 'Mosquera', 'Cundinamarca'),
(25483, 'Nariño', 'Cundinamarca'),
(25486, 'Nemocon', 'Cundinamarca'),
(25488, 'Nilo', 'Cundinamarca'),
(25489, 'Nimaima', 'Cundinamarca'),
(25491, 'Nocaima', 'Cundinamarca'),
(25506, 'Venecia', 'Cundinamarca'),
(25513, 'Pacho', 'Cundinamarca'),
(25518, 'Paime', 'Cundinamarca'),
(25524, 'Pandi', 'Cundinamarca'),
(25530, 'Paratebueno', 'Cundinamarca'),
(25535, 'Pasca', 'Cundinamarca'),
(25572, 'Puerto Salgar', 'Cundinamarca'),
(25580, 'Puli', 'Cundinamarca'),
(25592, 'Quebradanegra', 'Cundinamarca'),
(25594, 'Quetame', 'Cundinamarca'),
(25596, 'Quipile', 'Cundinamarca'),
(25599, 'Apulo', 'Cundinamarca'),
(25612, 'Ricaurte', 'Cundinamarca'),
(25645, 'San Antonio Del Tequendama', 'Cundinamarca'),
(25649, 'San Bernardo', 'Cundinamarca'),
(25653, 'San Cayetano', 'Cundinamarca'),
(25658, 'San Francisco', 'Cundinamarca'),
(25662, 'San Juan De Rio Seco', 'Cundinamarca'),
(25718, 'Sasaima', 'Cundinamarca'),
(25736, 'Sesquile', 'Cundinamarca'),
(25740, 'Sibate', 'Cundinamarca'),
(25743, 'Silvania', 'Cundinamarca'),
(25745, 'Simijaca', 'Cundinamarca'),
(25754, 'Soacha', 'Cundinamarca'),
(25758, 'Sopo', 'Cundinamarca'),
(25769, 'Subachoque', 'Cundinamarca'),
(25772, 'Suesca', 'Cundinamarca'),
(25777, 'Supata', 'Cundinamarca'),
(25779, 'Susa', 'Cundinamarca'),
(25781, 'Sutatausa', 'Cundinamarca'),
(25785, 'Tabio', 'Cundinamarca'),
(25793, 'Tausa', 'Cundinamarca'),
(25797, 'Tena', 'Cundinamarca'),
(25799, 'Tenjo', 'Cundinamarca'),
(25805, 'Tibacuy', 'Cundinamarca'),
(25807, 'Tibirita', 'Cundinamarca'),
(25815, 'Tocaima', 'Cundinamarca'),
(25817, 'Tocancipa', 'Cundinamarca'),
(25823, 'Topaipi', 'Cundinamarca'),
(25839, 'Ubala', 'Cundinamarca'),
(25841, 'Ubaque', 'Cundinamarca'),
(25843, 'Villa De San Diego De Ubate', 'Cundinamarca'),
(25845, 'Une', 'Cundinamarca'),
(25851, 'Utica', 'Cundinamarca'),
(25862, 'Vergara', 'Cundinamarca'),
(25867, 'Viani', 'Cundinamarca'),
(25871, 'Villagomez', 'Cundinamarca'),
(25873, 'Villapinzon', 'Cundinamarca'),
(25875, 'Villeta', 'Cundinamarca'),
(25878, 'Viota', 'Cundinamarca'),
(25885, 'Yacopi', 'Cundinamarca'),
(25898, 'Zipacon', 'Cundinamarca'),
(25899, 'Zipaquira', 'Cundinamarca'),
(27001, 'Quibdo', 'Choco'),
(27006, 'Acandi', 'Choco'),
(27025, 'Alto Baudo', 'Choco'),
(27050, 'Atrato', 'Choco'),
(27073, 'Bagado', 'Choco'),
(27075, 'Bahia Solano', 'Choco'),
(27077, 'Bajo Baudo', 'Choco'),
(27099, 'Bojaya', 'Choco'),
(27135, 'El Canton Del San Pablo', 'Choco'),
(27150, 'Carmen Del Darien', 'Choco'),
(27160, 'Certegui', 'Choco'),
(27205, 'Condoto', 'Choco'),
(27245, 'El Carmen De Atrato', 'Choco'),
(27250, 'El Litoral Del San Juan', 'Choco'),
(27361, 'Istmina', 'Choco'),
(27372, 'Jurado', 'Choco'),
(27413, 'Lloro', 'Choco'),
(27425, 'Medio Atrato', 'Choco'),
(27430, 'Medio Baudo', 'Choco'),
(27450, 'Medio San Juan', 'Choco'),
(27491, 'Novita', 'Choco'),
(27495, 'Nuqui', 'Choco'),
(27580, 'Rio Iro', 'Choco'),
(27600, 'Rio Quito', 'Choco'),
(27615, 'Riosucio', 'Choco'),
(27660, 'San Jose Del Palmar', 'Choco'),
(27745, 'Sipi', 'Choco'),
(27787, 'Tado', 'Choco'),
(27800, 'Unguia', 'Choco'),
(27810, 'Union Panamericana', 'Choco'),
(41001, 'Neiva', 'Huila'),
(41006, 'Acevedo', 'Huila'),
(41013, 'Agrado', 'Huila'),
(41016, 'Aipe', 'Huila'),
(41020, 'Algeciras', 'Huila'),
(41026, 'Altamira', 'Huila'),
(41078, 'Baraya', 'Huila'),
(41132, 'Campoalegre', 'Huila'),
(41206, 'Colombia', 'Huila'),
(41244, 'Elias', 'Huila'),
(41298, 'Garzon', 'Huila'),
(41306, 'Gigante', 'Huila'),
(41319, 'Guadalupe', 'Huila'),
(41349, 'Hobo', 'Huila'),
(41357, 'Iquira', 'Huila'),
(41359, 'Isnos', 'Huila'),
(41378, 'La Argentina', 'Huila'),
(41396, 'La Plata', 'Huila'),
(41483, 'Nataga', 'Huila'),
(41503, 'Oporapa', 'Huila'),
(41518, 'Paicol', 'Huila'),
(41524, 'Palermo', 'Huila'),
(41530, 'Palestina', 'Huila'),
(41548, 'Pital', 'Huila'),
(41551, 'Pitalito', 'Huila'),
(41615, 'Rivera', 'Huila'),
(41660, 'Saladoblanco', 'Huila'),
(41668, 'San Agustin', 'Huila'),
(41676, 'Santa Maria', 'Huila'),
(41770, 'Suaza', 'Huila'),
(41791, 'Tarqui', 'Huila'),
(41797, 'Tesalia', 'Huila'),
(41799, 'Tello', 'Huila'),
(41801, 'Teruel', 'Huila'),
(41807, 'Timana', 'Huila'),
(41872, 'Villavieja', 'Huila'),
(41885, 'Yaguara', 'Huila'),
(44001, 'Riohacha', 'La Guajira'),
(44035, 'Albania', 'La Guajira'),
(44078, 'Barrancas', 'La Guajira'),
(44090, 'Dibulla', 'La Guajira'),
(44098, 'Distraccion', 'La Guajira'),
(44110, 'El Molino', 'La Guajira'),
(44279, 'Fonseca', 'La Guajira'),
(44378, 'Hatonuevo', 'La Guajira'),
(44420, 'La Jagua Del Pilar', 'La Guajira'),
(44430, 'Maicao', 'La Guajira'),
(44560, 'Manaure', 'La Guajira'),
(44650, 'San Juan Del Cesar', 'La Guajira'),
(44847, 'Uribia', 'La Guajira'),
(44855, 'Urumita', 'La Guajira'),
(44874, 'Villanueva', 'La Guajira'),
(47001, 'Santa Marta', 'Magdalena'),
(47030, 'Algarrobo', 'Magdalena'),
(47053, 'Aracataca', 'Magdalena'),
(47058, 'Ariguani', 'Magdalena'),
(47161, 'Cerro San Antonio', 'Magdalena'),
(47170, 'Chibolo', 'Magdalena'),
(47189, 'Cienaga', 'Magdalena'),
(47205, 'Concordia', 'Magdalena'),
(47245, 'El Banco', 'Magdalena'),
(47258, 'El Piñon', 'Magdalena'),
(47268, 'El Reten', 'Magdalena'),
(47288, 'Fundacion', 'Magdalena'),
(47318, 'Guamal', 'Magdalena'),
(47460, 'Nueva Granada', 'Magdalena'),
(47541, 'Pedraza', 'Magdalena'),
(47545, 'Pijiño Del Carmen', 'Magdalena'),
(47551, 'Pivijay', 'Magdalena'),
(47555, 'Plato', 'Magdalena'),
(47570, 'Puebloviejo', 'Magdalena'),
(47605, 'Remolino', 'Magdalena'),
(47660, 'Sabanas De San Angel', 'Magdalena'),
(47675, 'Salamina', 'Magdalena'),
(47692, 'San Sebastian De Buenavista', 'Magdalena'),
(47703, 'San Zenon', 'Magdalena'),
(47707, 'Santa Ana', 'Magdalena'),
(47720, 'Santa Barbara De Pinto', 'Magdalena'),
(47745, 'Sitionuevo', 'Magdalena'),
(47798, 'Tenerife', 'Magdalena'),
(47960, 'Zapayan', 'Magdalena'),
(47980, 'Zona Bananera', 'Magdalena'),
(50001, 'Villavicencio', 'Meta'),
(50006, 'Acacias', 'Meta'),
(50110, 'Barranca De Upia', 'Meta'),
(50124, 'Cabuyaro', 'Meta'),
(50150, 'Castilla La Nueva', 'Meta'),
(50223, 'Cubarral', 'Meta'),
(50226, 'Cumaral', 'Meta'),
(50245, 'El Calvario', 'Meta'),
(50251, 'El Castillo', 'Meta'),
(50270, 'El Dorado', 'Meta'),
(50287, 'Fuente De Oro', 'Meta'),
(50313, 'Granada', 'Meta'),
(50318, 'Guamal', 'Meta'),
(50325, 'Mapiripan', 'Meta'),
(50330, 'Mesetas', 'Meta'),
(50350, 'La Macarena', 'Meta'),
(50370, 'Uribe', 'Meta'),
(50400, 'Lejanias', 'Meta'),
(50450, 'Puerto Concordia', 'Meta'),
(50568, 'Puerto Gaitan', 'Meta'),
(50573, 'Puerto Lopez', 'Meta'),
(50577, 'Puerto Lleras', 'Meta'),
(50590, 'Puerto Rico', 'Meta'),
(50606, 'Restrepo', 'Meta'),
(50680, 'San Carlos De Guaroa', 'Meta'),
(50683, 'San Juan De Arama', 'Meta'),
(50686, 'San Juanito', 'Meta'),
(50689, 'San Martin', 'Meta'),
(50711, 'Vistahermosa', 'Meta'),
(52001, 'Pasto', 'Nariño'),
(52019, 'Alban', 'Nariño'),
(52022, 'Aldana', 'Nariño'),
(52036, 'Ancuya', 'Nariño'),
(52051, 'Arboleda', 'Nariño'),
(52079, 'Barbacoas', 'Nariño'),
(52083, 'Belen', 'Nariño'),
(52110, 'Buesaco', 'Nariño'),
(52203, 'Colon', 'Nariño'),
(52207, 'Consaca', 'Nariño'),
(52210, 'Contadero', 'Nariño'),
(52215, 'Cordoba', 'Nariño'),
(52224, 'Cuaspud', 'Nariño'),
(52227, 'Cumbal', 'Nariño'),
(52233, 'Cumbitara', 'Nariño'),
(52240, 'Chachagsi', 'Nariño'),
(52250, 'El Charco', 'Nariño'),
(52254, 'El Peñol', 'Nariño'),
(52256, 'El Rosario', 'Nariño'),
(52258, 'El Tablon De Gomez', 'Nariño'),
(52260, 'El Tambo', 'Nariño'),
(52287, 'Funes', 'Nariño'),
(52317, 'Guachucal', 'Nariño'),
(52320, 'Guaitarilla', 'Nariño'),
(52323, 'Gualmatan', 'Nariño'),
(52352, 'Iles', 'Nariño'),
(52354, 'Imues', 'Nariño'),
(52356, 'Ipiales', 'Nariño'),
(52378, 'La Cruz', 'Nariño'),
(52381, 'La Florida', 'Nariño'),
(52385, 'La Llanada', 'Nariño'),
(52390, 'La Tola', 'Nariño'),
(52399, 'La Union', 'Nariño'),
(52405, 'Leiva', 'Nariño'),
(52411, 'Linares', 'Nariño'),
(52418, 'Los Andes', 'Nariño'),
(52427, 'Magsi', 'Nariño'),
(52435, 'Mallama', 'Nariño'),
(52473, 'Mosquera', 'Nariño'),
(52480, 'Nariño', 'Nariño'),
(52490, 'Olaya Herrera', 'Nariño'),
(52506, 'Ospina', 'Nariño'),
(52520, 'Francisco Pizarro', 'Nariño'),
(52540, 'Policarpa', 'Nariño'),
(52560, 'Potosi', 'Nariño'),
(52565, 'Providencia', 'Nariño'),
(52573, 'Puerres', 'Nariño'),
(52585, 'Pupiales', 'Nariño'),
(52612, 'Ricaurte', 'Nariño'),
(52621, 'Roberto Payan', 'Nariño'),
(52678, 'Samaniego', 'Nariño'),
(52683, 'Sandona', 'Nariño'),
(52685, 'San Bernardo', 'Nariño'),
(52687, 'San Lorenzo', 'Nariño'),
(52693, 'San Pablo', 'Nariño'),
(52694, 'San Pedro De Cartago', 'Nariño'),
(52696, 'Santa Barbara', 'Nariño'),
(52699, 'Santacruz', 'Nariño'),
(52720, 'Sapuyes', 'Nariño'),
(52786, 'Taminango', 'Nariño'),
(52788, 'Tangua', 'Nariño'),
(52835, 'San Andres De Tumaco', 'Nariño'),
(52838, 'Tuquerres', 'Nariño'),
(52885, 'Yacuanquer', 'Nariño'),
(54001, 'Cucuta', 'N. De Santander'),
(54003, 'Abrego', 'N. De Santander'),
(54051, 'Arboledas', 'N. De Santander'),
(54099, 'Bochalema', 'N. De Santander'),
(54109, 'Bucarasica', 'N. De Santander'),
(54125, 'Cacota', 'N. De Santander'),
(54128, 'Cachira', 'N. De Santander'),
(54172, 'Chinacota', 'N. De Santander'),
(54174, 'Chitaga', 'N. De Santander'),
(54206, 'Convencion', 'N. De Santander'),
(54223, 'Cucutilla', 'N. De Santander'),
(54239, 'Durania', 'N. De Santander'),
(54245, 'El Carmen', 'N. De Santander'),
(54250, 'El Tarra', 'N. De Santander'),
(54261, 'El Zulia', 'N. De Santander'),
(54313, 'Gramalote', 'N. De Santander'),
(54344, 'Hacari', 'N. De Santander'),
(54347, 'Herran', 'N. De Santander'),
(54377, 'Labateca', 'N. De Santander'),
(54385, 'La Esperanza', 'N. De Santander'),
(54398, 'La Playa', 'N. De Santander'),
(54405, 'Los Patios', 'N. De Santander'),
(54418, 'Lourdes', 'N. De Santander'),
(54480, 'Mutiscua', 'N. De Santander'),
(54498, 'Ocaña', 'N. De Santander'),
(54518, 'Pamplona', 'N. De Santander'),
(54520, 'Pamplonita', 'N. De Santander'),
(54553, 'Puerto Santander', 'N. De Santander'),
(54599, 'Ragonvalia', 'N. De Santander'),
(54660, 'Salazar', 'N. De Santander'),
(54670, 'San Calixto', 'N. De Santander'),
(54673, 'San Cayetano', 'N. De Santander'),
(54680, 'Santiago', 'N. De Santander'),
(54720, 'Sardinata', 'N. De Santander'),
(54743, 'Silos', 'N. De Santander'),
(54800, 'Teorama', 'N. De Santander'),
(54810, 'Tibu', 'N. De Santander'),
(54820, 'Toledo', 'N. De Santander'),
(54871, 'Villa Caro', 'N. De Santander'),
(54874, 'Villa Del Rosario', 'N. De Santander'),
(63001, 'Armenia', 'Quindio'),
(63111, 'Buenavista', 'Quindio'),
(63130, 'Calarca', 'Quindio'),
(63190, 'Circasia', 'Quindio'),
(63212, 'Cordoba', 'Quindio'),
(63272, 'Filandia', 'Quindio'),
(63302, 'Genova', 'Quindio'),
(63401, 'La Tebaida', 'Quindio'),
(63470, 'Montenegro', 'Quindio'),
(63548, 'Pijao', 'Quindio'),
(63594, 'Quimbaya', 'Quindio'),
(63690, 'Salento', 'Quindio'),
(66001, 'Pereira', 'Risaralda'),
(66045, 'Apia', 'Risaralda'),
(66075, 'Balboa', 'Risaralda'),
(66088, 'Belen De Umbria', 'Risaralda'),
(66170, 'Dosquebradas', 'Risaralda'),
(66318, 'Guatica', 'Risaralda'),
(66383, 'La Celia', 'Risaralda'),
(66400, 'La Virginia', 'Risaralda'),
(66440, 'Marsella', 'Risaralda'),
(66456, 'Mistrato', 'Risaralda'),
(66572, 'Pueblo Rico', 'Risaralda'),
(66594, 'Quinchia', 'Risaralda'),
(66682, 'Santa Rosa De Cabal', 'Risaralda'),
(66687, 'Santuario', 'Risaralda'),
(68001, 'Bucaramanga', 'Santander'),
(68013, 'Aguada', 'Santander'),
(68020, 'Albania', 'Santander'),
(68051, 'Aratoca', 'Santander'),
(68077, 'Barbosa', 'Santander'),
(68079, 'Barichara', 'Santander'),
(68081, 'Barrancabermeja', 'Santander'),
(68092, 'Betulia', 'Santander'),
(68101, 'Bolivar', 'Santander'),
(68121, 'Cabrera', 'Santander'),
(68132, 'California', 'Santander'),
(68147, 'Capitanejo', 'Santander'),
(68152, 'Carcasi', 'Santander'),
(68160, 'Cepita', 'Santander'),
(68162, 'Cerrito', 'Santander'),
(68167, 'Charala', 'Santander'),
(68169, 'Charta', 'Santander'),
(68176, 'Chima', 'Santander'),
(68179, 'Chipata', 'Santander'),
(68190, 'Cimitarra', 'Santander'),
(68207, 'Concepcion', 'Santander'),
(68209, 'Confines', 'Santander'),
(68211, 'Contratacion', 'Santander'),
(68217, 'Coromoro', 'Santander'),
(68229, 'Curiti', 'Santander'),
(68235, 'El Carmen De Chucuri', 'Santander'),
(68245, 'El Guacamayo', 'Santander'),
(68250, 'El Peñon', 'Santander'),
(68255, 'El Playon', 'Santander'),
(68264, 'Encino', 'Santander'),
(68266, 'Enciso', 'Santander'),
(68271, 'Florian', 'Santander'),
(68276, 'Floridablanca', 'Santander'),
(68296, 'Galan', 'Santander'),
(68298, 'Gambita', 'Santander'),
(68307, 'Giron', 'Santander'),
(68318, 'Guaca', 'Santander'),
(68320, 'Guadalupe', 'Santander'),
(68322, 'Guapota', 'Santander'),
(68324, 'Guavata', 'Santander'),
(68327, 'Gsepsa', 'Santander'),
(68344, 'Hato', 'Santander'),
(68368, 'Jesus Maria', 'Santander'),
(68370, 'Jordan', 'Santander'),
(68377, 'La Belleza', 'Santander'),
(68385, 'Landazuri', 'Santander'),
(68397, 'La Paz', 'Santander'),
(68406, 'Lebrija', 'Santander'),
(68418, 'Los Santos', 'Santander'),
(68425, 'Macaravita', 'Santander'),
(68432, 'Malaga', 'Santander'),
(68444, 'Matanza', 'Santander'),
(68464, 'Mogotes', 'Santander'),
(68468, 'Molagavita', 'Santander'),
(68498, 'Ocamonte', 'Santander'),
(68500, 'Oiba', 'Santander'),
(68502, 'Onzaga', 'Santander'),
(68522, 'Palmar', 'Santander'),
(68524, 'Palmas Del Socorro', 'Santander'),
(68533, 'Paramo', 'Santander'),
(68547, 'Piedecuesta', 'Santander'),
(68549, 'Pinchote', 'Santander'),
(68572, 'Puente Nacional', 'Santander'),
(68573, 'Puerto Parra', 'Santander'),
(68575, 'Puerto Wilches', 'Santander'),
(68615, 'Rionegro', 'Santander'),
(68655, 'Sabana De Torres', 'Santander'),
(68669, 'San Andres', 'Santander'),
(68673, 'San Benito', 'Santander'),
(68679, 'San Gil', 'Santander'),
(68682, 'San Joaquin', 'Santander'),
(68684, 'San Jose De Miranda', 'Santander'),
(68686, 'San Miguel', 'Santander'),
(68689, 'San Vicente De Chucuri', 'Santander'),
(68705, 'Santa Barbara', 'Santander'),
(68720, 'Santa Helena Del Opon', 'Santander'),
(68745, 'Simacota', 'Santander'),
(68755, 'Socorro', 'Santander'),
(68770, 'Suaita', 'Santander'),
(68773, 'Sucre', 'Santander'),
(68780, 'Surata', 'Santander'),
(68820, 'Tona', 'Santander'),
(68855, 'Valle De San Jose', 'Santander'),
(68861, 'Velez', 'Santander'),
(68867, 'Vetas', 'Santander'),
(68872, 'Villanueva', 'Santander'),
(68895, 'Zapatoca', 'Santander'),
(70001, 'Sincelejo', 'Sucre'),
(70110, 'Buenavista', 'Sucre'),
(70124, 'Caimito', 'Sucre'),
(70204, 'Coloso', 'Sucre'),
(70215, 'Corozal', 'Sucre'),
(70221, 'Coveñas', 'Sucre'),
(70230, 'Chalan', 'Sucre'),
(70233, 'El Roble', 'Sucre'),
(70235, 'Galeras', 'Sucre'),
(70265, 'Guaranda', 'Sucre'),
(70400, 'La Union', 'Sucre'),
(70418, 'Los Palmitos', 'Sucre'),
(70429, 'Majagual', 'Sucre'),
(70473, 'Morroa', 'Sucre'),
(70508, 'Ovejas', 'Sucre'),
(70523, 'Palmito', 'Sucre'),
(70670, 'Sampues', 'Sucre'),
(70678, 'San Benito Abad', 'Sucre'),
(70702, 'San Juan De Betulia', 'Sucre'),
(70708, 'San Marcos', 'Sucre'),
(70713, 'San Onofre', 'Sucre'),
(70717, 'San Pedro', 'Sucre'),
(70742, 'San Luis De Since', 'Sucre'),
(70771, 'Sucre', 'Sucre'),
(70820, 'Santiago De Tolu', 'Sucre'),
(70823, 'Tolu Viejo', 'Sucre'),
(73001, 'Ibague', 'Tolima'),
(73024, 'Alpujarra', 'Tolima'),
(73026, 'Alvarado', 'Tolima'),
(73030, 'Ambalema', 'Tolima'),
(73043, 'Anzoategui', 'Tolima'),
(73055, 'Armero', 'Tolima'),
(73067, 'Ataco', 'Tolima'),
(73124, 'Cajamarca', 'Tolima'),
(73148, 'Carmen De Apicala', 'Tolima'),
(73152, 'Casabianca', 'Tolima'),
(73168, 'Chaparral', 'Tolima'),
(73200, 'Coello', 'Tolima'),
(73217, 'Coyaima', 'Tolima'),
(73226, 'Cunday', 'Tolima'),
(73236, 'Dolores', 'Tolima'),
(73268, 'Espinal', 'Tolima'),
(73270, 'Falan', 'Tolima'),
(73275, 'Flandes', 'Tolima'),
(73283, 'Fresno', 'Tolima'),
(73319, 'Guamo', 'Tolima'),
(73347, 'Herveo', 'Tolima'),
(73349, 'Honda', 'Tolima'),
(73352, 'Icononzo', 'Tolima'),
(73408, 'Lerida', 'Tolima'),
(73411, 'Libano', 'Tolima'),
(73443, 'Mariquita', 'Tolima'),
(73449, 'Melgar', 'Tolima'),
(73461, 'Murillo', 'Tolima'),
(73483, 'Natagaima', 'Tolima'),
(73504, 'Ortega', 'Tolima'),
(73520, 'Palocabildo', 'Tolima'),
(73547, 'Piedras', 'Tolima'),
(73555, 'Planadas', 'Tolima'),
(73563, 'Prado', 'Tolima'),
(73585, 'Purificacion', 'Tolima'),
(73616, 'Rioblanco', 'Tolima'),
(73622, 'Roncesvalles', 'Tolima'),
(73624, 'Rovira', 'Tolima'),
(73671, 'Saldaña', 'Tolima'),
(73675, 'San Antonio', 'Tolima'),
(73678, 'San Luis', 'Tolima'),
(73686, 'Santa Isabel', 'Tolima'),
(73770, 'Suarez', 'Tolima'),
(73854, 'Valle De San Juan', 'Tolima'),
(73861, 'Venadillo', 'Tolima'),
(73870, 'Villahermosa', 'Tolima'),
(73873, 'Villarrica', 'Tolima'),
(76001, 'Cali', 'Valle Del Cauca'),
(76020, 'Alcala', 'Valle Del Cauca'),
(76036, 'Andalucia', 'Valle Del Cauca'),
(76041, 'Ansermanuevo', 'Valle Del Cauca'),
(76054, 'Argelia', 'Valle Del Cauca'),
(76100, 'Bolivar', 'Valle Del Cauca'),
(76109, 'Buenaventura', 'Valle Del Cauca'),
(76111, 'Guadalajara De Buga', 'Valle Del Cauca'),
(76113, 'Bugalagrande', 'Valle Del Cauca'),
(76122, 'Caicedonia', 'Valle Del Cauca'),
(76126, 'Calima', 'Valle Del Cauca'),
(76130, 'Candelaria', 'Valle Del Cauca'),
(76147, 'Cartago', 'Valle Del Cauca'),
(76233, 'Dagua', 'Valle Del Cauca'),
(76243, 'El Aguila', 'Valle Del Cauca'),
(76246, 'El Cairo', 'Valle Del Cauca'),
(76248, 'El Cerrito', 'Valle Del Cauca'),
(76250, 'El Dovio', 'Valle Del Cauca'),
(76275, 'Florida', 'Valle Del Cauca'),
(76306, 'Ginebra', 'Valle Del Cauca'),
(76318, 'Guacari', 'Valle Del Cauca'),
(76364, 'Jamundi', 'Valle Del Cauca'),
(76377, 'La Cumbre', 'Valle Del Cauca'),
(76400, 'La Union', 'Valle Del Cauca'),
(76403, 'La Victoria', 'Valle Del Cauca'),
(76497, 'Obando', 'Valle Del Cauca'),
(76520, 'Palmira', 'Valle Del Cauca'),
(76563, 'Pradera', 'Valle Del Cauca'),
(76606, 'Restrepo', 'Valle Del Cauca'),
(76616, 'Riofrio', 'Valle Del Cauca'),
(76622, 'Roldanillo', 'Valle Del Cauca'),
(76670, 'San Pedro', 'Valle Del Cauca'),
(76736, 'Sevilla', 'Valle Del Cauca'),
(76823, 'Toro', 'Valle Del Cauca'),
(76828, 'Trujillo', 'Valle Del Cauca'),
(76834, 'Tulua', 'Valle Del Cauca'),
(76845, 'Ulloa', 'Valle Del Cauca'),
(76863, 'Versalles', 'Valle Del Cauca'),
(76869, 'Vijes', 'Valle Del Cauca'),
(76890, 'Yotoco', 'Valle Del Cauca'),
(76892, 'Yumbo', 'Valle Del Cauca'),
(76895, 'Zarzal', 'Valle Del Cauca'),
(81001, 'Arauca', 'Arauca'),
(81065, 'Arauquita', 'Arauca'),
(81220, 'Cravo Norte', 'Arauca'),
(81300, 'Fortul', 'Arauca'),
(81591, 'Puerto Rondon', 'Arauca'),
(81736, 'Saravena', 'Arauca'),
(81794, 'Tame', 'Arauca'),
(85001, 'Yopal', 'Casanare'),
(85010, 'Aguazul', 'Casanare'),
(85015, 'Chameza', 'Casanare'),
(85125, 'Hato Corozal', 'Casanare'),
(85136, 'La Salina', 'Casanare'),
(85139, 'Mani', 'Casanare'),
(85162, 'Monterrey', 'Casanare'),
(85225, 'Nunchia', 'Casanare'),
(85230, 'Orocue', 'Casanare'),
(85250, 'Paz De Ariporo', 'Casanare'),
(85263, 'Pore', 'Casanare'),
(85279, 'Recetor', 'Casanare'),
(85300, 'Sabanalarga', 'Casanare'),
(85315, 'Sacama', 'Casanare'),
(85325, 'San Luis De Palenque', 'Casanare'),
(85400, 'Tamara', 'Casanare'),
(85410, 'Tauramena', 'Casanare'),
(85430, 'Trinidad', 'Casanare'),
(85440, 'Villanueva', 'Casanare'),
(86001, 'Mocoa', 'Putumayo'),
(86219, 'Colon', 'Putumayo'),
(86320, 'Orito', 'Putumayo'),
(86568, 'Puerto Asis', 'Putumayo'),
(86569, 'Puerto Caicedo', 'Putumayo'),
(86571, 'Puerto Guzman', 'Putumayo'),
(86573, 'Leguizamo', 'Putumayo'),
(86749, 'Sibundoy', 'Putumayo'),
(86755, 'San Francisco', 'Putumayo'),
(86757, 'San Miguel', 'Putumayo'),
(86760, 'Santiago', 'Putumayo'),
(86865, 'Valle Del Guamuez', 'Putumayo'),
(86885, 'Villagarzon', 'Putumayo'),
(88001, 'San Andres', 'San Andres'),
(88564, 'Providencia', 'San Andres'),
(91001, 'Leticia', 'Amazonas'),
(91263, 'El Encanto', 'Amazonas'),
(91405, 'La Chorrera', 'Amazonas'),
(91407, 'La Pedrera', 'Amazonas'),
(91430, 'La Victoria', 'Amazonas'),
(91460, 'Miriti - Parana', 'Amazonas'),
(91530, 'Puerto Alegria', 'Amazonas'),
(91536, 'Puerto Arica', 'Amazonas'),
(91540, 'Puerto Nariño', 'Amazonas'),
(91669, 'Puerto Santander', 'Amazonas'),
(91798, 'Tarapaca', 'Amazonas'),
(94001, 'Inirida', 'Guainia'),
(94343, 'Barranco Minas', 'Guainia'),
(94663, 'Mapiripana', 'Guainia'),
(94883, 'San Felipe', 'Guainia'),
(94884, 'Puerto Colombia', 'Guainia'),
(94885, 'La Guadalupe', 'Guainia'),
(94886, 'Cacahual', 'Guainia'),
(94887, 'Pana Pana', 'Guainia'),
(94888, 'Morichal', 'Guainia'),
(95001, 'San Jose Del Guaviare', 'Guaviare'),
(95015, 'Calamar', 'Guaviare'),
(95025, 'El Retorno', 'Guaviare'),
(95200, 'Miraflores', 'Guaviare'),
(97001, 'Mitu', 'Vaupes'),
(97161, 'Caruru', 'Vaupes'),
(97511, 'Pacoa', 'Vaupes'),
(97666, 'Taraira', 'Vaupes'),
(97777, 'Papunaua', 'Vaupes'),
(97889, 'Yavarate', 'Vaupes'),
(99001, 'Puerto Carreño', 'Vichada'),
(99524, 'La Primavera', 'Vichada'),
(99624, 'Santa Rosalia', 'Vichada'),
(99773, 'Cumaribo', 'Vichada');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE IF NOT EXISTS `cliente` (
  `CodigoCliente` int(11) NOT NULL,
  `IdTipoIdentidad1` int(11) NOT NULL,
  `NumeroDocumento` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Nombre` varchar(60) COLLATE latin1_spanish_ci NOT NULL,
  `Apellido` varchar(60) COLLATE latin1_spanish_ci NOT NULL,
  `Genero` char(1) COLLATE latin1_spanish_ci NOT NULL,
  `FechaNacimiento` date NOT NULL,
  `Direccion` varchar(120) COLLATE latin1_spanish_ci NOT NULL,
  `Telefono` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  `Email` varchar(120) COLLATE latin1_spanish_ci NOT NULL,
  `IdBarrio1` int(11) NOT NULL,
  `CodigoCiudad1` int(11) NOT NULL,
  `estado` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`CodigoCliente`),
  KEY `FK_IdTipoIdentidad1` (`IdTipoIdentidad1`),
  KEY `FK_IdBarrio1` (`IdBarrio1`),
  KEY `FK_CodigoCiudad1` (`CodigoCiudad1`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`CodigoCliente`, `IdTipoIdentidad1`, `NumeroDocumento`, `Nombre`, `Apellido`, `Genero`, `FechaNacimiento`, `Direccion`, `Telefono`, `Email`, `IdBarrio1`, `CodigoCiudad1`, `estado`) VALUES
(1, 7, '0', 'CLIENTE', 'DE MOSTRADOR', 'M', '2019-06-18', '0', '0', '0', 0, 0, 'Activo'),
(2, 4, '1144043776', 'Diego', 'Herrera', 'M', '1991-05-11', 'Calle 100', '3172185139', 'diegoherrera41@gmail.com', 1, 76001, 'Activo'),
(3, 6, '91051161900', 'Alexander', 'Saa', 'M', '1993-11-22', '', '', 'alex@hotmail.com', 2, 5001, 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalleventa`
--

DROP TABLE IF EXISTS `detalleventa`;
CREATE TABLE IF NOT EXISTS `detalleventa` (
  `idDetalleVenta` int(5) NOT NULL,
  `idFactura1` int(11) NOT NULL,
  `CodigoArticulo1` int(11) NOT NULL,
  `precioUnid` double(15,2) NOT NULL,
  `cantidad` int(2) NOT NULL,
  `subTotal` double(15,2) NOT NULL,
  PRIMARY KEY (`idDetalleVenta`),
  KEY `CodigoArticulo1` (`CodigoArticulo1`),
  KEY `FK_idFactura1` (`idFactura1`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `detalleventa`
--

INSERT INTO `detalleventa` (`idDetalleVenta`, `idFactura1`, `CodigoArticulo1`, `precioUnid`, `cantidad`, `subTotal`) VALUES
(1, 1, 1, 16200.00, 2, 32400.00),
(2, 1, 4, 1570800.00, 3, 4712400.00),
(3, 1, 2, 34880.00, 1, 34880.00),
(4, 1, 3, 2514500.00, 1, 2514500.00),
(5, 2, 2, 34880.00, 4, 139520.00),
(6, 2, 2, 34880.00, 2, 69760.00),
(7, 2, 3, 2514500.00, 1, 2514500.00),
(8, 3, 2, 34880.00, 1, 34880.00),
(9, 3, 3, 2514500.00, 2, 5029000.00),
(10, 3, 4, 1570800.00, 1, 1570800.00),
(11, 3, 1, 16200.00, 1, 16200.00),
(12, 3, 1, 16200.00, 3, 48600.00),
(13, 4, 1, 16200.00, 2, 32400.00),
(14, 4, 2, 34880.00, 1, 34880.00),
(15, 5, 5, 26950.00, 2, 53900.00),
(16, 5, 1, 16200.00, 2, 32400.00),
(17, 5, 2, 34880.00, 1, 34880.00),
(18, 6, 1, 16200.00, 3, 48600.00),
(19, 6, 2, 34880.00, 4, 139520.00),
(20, 6, 3, 2514500.00, 1, 2514500.00),
(21, 6, 5, 26950.00, 1, 26950.00),
(22, 6, 4, 1570800.00, 1, 1570800.00),
(23, 7, 1, 16200.00, 1, 16200.00),
(24, 8, 5, 26950.00, 2, 53900.00),
(25, 9, 4, 1570800.00, 1, 1570800.00),
(26, 10, 3, 2514500.00, 1, 2514500.00),
(27, 10, 4, 1570800.00, 1, 1570800.00),
(28, 10, 5, 26950.00, 1, 26950.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

DROP TABLE IF EXISTS `empleados`;
CREATE TABLE IF NOT EXISTS `empleados` (
  `IdEmpleados` int(11) NOT NULL,
  `PrimerNombre` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  `SegundoNombre` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  `PrimerApellido` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  `SegundoApellido` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  `IdRol1` int(11) NOT NULL,
  `Sexo` char(1) COLLATE latin1_spanish_ci NOT NULL,
  `IdTipoIdentidad2` int(11) NOT NULL,
  `NumeroIdentidad` varchar(30) COLLATE latin1_spanish_ci NOT NULL,
  `FechaNac` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  `IdCargo1` int(11) NOT NULL,
  `Direccion` varchar(60) COLLATE latin1_spanish_ci NOT NULL,
  `Telefono` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `horaEntrada` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  `horaSalida` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  `estado` varchar(12) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`IdEmpleados`),
  KEY `FK_IdRol1` (`IdRol1`),
  KEY `FK_IdTipoIdentidad2` (`IdTipoIdentidad2`),
  KEY `FK_IdCargo1` (`IdCargo1`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`IdEmpleados`, `PrimerNombre`, `SegundoNombre`, `PrimerApellido`, `SegundoApellido`, `IdRol1`, `Sexo`, `IdTipoIdentidad2`, `NumeroIdentidad`, `FechaNac`, `IdCargo1`, `Direccion`, `Telefono`, `horaEntrada`, `horaSalida`, `estado`) VALUES
(1, 'Diego', '', 'Herrera', 'Saa', 1, 'M', 4, '123', '1991-05-11', 1, 'CRA 2 Nº31-41', '3172185139', '7:30:00 a. m.', '5:30:00 p. m.', 'Activo'),
(2, 'Alexander', '', 'Saa', 'Saa', 2, 'M', 1, '321', '1992-06-25', 2, 'Avenida 32 # 3 14', '3002589632', '8:00:00 a. m.', '5:30:00 p. m.', 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

DROP TABLE IF EXISTS `factura`;
CREATE TABLE IF NOT EXISTS `factura` (
  `IdFactura` int(20) NOT NULL,
  `idTipoFactura1` int(2) NOT NULL,
  `Fecha` varchar(30) COLLATE latin1_spanish_ci NOT NULL,
  `Hora` varchar(30) COLLATE latin1_spanish_ci NOT NULL,
  `CodigoCaja1` int(11) NOT NULL,
  `IdEmpleados1` int(11) NOT NULL,
  `CodigoCliente1` int(11) NOT NULL,
  PRIMARY KEY (`IdFactura`),
  KEY `FK_CodigoCaja1` (`CodigoCaja1`),
  KEY `FK_CodigoCliente1` (`CodigoCliente1`),
  KEY `FK_IdEmpleados1` (`IdEmpleados1`),
  KEY `idTipoFactura1` (`idTipoFactura1`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `factura`
--

INSERT INTO `factura` (`IdFactura`, `idTipoFactura1`, `Fecha`, `Hora`, `CodigoCaja1`, `IdEmpleados1`, `CodigoCliente1`) VALUES
(1, 2, '2019-06-14', '03:04:57 AM', 2, 1, 1),
(2, 1, '2019-06-14', '03:06:14 AM', 2, 1, 3),
(3, 1, '2019-06-14', '03:07:41 AM', 2, 1, 2),
(4, 2, '2019-06-14', '03:02:52 PM', 1, 2, 1),
(5, 2, '2019-06-14', '09:02:02 PM', 1, 1, 3),
(6, 2, '2019-06-20', '01:04:19 AM', 1, 1, 2),
(7, 1, '2019-06-28', '10:53:24 PM', 1, 1, 1),
(8, 2, '2019-06-28', '10:56:15 PM', 1, 2, 1),
(9, 1, '2019-06-28', '11:01:10 PM', 2, 1, 2),
(10, 2, '2019-06-28', '11:03:31 PM', 2, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lineaproducto`
--

DROP TABLE IF EXISTS `lineaproducto`;
CREATE TABLE IF NOT EXISTS `lineaproducto` (
  `IdLineas` int(11) NOT NULL,
  `LineaDescripcion` varchar(80) COLLATE latin1_spanish_ci NOT NULL,
  `estado` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`IdLineas`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `lineaproducto`
--

INSERT INTO `lineaproducto` (`IdLineas`, `LineaDescripcion`, `estado`) VALUES
(1, 'Ropa', 'Activo'),
(2, 'Tecnología', 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
CREATE TABLE IF NOT EXISTS `proveedores` (
  `IdProveedor` bigint(20) NOT NULL,
  `NumeroIdentidad` bigint(20) NOT NULL,
  `Nombre` varchar(80) COLLATE latin1_spanish_ci NOT NULL,
  `CodigoCiudad2` int(11) NOT NULL,
  `Direccion` varchar(80) COLLATE latin1_spanish_ci NOT NULL,
  `Telefono` bigint(15) NOT NULL,
  `Email` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  `estado` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`IdProveedor`),
  KEY `FK_CodigoCiudad2` (`CodigoCiudad2`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`IdProveedor`, `NumeroIdentidad`, `Nombre`, `CodigoCiudad2`, `Direccion`, `Telefono`, `Email`, `estado`) VALUES
(1, 123456789, 'Gef SAS', 76001, 'Calle 29 # 43 A 47', 6045802, 'gef@gmail.com', 'Activo'),
(2, 900123456, 'GSMPHONE-BOG', 11001, 'Parque Simon Bolivar', 3172505890, 'gsm@hotmail.com', 'Activo'),
(3, 9005103598, 'GRUPO BW TECHNOLOGI', 5001, 'Avenida las Plamas', 3215104875, 'gbwtech@gmail.com', 'Activo'),
(4, 900456789, 'Almacenes SI', 76001, 'Cl. 12 #8-58', 6410000, 'almacenessi.com', 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

DROP TABLE IF EXISTS `rol`;
CREATE TABLE IF NOT EXISTS `rol` (
  `IdRol` int(11) NOT NULL,
  `Nombre` varchar(40) COLLATE latin1_spanish_ci NOT NULL,
  `Descripcion` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`IdRol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`IdRol`, `Nombre`, `Descripcion`) VALUES
(1, 'Administrador', 'Todos los permisos'),
(2, 'Usuario', 'Consultar, editar (productos) y crear (clientes), ver info de empleados');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sublineaproducto`
--

DROP TABLE IF EXISTS `sublineaproducto`;
CREATE TABLE IF NOT EXISTS `sublineaproducto` (
  `IdSubLinea` int(11) NOT NULL,
  `SubLineaDescripcion` varchar(80) COLLATE latin1_spanish_ci NOT NULL,
  `IdLineas1` int(11) NOT NULL,
  `estado` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`IdSubLinea`),
  KEY `FK_IdLineas1` (`IdLineas1`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `sublineaproducto`
--

INSERT INTO `sublineaproducto` (`IdSubLinea`, `SubLineaDescripcion`, `IdLineas1`, `estado`) VALUES
(1, 'Camisas', 1, 'Activo'),
(2, 'Pantalones', 1, 'Activo'),
(3, 'Televisores', 2, 'Activo'),
(4, 'Celulares', 2, 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipocaja`
--

DROP TABLE IF EXISTS `tipocaja`;
CREATE TABLE IF NOT EXISTS `tipocaja` (
  `IdTipoCaja` int(11) NOT NULL,
  `Nombre` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  `estado` varchar(12) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`IdTipoCaja`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `tipocaja`
--

INSERT INTO `tipocaja` (`IdTipoCaja`, `Nombre`, `estado`) VALUES
(1, 'Caja Rápida', 'Activo'),
(2, 'Caja Normal', 'Activo'),
(3, 'Caja Prioritaria', 'Inactivo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipofactura`
--

DROP TABLE IF EXISTS `tipofactura`;
CREATE TABLE IF NOT EXISTS `tipofactura` (
  `idTipoFactura` int(2) NOT NULL,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`idTipoFactura`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipofactura`
--

INSERT INTO `tipofactura` (`idTipoFactura`, `descripcion`) VALUES
(1, 'Venta'),
(2, 'Cotización');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipoidentidad`
--

DROP TABLE IF EXISTS `tipoidentidad`;
CREATE TABLE IF NOT EXISTS `tipoidentidad` (
  `IdTipoIdentidad` int(11) NOT NULL,
  `NombreTipoIdentidad` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`IdTipoIdentidad`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `tipoidentidad`
--

INSERT INTO `tipoidentidad` (`IdTipoIdentidad`, `NombreTipoIdentidad`) VALUES
(1, 'Cédula Ciudadania'),
(2, 'Libreta Militar'),
(3, 'Pasaporte'),
(4, 'Cédula Extranjeria'),
(5, 'Contraseña'),
(6, 'Tarjeta Identidad'),
(7, 'Otro');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `articulo`
--
ALTER TABLE `articulo`
  ADD CONSTRAINT `FK_IdProveedor1` FOREIGN KEY (`IdProveedor1`) REFERENCES `proveedores` (`IdProveedor`),
  ADD CONSTRAINT `FK_IdSublinea1` FOREIGN KEY (`IdSublinea1`) REFERENCES `sublineaproducto` (`IdSubLinea`);

--
-- Filtros para la tabla `caja`
--
ALTER TABLE `caja`
  ADD CONSTRAINT `FK_IdTipoCaja1` FOREIGN KEY (`IdTipoCaja1`) REFERENCES `tipocaja` (`IdTipoCaja`);

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `FK_CodigoCiudad1` FOREIGN KEY (`CodigoCiudad1`) REFERENCES `ciudad` (`CodigoCiudad`),
  ADD CONSTRAINT `FK_IdBarrio1` FOREIGN KEY (`IdBarrio1`) REFERENCES `barrio` (`IdBarrio`),
  ADD CONSTRAINT `FK_IdTipoIdentidad1` FOREIGN KEY (`IdTipoIdentidad1`) REFERENCES `tipoidentidad` (`IdTipoIdentidad`);

--
-- Filtros para la tabla `detalleventa`
--
ALTER TABLE `detalleventa`
  ADD CONSTRAINT `FK_CodigoArticulo1` FOREIGN KEY (`CodigoArticulo1`) REFERENCES `articulo` (`CodigoArticulo`),
  ADD CONSTRAINT `FK_idFactura1` FOREIGN KEY (`idFactura1`) REFERENCES `factura` (`IdFactura`);

--
-- Filtros para la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD CONSTRAINT `FK_IdCargo1` FOREIGN KEY (`IdCargo1`) REFERENCES `cargos` (`IdCargo`),
  ADD CONSTRAINT `FK_IdRol1` FOREIGN KEY (`IdRol1`) REFERENCES `rol` (`IdRol`),
  ADD CONSTRAINT `FK_IdTipoIdentidad2` FOREIGN KEY (`IdTipoIdentidad2`) REFERENCES `tipoidentidad` (`IdTipoIdentidad`);

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `FK_CodigoCaja1` FOREIGN KEY (`CodigoCaja1`) REFERENCES `caja` (`CodigoCaja`),
  ADD CONSTRAINT `FK_CodigoCliente1` FOREIGN KEY (`CodigoCliente1`) REFERENCES `cliente` (`CodigoCliente`),
  ADD CONSTRAINT `FK_IdEmpleados1` FOREIGN KEY (`IdEmpleados1`) REFERENCES `empleados` (`IdEmpleados`),
  ADD CONSTRAINT `FK_idTipoFactura1` FOREIGN KEY (`idTipoFactura1`) REFERENCES `tipofactura` (`idTipoFactura`);

--
-- Filtros para la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD CONSTRAINT `FK_CodigoCiudad2` FOREIGN KEY (`CodigoCiudad2`) REFERENCES `ciudad` (`CodigoCiudad`);

--
-- Filtros para la tabla `sublineaproducto`
--
ALTER TABLE `sublineaproducto`
  ADD CONSTRAINT `FK_IdLineas1` FOREIGN KEY (`IdLineas1`) REFERENCES `lineaproducto` (`IdLineas`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
